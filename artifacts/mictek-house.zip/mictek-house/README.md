# MicTek House

Playable album shelf for Mikey More Bounce. Lives outside Suno.

Open `index.html` in a browser. Four shelves are already named: West Coast, Neon Bae Groove, Bounce, Konkrete Jungle. Covers are placeholders. Swap them.

## Add a release

1. Download the tracks from Suno (MP3 or WAV).
2. Open an album.
3. Drop the files on the dashed box. Order them with the arrows.
4. Or hit New album and start a shelf that is not in the starter list.

Audio stays in this browser (IndexedDB). It is not uploaded anywhere. Refresh keeps it. Another computer does not have it until you copy the files.

## Put it on the internet

Host this folder on Netlify, GitHub Pages, or any static host.

1. Make a folder per album under `audio/`, for example `audio/west-coast/01.mp3`.
2. Point each track `src` in `albums.json` at that file.
3. Publish the folder.

Export writes an `albums.json` with suggested paths. Import reads a catalog back in. Import does not carry the audio blobs, only titles and file paths.

Space plays and pauses. Left and right arrows skip 5 seconds.

Suno albums still do not push to Spotify or Apple Music. This page is the public player you control.
