import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import vm from 'node:vm';
import { RegionCompletionGate } from '../audio/region-gate.js';
import { makeRegionKey, percentile } from '../audio/protocol.js';
import { equalPowerGains, crossfaderGains, dbToGain, faderGain, filterFrequencies, monitorBlendGains, echoDelaySeconds } from '../audio/mixer-law.js';
import { buildDemoTrack } from '../audio/track-provider.js';
import { buildPeakModel, predictSourceFrame } from '../visual/waveform-view.js';
import { calculateTapTempo, syncPitchPercent, smartSyncPitchPercent, msUntilNextBeat, msUntilNextBoundary, loopBoundsFromBeats, bpmFamily } from '../performance/tempo.js';
import { automixDecks, automixPosition, resolveAutomixDirection } from '../performance/automix.js';
import { detectBpmFromMono } from '../analysis/bpm-core.js';
import { sanitizeCrtSettings } from '../world/crt/crt-shell.js';
import { decideVisualProtection } from '../world/quality-manager.js';
import { normalizeVisualSnapshot, dbToVisualPercent } from '../world/visual-state-bridge.js';
import { normalizeHardwareRange, hardwareRangeAngle, resolveHardwareTargetId } from '../world/hardware/hardware-surface.js';
import { sanitizePresentationMode } from '../world/view-mode-controller.js';
import { sanitizeLabTab } from '../world/lab/diagnostics-drawer.js';
import { sanitizeCrtSource } from '../world/crt/source-router.js';
import { inferTrackMetadata, sanitizeCrateSort, isSupportedAudioFile, sanitizeManifest, sanitizeTrackPrep, normalizeTrackTags, tempoFamilyDistance, selectSmartSetTracks, chooseQuietDeck, estimateEnergyFromMono } from '../library/suno-crate-bridge.js';
import { auditTrackRecord, summarizeLibraryHealth, reconcileQueue, buildImportReceipt, matchRepairCandidate, sanitizeRecoveryManifest } from '../library/library-reliability.js';
import { calculateBoothFit } from '../world/booth/booth-composition.js';
import { rangePercent, meterPercentFromStyle } from '../world/crt/performance-monitor.js';
import { sanitizeBoothFrame } from '../world/booth/framing-controller.js';
import { sanitizeDrawerCompact } from '../world/lab/diagnostics-drawer.js';

const results = [];
function test(name, fn) {
  try { fn(); results.push({ name, ok: true }); }
  catch (error) { results.push({ name, ok: false, error }); }
}

const base = {
  deckId: 'A', trackId: 'track-1', regionId: 2, generation: 7, requestSeq: 44,
  startFrame: 32768, frameCount: 16384, deadlineMs: 1000,
};

test('accepts matching completion exactly once', () => {
  const gate = new RegionCompletionGate();
  gate.expect(base);
  const first = gate.evaluate({ ...base, channels: [new Float32Array(2)], stillUseful: true }, 900);
  assert.equal(first.accepted, true);
});

test('rejects wrong deck ownership', () => {
  const gate = new RegionCompletionGate(); gate.expect(base);
  const result = gate.evaluate({ ...base, deckId: 'B', channels: [new Float32Array(2)] }, 900);
  assert.equal(result.reason, 'wrong-deck');
});

test('rejects stale generation', () => {
  const gate = new RegionCompletionGate(); gate.expect(base);
  const result = gate.evaluate({ ...base, generation: 6, channels: [new Float32Array(2)] }, 900);
  assert.deepEqual(result, { accepted: false, reason: 'stale-generation' });
});

test('rejects obsolete request sequence', () => {
  const gate = new RegionCompletionGate(); gate.expect(base);
  const result = gate.evaluate({ ...base, requestSeq: 43, channels: [new Float32Array(2)] }, 900);
  assert.equal(result.reason, 'obsolete-request');
});

test('rejects wrong range', () => {
  const gate = new RegionCompletionGate(); gate.expect(base);
  const result = gate.evaluate({ ...base, startFrame: 0, channels: [new Float32Array(2)] }, 900);
  assert.equal(result.reason, 'wrong-range');
});

test('region key includes deck ownership', () => {
  assert.equal(makeRegionKey(base), 'A:track-1:7:32768:16384');
  assert.notEqual(makeRegionKey(base), makeRegionKey({ ...base, deckId: 'B' }));
});

test('percentile handles bounded samples', () => {
  assert.equal(percentile([9, 1, 5, 3, 7], 50), 5);
  assert.equal(percentile([9, 1, 5, 3, 7], 95), 9);
});

test('equal-power crossfader has lawful endpoints and center', () => {
  const left = equalPowerGains(-1);
  const center = equalPowerGains(0);
  const right = equalPowerGains(1);
  assert.ok(Math.abs(left.a - 1) < 1e-12 && Math.abs(left.b) < 1e-12);
  assert.ok(Math.abs(center.a - Math.SQRT1_2) < 1e-12);
  assert.ok(Math.abs(center.b - Math.SQRT1_2) < 1e-12);
  assert.ok(Math.abs(right.a) < 1e-12 && Math.abs(right.b - 1) < 1e-12);
  assert.ok(Math.abs(center.a ** 2 + center.b ** 2 - 1) < 1e-12);
});


test('crossfader curve preserves endpoints and sharpens the center', () => {
  const smooth = crossfaderGains(0, 0);
  const battle = crossfaderGains(0, 1);
  assert.ok(Math.abs(crossfaderGains(-1, 1).a - 1) < 1e-12);
  assert.ok(Math.abs(crossfaderGains(1, 1).b - 1) < 1e-12);
  assert.ok(battle.a < smooth.a && battle.b < smooth.b);
});

test('tap tempo rejects outlier gaps and resolves 96 BPM', () => {
  const interval = 60_000 / 96;
  const taps = [0, interval, interval * 2, interval * 3, interval * 4, interval * 4 + 1900, interval * 5 + 1900];
  const bpm = calculateTapTempo(taps);
  assert.ok(Math.abs(bpm - 96) < 0.1);
});

test('tempo sync calculates lawful pitch and reports range limits', () => {
  const match = syncPitchPercent(120, 125);
  assert.equal(match.ok, true);
  assert.ok(Math.abs(match.percent + 4) < 1e-9);
  const limited = syncPitchPercent(180, 90);
  assert.equal(limited.ok, false);
  assert.equal(limited.percent, 16);
});

test('next-beat delay is bounded by one beat', () => {
  const wait = msUntilNextBeat(24_000, 48_000, 120);
  assert.ok(wait >= 0 && wait <= 500);
});

test('smart tempo family resolves half-time analysis without extreme pitch', () => {
  const result = smartSyncPitchPercent(129, 70.8);
  assert.equal(result.ok, true);
  assert.equal(result.reason, 'family-matched');
  assert.equal(result.targetFamilyFactor, 2);
  assert.ok(Math.abs(result.percent + 8.8983050847) < 0.001);
});

test('smart tempo family refuses unsafe range instead of pretending lock', () => {
  const result = smartSyncPitchPercent(180, 63);
  assert.equal(result.ok, false);
  assert.equal(result.reason, 'outside-pitch-range');
  assert.ok(Math.abs(result.percent) <= 16);
});

test('BPM family exposes lawful half and double candidates', () => {
  const family = bpmFamily(70.8);
  assert.ok(family.some((entry) => Math.abs(entry.bpm - 141.6) < 1e-9 && entry.factor === 2));
  assert.ok(family.some((entry) => Math.abs(entry.bpm - 70.8) < 1e-9 && entry.factor === 1));
});

test('phrase boundary wait is bounded by selected phrase', () => {
  const wait = msUntilNextBoundary(48_000 * 3.4, 48_000, 120, 0, 1, 16);
  assert.ok(wait >= 0 && wait <= 8_000);
});

test('beat loop bounds quantize and preserve requested beat count', () => {
  const loop = loopBoundsFromBeats(51_000, 48_000, 120, 4, 0);
  assert.equal(loop.startFrame, 48_000);
  assert.equal(loop.endFrame, 144_000);
  assert.equal(loop.beats, 4);
});

test('monitor blend is equal-power and cue level bounded', () => {
  const master = monitorBlendGains(0, .7);
  const center = monitorBlendGains(.5, .7);
  const cue = monitorBlendGains(1, .7);
  assert.ok(Math.abs(master.master - 1) < 1e-12 && master.cue === 0);
  assert.ok(center.master > 0 && center.cue > 0);
  assert.ok(cue.master < 1e-12 && Math.abs(cue.cue - .7) < 1e-12);
});

test('echo delay conversion is clamped to safe bounds', () => {
  assert.equal(echoDelaySeconds(280), .28);
  assert.equal(echoDelaySeconds(1), .04);
  assert.equal(echoDelaySeconds(5_000), .9);
});

test('automix direction and crossfade law are deterministic', () => {
  assert.equal(resolveAutomixDirection(-0.2, 'AUTO'), 'A_TO_B');
  assert.deepEqual(automixDecks('B_TO_A'), { source: 'B', target: 'A', finalPosition: -1 });
  assert.equal(automixPosition('A_TO_B', 0), -1);
  assert.equal(automixPosition('A_TO_B', 1), 1);
  assert.equal(automixPosition('B_TO_A', 1), -1);
});

test('BPM detector resolves a synthetic 96 BPM pulse train', () => {
  const sampleRate = 8_000;
  const seconds = 24;
  const samples = new Float32Array(sampleRate * seconds);
  const beatFrames = sampleRate * 60 / 96;
  for (let beat = 0; beat < samples.length; beat += beatFrames) {
    for (let i = 0; i < 180 && Math.floor(beat) + i < samples.length; i += 1) {
      samples[Math.floor(beat) + i] += Math.exp(-i / 34);
    }
  }
  const result = detectBpmFromMono(samples, sampleRate, { maxSeconds: seconds });
  assert.ok(Math.abs(result.bpm - 96) < 0.6, JSON.stringify(result));
  assert.ok(result.confidence > 0.2);
});

test('mixer gain helpers are bounded and monotonic', () => {
  assert.equal(dbToGain(0), 1);
  assert.ok(dbToGain(6) > 1);
  assert.equal(faderGain(0), 0);
  assert.equal(faderGain(1), 1);
  assert.ok(faderGain(.5) < .5);
});

test('bipolar filter opens in center and closes correct side', () => {
  const open = filterFrequencies(0);
  const lowpass = filterFrequencies(-1);
  const highpass = filterFrequencies(1);
  assert.equal(open.highpassHz, 20);
  assert.equal(open.lowpassHz, 20_000);
  assert.ok(lowpass.lowpassHz <= 121 && lowpass.highpassHz === 20);
  assert.ok(highpass.highpassHz >= 4_999 && highpass.lowpassHz === 20_000);
});

test('demo decks are distinct but tempo-compatible', () => {
  const a = buildDemoTrack(48_000, 2, 'A');
  const b = buildDemoTrack(48_000, 2, 'B');
  assert.equal(a.bpm, b.bpm);
  assert.equal(a.length, b.length);
  assert.notEqual(a.name, b.name);
  let difference = 0;
  for (let i = 0; i < 2_000; i += 1) difference += Math.abs(a.channels[0][i] - b.channels[0][i]);
  assert.ok(difference > 1);
});

test('waveform peak model preserves extrema', () => {
  const channel = new Float32Array([0, 0.25, -0.75, 0.5, -0.1, 0.9, -0.4, 0]);
  const model = buildPeakModel(channel, 48_000, 4, 64);
  assert.equal(model.min[0], -0.75);
  assert.equal(model.max[0], 0.5);
  assert.ok(Math.abs(model.max[1] - 0.9) < 1e-6);
});

test('waveform transport prediction moves, reverses, and wraps', () => {
  const transport = { sourceFrame: 47_900, trackLength: 48_000, sampleRate: 48_000, playing: true, pitchRatio: 1, jogRatio: 1 };
  assert.equal(predictSourceFrame(transport, 1_000, 1_100), 4_700);
  assert.equal(predictSourceFrame({ ...transport, sourceFrame: 100, jogRatio: -1 }, 1_000, 1_100), 43_300);
});

test('worklet avoids unguarded performance.now and declares deck ownership', () => {
  const source = readFileSync(new URL('../audio/backspin-processor.js', import.meta.url), 'utf8');
  assert.equal(source.includes('const startedAt = performance.now()'), false);
  assert.equal(source.includes("deckId: config.deckId === 'B' ? 'B' : 'A'"), true);
  assert.equal(source.includes('outputRms'), true);
  assert.equal(source.includes('outputPeak'), true);
});

test('two processors keep independent deck IDs and PCM timelines', () => {
  const source = readFileSync(new URL('../audio/backspin-processor.js', import.meta.url), 'utf8');
  let RegisteredProcessor = null;
  class MockPort {
    constructor() { this.onmessage = null; this.messages = []; }
    postMessage(message) { this.messages.push(message); }
  }
  class MockAudioWorkletProcessor { constructor() { this.port = new MockPort(); } }
  const scope = {
    AudioWorkletProcessor: MockAudioWorkletProcessor,
    registerProcessor: (_name, Processor) => { RegisteredProcessor = Processor; },
    sampleRate: 48_000, currentFrame: 0, currentTime: 0,
    Date, Math, Map, Array, Float32Array, Number, String, Boolean, Error, console,
  };
  scope.globalThis = scope;
  vm.createContext(scope);
  vm.runInContext(source, scope, { filename: 'backspin-processor.js' });

  const a = new RegisteredProcessor({ processorOptions: { buildId: 'test', deckId: 'A', regionFrames: 16_384, slotCount: 4 } });
  const b = new RegisteredProcessor({ processorOptions: { buildId: 'test', deckId: 'B', regionFrames: 16_384, slotCount: 4 } });
  assert.equal(a.port.messages[0].deckId, 'A');
  assert.equal(b.port.messages[0].deckId, 'B');

  installAndPlay(a, 'A', .25);
  installAndPlay(b, 'B', -.15);
  let audibleA = false;
  let audibleB = false;
  for (let q = 0; q < 50; q += 1) {
    const aL = new Float32Array(128), aR = new Float32Array(128);
    const bL = new Float32Array(128), bR = new Float32Array(128);
    assert.equal(a.process([], [[aL, aR]]), true);
    assert.equal(b.process([], [[bL, bR]]), true);
    audibleA ||= aL.some((sample) => sample > .2);
    audibleB ||= bL.some((sample) => sample < -.1);
    scope.currentFrame += 128;
    scope.currentTime = scope.currentFrame / scope.sampleRate;
  }
  assert.equal(audibleA, true);
  assert.equal(audibleB, true);
  const telemetryA = a.port.messages.find((message) => message.type === 'telemetry');
  const telemetryB = b.port.messages.find((message) => message.type === 'telemetry');
  assert.equal(telemetryA.deckId, 'A');
  assert.equal(telemetryB.deckId, 'B');
  assert.ok(telemetryA.sourceFrame > 0 && telemetryB.sourceFrame > 0);
  assert.ok(telemetryA.outputPeak > 0 && telemetryB.outputPeak > 0);

  function installAndPlay(processor, deckId, value) {
    processor.port.onmessage({ data: { type: 'load-track', deckId, trackId: `track-${deckId}`, trackLength: 48_000, generation: 1, regionFrames: 16_384 } });
    const request = processor.port.messages.find((message) => message.type === 'region-request' && message.startFrame === 0);
    assert.ok(request);
    const frames = request.frameCount + 1;
    processor.port.onmessage({ data: {
      type: 'region-ready', deckId, trackId: request.trackId, regionId: request.regionId,
      generation: request.generation, requestSeq: request.requestSeq, startFrame: request.startFrame,
      frameCount: request.frameCount, validFrameCount: request.frameCount, continuityToken: 1,
      channels: [new Float32Array(frames).fill(value), new Float32Array(frames).fill(value)],
    } });
    processor.port.onmessage({ data: { type: 'command', deckId, command: 'set-playing', payload: { playing: true }, sequence: 1, effectiveFrame: 0 } });
  }
});


test('worklet loops inside the commanded beat region without leaving sample time', () => {
  const source = readFileSync(new URL('../audio/backspin-processor.js', import.meta.url), 'utf8');
  let RegisteredProcessor = null;
  class MockPort {
    constructor() { this.onmessage = null; this.messages = []; }
    postMessage(message) { this.messages.push(message); }
  }
  class MockAudioWorkletProcessor { constructor() { this.port = new MockPort(); } }
  const scope = {
    AudioWorkletProcessor: MockAudioWorkletProcessor,
    registerProcessor: (_name, Processor) => { RegisteredProcessor = Processor; },
    sampleRate: 48_000, currentFrame: 0, currentTime: 0,
    Date, Math, Map, Array, Float32Array, Number, String, Boolean, Error, console,
  };
  scope.globalThis = scope;
  vm.createContext(scope);
  vm.runInContext(source, scope, { filename: 'backspin-processor.js' });

  const processor = new RegisteredProcessor({ processorOptions: { buildId: 'loop-test', deckId: 'A', regionFrames: 16_384, slotCount: 4 } });
  processor.port.onmessage({ data: { type: 'load-track', deckId: 'A', trackId: 'loop-track', trackLength: 48_000, generation: 1, regionFrames: 16_384 } });
  const request = processor.port.messages.find((message) => message.type === 'region-request' && message.startFrame === 0);
  const frames = request.frameCount + 1;
  processor.port.onmessage({ data: {
    type: 'region-ready', deckId: 'A', trackId: request.trackId, regionId: request.regionId,
    generation: request.generation, requestSeq: request.requestSeq, startFrame: request.startFrame,
    frameCount: request.frameCount, validFrameCount: request.frameCount, continuityToken: 1,
    channels: [new Float32Array(frames).fill(.2), new Float32Array(frames).fill(.2)],
  } });
  processor.port.onmessage({ data: { type: 'command', deckId: 'A', command: 'set-loop', payload: { enabled: true, startFrame: 0, endFrame: 256, beats: 1 }, sequence: 1, effectiveFrame: 0 } });
  processor.port.onmessage({ data: { type: 'command', deckId: 'A', command: 'set-playing', payload: { playing: true }, sequence: 2, effectiveFrame: 0 } });
  for (let q = 0; q < 50; q += 1) {
    const left = new Float32Array(128), right = new Float32Array(128);
    assert.equal(processor.process([], [[left, right]]), true);
    scope.currentFrame += 128;
    scope.currentTime = scope.currentFrame / scope.sampleRate;
  }
  const telemetry = processor.port.messages.filter((message) => message.type === 'telemetry').at(-1);
  assert.equal(telemetry.loopEnabled, true);
  assert.equal(telemetry.loopBeats, 1);
  assert.ok(telemetry.sourceFrame >= 0 && telemetry.sourceFrame < 256, telemetry.sourceFrame);
});


test('CRT settings sanitize local preferences and clamp effect values', () => {
  const settings = sanitizeCrtSettings({ mode: 'other', quality: 'broken', scanlines: 150, glow: -4, curvature: 44, reflection: 30 });
  assert.equal(settings.mode, 'crt');
  assert.equal(settings.quality, 'auto');
  assert.equal(settings.scanlines, 100);
  assert.equal(settings.glow, 0);
  assert.equal(settings.curvature, 44);
});

test('visual state bridge clamps presentation snapshots without transport authority', () => {
  const snapshot = normalizeVisualSnapshot({
    sequence: 9.8,
    decks: { A: { angle: 12.5, playing: true, mode: 'scratch', bpm: 129, liveBpm: 108.4 }, B: { bpm: -20, liveBpm: 1200 } },
    mixer: { crossfader: 4, meterA: -12, meterB: -90, meterMaster: 3, recording: true, automix: true },
  });
  assert.equal(snapshot.sequence, 9);
  assert.equal(snapshot.decks.A.mode, 'scratch');
  assert.equal(snapshot.decks.B.bpm, 0);
  assert.equal(snapshot.decks.B.liveBpm, 999.9);
  assert.equal(snapshot.mixer.crossfader, 1);
  assert.equal(snapshot.mixer.recording, true);
});

test('visual meter conversion is bounded and monotonic', () => {
  assert.equal(dbToVisualPercent(-100), 0);
  assert.equal(dbToVisualPercent(0), 100);
  assert.ok(dbToVisualPercent(-12) > dbToVisualPercent(-24));
});

test('quality manager sends renderer faults directly to Safe Flat', () => {
  const decision = decideVisualProtection({ mode: 'crt', selected: 'full', current: 'full', rendererFault: true });
  assert.equal(decision.mode, 'flat');
  assert.match(decision.reason, /Renderer fault/);
});

test('automatic quality policy reduces CRT effects before abandoning the booth', () => {
  const reduced = decideVisualProtection({ mode: 'crt', selected: 'auto', current: 'full', fps: 22, lowFpsStreak: 4 });
  assert.equal(reduced.mode, 'crt');
  assert.equal(reduced.quality, 'reduced');
  const severe = decideVisualProtection({ mode: 'crt', selected: 'auto', current: 'reduced', fps: 12, severeFpsStreak: 3 });
  assert.equal(severe.mode, 'flat');
});

test('CRT shell hosts one canonical Phase 3 rig plus the tactile Phase 5B control mirror', () => {
  const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  assert.equal((html.match(/id="a-platter"/g) || []).length, 1);
  assert.equal((html.match(/id="crossfader"/g) || []).length, 1);
  assert.equal(html.includes('id="crtScreen"'), true);
  assert.equal(html.includes('id="viewFlat"'), true);
  assert.equal(html.includes('TACTILE HARDWARE SURFACE'), true);
  assert.equal(html.includes('data-hardware-platter="A"'), true);
  assert.equal(html.includes('data-range-target="crossfader"'), true);
});


test('hardware range normalization clamps and quantizes without inventing state', () => {
  assert.equal(normalizeHardwareRange(14.27, -16, 16, .01), 14.27);
  assert.equal(normalizeHardwareRange(30, -16, 16, .01), 16);
  assert.equal(normalizeHardwareRange(-30, -16, 16, .01), -16);
});

test('hardware rotary angle preserves lawful endpoints and center', () => {
  assert.equal(hardwareRangeAngle(-1, -1, 1), -135);
  assert.equal(hardwareRangeAngle(0, -1, 1), 0);
  assert.equal(hardwareRangeAngle(1, -1, 1), 135);
});

test('hardware target resolution uses explicit typed DOM bindings', () => {
  assert.equal(resolveHardwareTargetId({ dataset: { actionTarget: 'a-play' } }), 'a-play');
  assert.equal(resolveHardwareTargetId({ dataset: { rangeTarget: 'crossfader' } }), 'crossfader');
  assert.equal(resolveHardwareTargetId({ dataset: {} }), '');
});


test('every tactile control resolves to one real canonical target and IDs remain unique', () => {
  const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  const ids = [...html.matchAll(/id="([^"]+)"/g)].map((match) => match[1]);
  assert.equal(new Set(ids).size, ids.length);
  const targets = [...html.matchAll(/data-(?:action|range)-target="([^"]+)"/g)].map((match) => match[1]);
  assert.ok(targets.length >= 50, targets.length);
  for (const target of targets) assert.ok(ids.includes(target), `missing target ${target}`);
});

test('physical and CRT platters enter the same bounded scratch handler', () => {
  const source = readFileSync(new URL('../app.js', import.meta.url), 'utf8');
  assert.equal(source.includes('handlePlatterPointer(pointerEvent, deckId, element)'), true);
  assert.equal(source.includes('handlePlatterPointer(event, deckId, ui.platter)'), true);
  assert.equal(source.includes('function handlePlatterPointer(event, deckId, surface = deckUi[deckId].platter)'), true);
});


for (const result of results) {
  console.log(`${result.ok ? 'PASS' : 'FAIL'} ${result.name}`);
  if (!result.ok) console.error(result.error);
}


test('Phase 5C presentation modes reject unknown authority states', () => {
  assert.equal(sanitizePresentationMode('booth'), 'booth');
  assert.equal(sanitizePresentationMode('lab'), 'lab');
  assert.equal(sanitizePresentationMode('nonsense'), 'booth');
});

test('diagnostics drawer tabs are bounded to known evidence surfaces', () => {
  assert.equal(sanitizeLabTab('ledger'), 'ledger');
  assert.equal(sanitizeLabTab('transport'), 'health');
});

test('CRT source router accepts presentation sources only', () => {
  assert.equal(sanitizeCrtSource('tunnel'), 'tunnel');
  assert.equal(sanitizeCrtSource('health'), 'health');
  assert.equal(sanitizeCrtSource('audio-command'), 'performance');
});

test('booth fit crops room before abandoning the instrument', () => {
  assert.equal(calculateBoothFit({ width: 1600, height: 900 }).policy, 'hero');
  assert.equal(calculateBoothFit({ width: 1200, height: 800 }).policy, 'cropped');
  assert.equal(calculateBoothFit({ width: 560, height: 900 }).policy, 'flat');
  assert.ok(calculateBoothFit({ width: 1600, height: 900 }).crtScale > 0);
});

test('Phase 5C HTML preserves canonical controls and adds one hero composition boundary', () => {
  const html = readFileSync(new URL('../index.html', import.meta.url), 'utf8');
  assert.equal((html.match(/id="a-platter"/g) || []).length, 1);
  assert.equal((html.match(/id="crossfader"/g) || []).length, 1);
  assert.equal((html.match(/id="labDrawer"/g) || []).length, 1);
  assert.equal((html.match(/id="crtSourceLayer"/g) || []).length, 1);
  assert.equal(html.includes('id="viewLab"'), true);
  assert.equal(html.includes('id="boothStatusRail"'), true);
});



test('docked drawer reduces available booth height without changing fit authority', () => {
  const closed=calculateBoothFit({width:1600,height:900,drawerHeight:0});
  const open=calculateBoothFit({width:1600,height:900,drawerHeight:290});
  assert.equal(open.policy,'hero');
  assert.ok(open.availableHeight<closed.availableHeight);
  assert.ok(open.rigScale<closed.rigScale);
});

test('performance monitor percentages are bounded presentation-only helpers', () => {
  assert.equal(rangePercent(-1,-1,1),0);
  assert.equal(rangePercent(0,-1,1),50);
  assert.equal(rangePercent(1,-1,1),100);
  assert.equal(meterPercentFromStyle('144%'),100);
  assert.equal(meterPercentFromStyle('-3%'),0);
});

test('diagnostics compact state accepts explicit booleans only', () => {
  assert.equal(sanitizeDrawerCompact(true),true);
  assert.equal(sanitizeDrawerCompact('true'),true);
  assert.equal(sanitizeDrawerCompact('yes'),false);
});

test('Phase 5C.2 HTML has a dedicated monitor and bottom-dock controls without duplicating canonical IDs', () => {
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal((html.match(/id="crtSourcePerformance"/g)||[]).length,1);
  assert.equal((html.match(/id="crtWaveA"/g)||[]).length,1);
  assert.equal((html.match(/id="labDrawerCompact"/g)||[]).length,1);
  assert.equal((html.match(/id="a-platter"/g)||[]).length,1);
  assert.equal((html.match(/id="crossfader"/g)||[]).length,1);
  assert.equal(html.includes('speaker-stack speaker-left'),true);
  assert.equal(html.includes('booth-desk-surface'),true);
});

test('source router keeps canonical instrument available for Safe Flat while selecting visual panels', () => {
  const source=readFileSync(new URL('../world/crt/source-router.js',import.meta.url),'utf8');
  assert.equal(source.includes('this.instrument.hidden'),false);
  assert.equal(source.includes('this.performancePanel.hidden'),true);
  assert.equal(source.includes("canonicalInstrument:'preserved-for-flat-and-bindings'"),true);
});


test('cinematic booth framing accepts only Full Booth and Performance Rig',()=>{
  assert.equal(sanitizeBoothFrame('full'),'full');
  assert.equal(sanitizeBoothFrame('rig'),'rig');
  assert.equal(sanitizeBoothFrame('cinema'),'full');
});

test('Performance Rig fit grants more space to the tactile rig',()=>{
  const full=calculateBoothFit({width:1600,height:900,frame:'full'});
  const rig=calculateBoothFit({width:1600,height:900,frame:'rig'});
  assert.ok(rig.rigShare>full.rigShare);
  assert.ok(rig.rigScale>=full.rigScale);
  assert.ok(rig.crtShare<full.crtShare);
});

test('Phase 5C.3 HTML contains framing controls and cinematic depth layers without duplicate canonical controls',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal((html.match(/id="frameFull"/g)||[]).length,1);
  assert.equal((html.match(/id="frameRig"/g)||[]).length,1);
  assert.equal((html.match(/id="a-platter"/g)||[]).length,1);
  assert.equal((html.match(/id="crossfader"/g)||[]).length,1);
  assert.equal(html.includes('warehouse-wall-plane'),true);
  assert.equal(html.includes('warehouse-floor-plane'),true);
  assert.equal(html.includes('aux-video-monitor'),true);
  assert.equal(html.includes('rig-decals'),true);
});

test('CRT source router declares keyboard source shortcuts and preserves the canonical instrument',()=>{
  const source=readFileSync(new URL('../world/crt/source-router.js',import.meta.url),'utf8');
  assert.equal(source.includes("event.code==='KeyP'"),true);
  assert.equal(source.includes("event.code==='KeyT'"),true);
  assert.equal(source.includes("event.code==='KeyH'"),true);
  assert.equal(source.includes('this.instrument.hidden'),false);
  assert.equal(source.includes("canonicalInstrument:'preserved-for-flat-and-bindings'"),true);
});

test('Lab startup policy returns saved Lab sessions to Booth rather than covering the instrument',()=>{
  const source=readFileSync(new URL('../world/view-mode-controller.js',import.meta.url),'utf8');
  assert.equal(source.includes("saved === 'flat' ? 'flat' : 'booth'"),true);
  assert.equal(source.includes('Lab defaults closed for performance startup'),true);
});



test('Phase 5D.1a exposes props on the front bezel without adding control authority',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal((html.match(/class="rig-prop-shelf"/g)||[]).length,1);
  assert.equal((html.match(/class="record-crate /g)||[]).length,2);
  assert.equal((html.match(/class="practical-lamp /g)||[]).length,2);
  assert.equal(html.includes('data-action-target="front-headphones"'),false);
});

test('Phase 5D.1a front props are pointer-safe and separated from the playable controls',()=>{
  const css=readFileSync(new URL('../styles/prop-visibility-repair.css',import.meta.url),'utf8');
  assert.equal(css.includes('.rig-prop-shelf'),true);
  assert.equal(css.includes('pointer-events:none'),true);
  assert.equal(css.includes('padding-bottom:42px'),true);
});

test('Phase 5D.1a raises crates and gives practical lamps explicit physical parts',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  const css=readFileSync(new URL('../styles/prop-visibility-repair.css',import.meta.url),'utf8');
  assert.equal(html.includes('class="lamp-base"'),true);
  assert.equal(html.includes('class="lamp-pool"'),true);
  assert.equal(css.includes('bottom:12.5%'),true);
  assert.equal(css.includes('.lamp-arm'),true);
});

test('Phase 5D.1a improves disabled hardware visibility without enabling it',()=>{
  const css=readFileSync(new URL('../styles/prop-visibility-repair.css',import.meta.url),'utf8');
  assert.equal(css.includes('.hardware-button:disabled,.hardware-pad:disabled'),true);
  assert.equal(css.includes('opacity:.62'),true);
});

test('Phase 5D.1a keeps the saved-Lab startup protection in place',()=>{
  const source=readFileSync(new URL('../world/view-mode-controller.js',import.meta.url),'utf8');
  assert.equal(source.includes("saved === 'flat' ? 'flat' : 'booth'"),true);
  assert.equal(source.includes('Lab defaults closed for performance startup'),true);
});



test('Phase 5D.1c enforces authoritative hidden drawer visibility in CSS',()=>{
  const css=readFileSync(new URL('../styles/prop-visibility-repair.css',import.meta.url),'utf8');
  assert.equal(css.includes('.diagnostics-drawer[hidden]'),true);
  assert.equal(css.includes('display:none !important'),true);
});

test('Phase 5D.1c keeps the top Lab trigger synchronized with actual drawer authority',()=>{
  const source=readFileSync(new URL('../world/view-mode-controller.js',import.meta.url),'utf8');
  const drawer=readFileSync(new URL('../world/lab/diagnostics-drawer.js',import.meta.url),'utf8');
  assert.equal(source.includes("mode === 'lab' ? 'CLOSE LAB' : 'OPEN LAB'"),true);
  assert.equal(drawer.includes("this.openButton.textContent=this.opened?'CLOSE LAB':'OPEN LAB'"),true);
});

test('Phase 5D.1c promotes the front headphones and adds practical spill to the rig surface',()=>{
  const css=readFileSync(new URL('../styles/prop-visibility-repair.css',import.meta.url),'utf8');
  assert.equal(css.includes('.front-headphones{'),true);
  assert.equal(css.includes('translateX(-92px)'),true);
  assert.equal(css.includes('.physical-rig-frame.tactile-rig::after'),true);
});



test('Phase 5D.2 material pass adds CRT glass, reflection, and phosphor polish selectors',()=>{
  const css=readFileSync(new URL('../styles/cinematic-warehouse.css',import.meta.url),'utf8');
  assert.equal(css.includes('/* ---------- Phase 5D.2 — material + CRT polish ---------- */'),true);
  assert.equal(css.includes('.crt-screen::before'),true);
  assert.equal(css.includes('.crt-reflection{opacity:calc(var(--crt-reflection-opacity) + .04)'),true);
});

test('Phase 5D.2 strengthens tactile hardware material shading without changing authority',()=>{
  const css=readFileSync(new URL('../styles/cinematic-warehouse.css',import.meta.url),'utf8');
  assert.equal(css.includes('.hardware-deck,.hardware-mixer{'),true);
  assert.equal(css.includes('box-shadow:inset 0 0 52px #000,0 16px 34px #000c'),true);
  assert.equal(css.includes('No transport or authority changes'),false);
});

test('Phase 5D.2 material-polish history remains documented after later slices',()=>{
  const doc=readFileSync(new URL('../docs/PHASE5D2_MATERIAL_CRT_POLISH.md',import.meta.url),'utf8');
  assert.equal(doc.includes('Phase 5D.2'),true);
  assert.equal(doc.includes('Material + CRT Polish'),true);
});



test('Phase 5D.3 adds one pointer-inert ambient life layer with bounded room elements',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  const css=readFileSync(new URL('../styles/reactive-booth-life.css',import.meta.url),'utf8');
  assert.equal((html.match(/class="ambient-life-layer"/g)||[]).length,1);
  assert.equal((html.match(/class="haze-band /g)||[]).length,2);
  assert.equal(css.includes('.ambient-life-layer{position:absolute;inset:0;z-index:0;pointer-events:none'),true);
});

test('Phase 5D.3 speaker and rack life consume visual variables only',()=>{
  const css=readFileSync(new URL('../styles/reactive-booth-life.css',import.meta.url),'utf8');
  assert.equal(css.includes('var(--life-a)'),true);
  assert.equal(css.includes('var(--life-b)'),true);
  assert.equal(css.includes('.speaker-left:before'),true);
  assert.equal(css.includes('.console-right i:nth-of-type(1)'),true);
});

test('Phase 5D.3 preserves Effects Off and reduced-motion parity',()=>{
  const css=readFileSync(new URL('../styles/reactive-booth-life.css',import.meta.url),'utf8');
  assert.equal(css.includes('.crt-effects-off .ambient-life-layer{display:none!important}'),true);
  assert.equal(css.includes('@media(prefers-reduced-motion:reduce)'),true);
  assert.equal(css.includes('animation:none!important'),true);
});

test('Phase 5D.3 reactive-life history remains documented after later slices',()=>{
  const doc=readFileSync(new URL('../docs/PHASE5D3_REACTIVE_BOOTH_LIFE.md',import.meta.url),'utf8');
  assert.equal(doc.includes('Phase 5D.3'),true);
  assert.equal(doc.includes('Reactive Booth Life'),true);
});



test('Phase 5D.3a separates speaker and rack positioning lanes',()=>{
  const css=readFileSync(new URL('../styles/speaker-stack-separation.css',import.meta.url),'utf8');
  assert.equal(css.includes('.speaker-left{left:.7%}'),true);
  assert.equal(css.includes('.rack-left{left:8.5%'),true);
  assert.equal(css.includes('.rack{\n  top:48%'),true);
});

test('Phase 5D.3a preserves reactive speaker drivers while making them visible',()=>{
  const css=readFileSync(new URL('../styles/speaker-stack-separation.css',import.meta.url),'utf8');
  assert.equal(css.includes('.speaker-stack:before,.speaker-stack:after{will-change:transform,filter}'),true);
  assert.equal(css.includes('width:132px'),true);
});

test('Phase 5D.3a stylesheet is loaded after the existing visual layers',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal(html.includes('./styles/speaker-stack-separation.css'),true);
  assert.equal(html.includes('PB96-5D3a v1.2.1'),true);
});



test('Phase 6A.1 infers artist and title from common downloaded track filenames',()=>{
  assert.deepEqual(inferTrackMetadata('Mikey More Bounce - Warehouse Love.wav'),{artist:'Mikey More Bounce',title:'Warehouse Love'});
  assert.equal(inferTrackMetadata('Untitled_Suno_Groove.mp3').title,'Untitled Suno Groove');
});

test('Phase 6A.1 crate sorting and supported audio filters are bounded',()=>{
  assert.equal(sanitizeCrateSort('bpm'),'bpm');
  assert.equal(sanitizeCrateSort('chaos'),'recent');
  assert.equal(isSupportedAudioFile({name:'track.wav',type:''}),true);
  assert.equal(isSupportedAudioFile({name:'notes.txt',type:'text/plain'}),false);
});

test('Phase 6A.1 manifests sanitize metadata without pretending missing audio is playable',()=>{
  const manifest=sanitizeManifest({crates:[{id:'x',name:'My Playlist'}],tracks:[{fileName:'A - B.mp3',crateId:'x',bpm:96}]});
  assert.equal(manifest.crates.length,1);
  assert.equal(manifest.tracks[0].status,'missing-file');
  assert.equal(manifest.tracks[0].fileAvailable,false);
});

test('Phase 6A.1 HTML contains one local crate source and one multi-file importer',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal((html.match(/id="crtSourceLibrary"/g)||[]).length,1);
  assert.equal((html.match(/id="crateFileInput"/g)||[]).length,1);
  assert.equal(html.includes('multiple=""'),true);
  assert.equal(html.includes('value="library"'),true);
});

test('Phase 6A.1 source router accepts the crate library and declares its shortcut',()=>{
  assert.equal(sanitizeCrtSource('library'),'library');
  const source=readFileSync(new URL('../world/crt/source-router.js',import.meta.url),'utf8');
  assert.equal(source.includes("event.code==='KeyY'"),true);
  assert.equal(source.includes("this.libraryPanel.hidden=next!=='library'"),true);
});

test('Phase 6A.1 crate layer enters decks only through the canonical loadFile method',()=>{
  const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const crate=readFileSync(new URL('../library/suno-crate-bridge.js',import.meta.url),'utf8');
  assert.equal(app.includes('await system.decks[deckId].loadFile(file)'),true);
  assert.equal(crate.includes('AudioWorkletNode'),false);
  assert.equal(crate.includes('postMessage({ type: \'region\''),false);
});



test('Phase 6A.2 prep metadata is bounded and tags are normalized',()=>{
  const prep=sanitizeTrackPrep({favorite:1,rating:9,energy:0,bpm:500,tags:' Jungle, jungle, Funk , Warehouse ',notes:'x'.repeat(400)});
  assert.equal(prep.favorite,true);
  assert.equal(prep.rating,5);
  assert.equal(prep.energy,3);
  assert.equal(prep.bpm,null);
  assert.deepEqual(prep.tags,['jungle','funk','warehouse']);
  assert.equal(prep.notes.length,300);
  assert.deepEqual(normalizeTrackTags(['A','a',' B ']),['a','b']);
});

test('Phase 6A.2 tempo-family distance recognizes half-time and double-time matches',()=>{
  const half=tempoFamilyDistance(70.8,141.6);
  const double=tempoFamilyDistance(141.6,70.8);
  assert.equal(half.factor,2);
  assert.equal(half.distance,0);
  assert.equal(double.factor,.5);
  assert.equal(double.distance,0);
});

test('Phase 6A.2 Smart Set excludes missing files and respects favorite-only planning',()=>{
  const tracks=[
    {id:'a',title:'A',bpm:96,fileAvailable:true,favorite:true,rating:5,energy:2},
    {id:'b',title:'B',bpm:97,fileAvailable:true,favorite:false,rating:5,energy:3},
    {id:'c',title:'C',bpm:48,fileAvailable:true,favorite:true,rating:4,energy:4},
    {id:'d',title:'D',bpm:96,fileAvailable:false,favorite:true,rating:5,energy:5},
  ];
  const set=selectSmartSetTracks(tracks,{targetBpm:96,tolerance:3,count:4,favoritesOnly:true,energyProfile:'rise'});
  assert.deepEqual(set.map((track)=>track.id).sort(),['a','c']);
});

test('Phase 6A.2 quiet-deck selection follows crossfader audibility and empty-deck state',()=>{
  assert.equal(chooseQuietDeck(-1,{trackA:true,trackB:true,playingA:true,playingB:true}),'B');
  assert.equal(chooseQuietDeck(1,{trackA:true,trackB:true,playingA:true,playingB:true}),'A');
  assert.equal(chooseQuietDeck(0,{trackA:false,trackB:true,playingA:false,playingB:true}),'A');
});

test('Phase 6A.2 energy candidate remains bounded from silent to loud audio',()=>{
  assert.equal(estimateEnergyFromMono(new Float32Array(200)),1);
  const loud=new Float32Array(200).fill(.5);
  assert.equal(estimateEnergyFromMono(loud),5);
});

test('Phase 6A.2 manifest v2 preserves prep metadata without file authority',()=>{
  const manifest=sanitizeManifest({tracks:[{fileName:'Mikey - Test.wav',favorite:true,rating:4,energy:5,tags:['Jungle'],notes:'keeper',bpm:96}]});
  assert.equal(manifest.version,2);
  assert.equal(manifest.tracks[0].favorite,true);
  assert.equal(manifest.tracks[0].rating,4);
  assert.equal(manifest.tracks[0].energy,5);
  assert.deepEqual(manifest.tracks[0].tags,['jungle']);
  assert.equal(manifest.tracks[0].fileAvailable,false);
});

test('Phase 6A.2 HTML exposes one Smart Set planner, batch bar, and opt-in auto-feed',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal((html.match(/id="crateBuildSmartSet"/g)||[]).length,1);
  assert.equal((html.match(/class="crate-batch-bar"/g)||[]).length,1);
  assert.equal((html.match(/id="crateAutoFeed"/g)||[]).length,1);
  assert.equal(html.includes('PB96-6A2 v1.4.0'),true);
});

test('Phase 6A.2 queue integration remains downstream of canonical deck loading',()=>{
  const app=readFileSync(new URL('../app.js',import.meta.url),'utf8');
  const crate=readFileSync(new URL('../library/suno-crate-bridge.js',import.meta.url),'utf8');
  assert.equal(app.includes('sunoCrate.handleAutoMixComplete'),true);
  assert.equal(app.includes('await system.decks[deckId].loadFile(file)'),true);
  assert.equal(crate.includes('AudioWorkletNode'),false);
  assert.equal(crate.includes('AUTO-FEED ARMED — REQUIRES STOP OLD DECK'),true);
});



test('Phase 6A.3 audit distinguishes healthy, missing, review, and trash records',()=>{
  assert.equal(auditTrackRecord({fileAvailable:true,blobSize:100,size:100}).state,'healthy');
  assert.equal(auditTrackRecord({fileAvailable:false,blobSize:0}).state,'missing');
  assert.equal(auditTrackRecord({fileAvailable:true,blobSize:99,size:100}).state,'review');
  assert.equal(auditTrackRecord({deletedAt:1}).state,'trash');
});

test('Phase 6A.3 queue reconciliation removes unavailable and deleted entries',()=>{
  const result=reconcileQueue(['a','b','c','a'],[
    {id:'a',fileAvailable:true,blobSize:1,size:1},
    {id:'b',fileAvailable:false,blobSize:0},
    {id:'c',fileAvailable:true,blobSize:1,size:1,deletedAt:1},
  ]);
  assert.deepEqual(result.queue,['a']);
  assert.equal(result.removed.length,2);
});

test('Phase 6A.3 recovery manifest preserves preparation and queue metadata without file authority',()=>{
  const manifest=sanitizeRecoveryManifest({tracks:[{id:'t',fileName:'Mikey - Tune.wav',fileAvailable:true,bpm:96,tags:['Jungle']}],queue:['t'],receipts:[{type:'import',total:1,imported:1}]});
  assert.equal(manifest.version,3);assert.equal(manifest.kind,'backspin96-library-recovery');
  assert.equal(manifest.tracks[0].fileAvailable,false);assert.deepEqual(manifest.queue,['t']);assert.equal(manifest.receipts.length,1);
});

test('Phase 6A.3 repair matching prefers exact hashes then filename and size',()=>{
  assert.equal(matchRepairCandidate({hash:'x'},{hash:'x'}),100);
  assert.equal(matchRepairCandidate({normalizedName:'a.wav',size:10},{normalizedName:'a.wav',size:10}),90);
  assert.equal(matchRepairCandidate({normalizedName:'a.wav',size:10},{normalizedName:'a.wav',size:20}),70);
});

test('Phase 6A.3 health summary reports queue orphans and reversible trash',()=>{
  const summary=summarizeLibraryHealth([
    {id:'a',fileAvailable:true,blobSize:1,size:1},
    {id:'b',fileAvailable:false,blobSize:0},
    {id:'c',fileAvailable:true,blobSize:1,size:1,deletedAt:1},
  ],['a','b','missing'],[]);
  assert.equal(summary.healthy,1);assert.equal(summary.missing,1);assert.equal(summary.trash,1);assert.equal(summary.queueOrphans,2);
});

test('Phase 6A.3 import receipts clamp counts and bound names',()=>{
  const receipt=buildImportReceipt({type:'repair',total:2,repaired:1,failed:1,names:['a.wav']});
  assert.equal(receipt.type,'repair');assert.equal(receipt.repaired,1);assert.equal(receipt.names[0],'a.wav');
});

test('Phase 6A.3 UI declares recovery desk controls and reversible trash',()=>{
  const html=readFileSync(new URL('../index.html',import.meta.url),'utf8');
  assert.equal(html.includes('id="crateScanLibrary"'),true);
  assert.equal(html.includes('id="crateRepairInput"'),true);
  assert.equal(html.includes('id="crateExportRecovery"'),true);
  assert.equal(html.includes('id="crateReliabilityPanel"'),true);
  assert.equal(html.includes('id="crateBatchTrash"'),true);
});

const failed = results.filter((result) => !result.ok);
console.log(`\n${results.length - failed.length}/${results.length} tests passed.`);
if (failed.length) process.exit(1);
