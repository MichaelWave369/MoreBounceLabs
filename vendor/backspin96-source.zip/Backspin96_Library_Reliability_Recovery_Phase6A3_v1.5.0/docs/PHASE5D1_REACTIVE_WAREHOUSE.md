# Phase 5D.1 — Reactive Warehouse Props & Polish

## Added in this slice

1. Prop-language integration based on the approved Backspin poster reference: record crates, sleeve props, rave flyers, headphones, cassette culture, and small desk clutter.
2. Lived-in sticker / decal pass on the physical rig and room.
3. Warm practical lamps to add occupied-booth atmosphere.
4. Reactive polish powered by CSS variables fed from the visual-state bridge: channel-specific booth glow, practical intensity, and state classes for recording / automix / deck-playing.
5. Performance-Rig framing keeps decorative props subdued so the hands still dominate.

## Exit checks

- Props do not cover the physical controls.
- Rig mode reduces the prominence of decorative props.
- Effects Off and Safe Flat still work.
- Audio core files remain untouched.
