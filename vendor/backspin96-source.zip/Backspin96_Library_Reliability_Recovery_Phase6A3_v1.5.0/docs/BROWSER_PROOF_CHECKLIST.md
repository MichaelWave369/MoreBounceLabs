# Phase 5C.2 Browser Proof Checklist

1. Start with `python serve.py` and open `http://127.0.0.1:8080`.
2. Confirm Booth mode shows the dedicated CRT Performance Monitor rather than a duplicate full mixer.
3. Start dual audio, load two tracks, and verify the CRT waveforms, BPM, meters, progress, crossfader, Auto Mix, and recorder states follow the canonical state.
4. Scratch, pitch, EQ, filter, cue, loop, crossfade, and Auto Mix from the physical rig.
5. Open Lab. Confirm the drawer docks below the instrument and does not cover Deck A, Deck B, or the mixer.
6. Toggle COMPACT/EXPAND. Confirm the booth refits and audio continues.
7. Switch CRT sources to Signal Tunnel and Health, then return to Performance.
8. Enter Safe Flat. Confirm the complete canonical interface appears regardless of the last CRT source.
9. Kill/recover visual pressure and confirm visual protection cannot interrupt audio.
10. Export evidence and confirm build slice 5C.2, drawer height/state, fit, CRT source, and visual quality are present.


## Phase 5C.3 cinematic warehouse proof

- [ ] Full Booth is the initial framing unless a prior framing preference exists.
- [ ] Lab is closed on a fresh Booth startup.
- [ ] Performance Rig enlarges the rig and reduces CRT share without audio restart.
- [ ] Alt+Shift+P/T/H switches the CRT source.
- [ ] CRT source transition does not affect transport or audio state.
- [ ] Effects Off removes expendable haze/depth polish while retaining controls.
- [ ] Safe Flat retains the complete canonical interface.
