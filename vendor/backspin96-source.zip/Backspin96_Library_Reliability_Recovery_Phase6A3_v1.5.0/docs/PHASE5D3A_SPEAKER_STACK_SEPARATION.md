# Phase 5D.3a — Speaker Stack Separation

The real-browser screenshot exposed a side-stage composition bug: the existing three-unit rack towers occupied the same coordinates as the PA speaker cabinets and visually masked most of the woofers.

## Repair

- PA cabinets now own the outermost left/right lanes.
- Rack towers move inward and lower, adjacent to rather than on top of the cabinets.
- Small side consoles remain below the speaker lane.
- Reactive speaker-cone motion remains presentation-only and now applies to visible drivers.
- Performance Rig and Lab still reduce the prominence of environmental equipment.
