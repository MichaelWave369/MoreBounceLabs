# Core Integrity — Phase 6A.2

Protected audio/performance files compared against Phase 6A.1:

- `audio/backspin-processor.js` — UNCHANGED
- `audio/engine.js` — UNCHANGED
- `audio/mixer-law.js` — UNCHANGED
- `audio/protocol.js` — UNCHANGED
- `audio/region-gate.js` — UNCHANGED
- `audio/track-provider.js` — UNCHANGED
- `performance/automix.js` — UNCHANGED
- `performance/tempo.js` — UNCHANGED
