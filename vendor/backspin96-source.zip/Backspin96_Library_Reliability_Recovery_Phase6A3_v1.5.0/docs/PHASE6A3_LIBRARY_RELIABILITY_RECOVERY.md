# Phase 6A.3 — Library Reliability & Recovery

## Purpose

Harden the local Suno crate library so a large catalog can survive interrupted imports, missing blobs, stale queue entries, accidental removals, and metadata migrations.

## Added

- Persistent receipts for import, repair, audit, and recovery sessions
- Integrity scan with healthy / missing / review / trash states
- Repair-file workflow that restores known missing records without losing prep metadata
- Recovery manifest v3
- IndexedDB queue journal plus previous-queue restore
- Reversible trash and explicit purge
- Queue orphan reconciliation

## Authority boundary

A recovery record cannot make a missing file playable. Only a verified local Blob can pass through the canonical deck load path.
