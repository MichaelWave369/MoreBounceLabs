# Phase 3 Performance Deck — Architecture Note

## Candidate purpose

PB96-P3 v0.4.0 adds musical performance state around the already-proven dual AudioWorklet spine without allowing optional intelligence, visual rendering, recording, or monitor routing to enter the sample-time control path.

## Timing-lane placement

### Sample time

- PCM region consumption and interpolation
- Pitch and scratch transport
- Loop boundary enforcement
- Deck output generation

### Performance time

- Hot-cue set, clear, and trigger commands
- Grid-anchor selection
- Loop-length requests
- Mixer, PFL, cue blend, and echo controls
- Phrase Auto Mix state machine and operator veto
- Recording start/stop control

### Office time

- Candidate BPM analysis
- Half-time/double-time family selection
- Evidence aggregation
- Visual pressure and fault-injection reporting

## Smart tempo family

A detected BPM value is not assumed to be the only musically useful interpretation. Smart sync evaluates a bounded family of candidate tempos and chooses the smallest lawful pitch correction that fits the ±16% deck range. The selected family factor becomes part of the deck's candidate grid state so live BPM, loop length, and phrase duration remain internally coherent.

When no family fits the range, smart mode returns `blend-only` and does not push the target deck to an arbitrary pitch limit. Exact mode retains the prior clamp behavior for deliberate testing.

## Loop contract

The main thread calculates a loop range in source frames using the deck's candidate grid BPM and downbeat offset. The AudioWorklet receives an explicit `set-loop` command containing start, end, and beat count. The worklet wraps its source frame inside that interval and requests coverage around both loop boundaries. Loop state is included in telemetry.

## Monitor contract

Each channel has a pre-fader cue send after trim, EQ, and filter. It bypasses the channel fader, crossfader, protected master bus, and recorder. A cue/master audition blend is applied only on the physical browser output path. This preserves a clean recording while acknowledging that the browser baseline generally cannot select an independent headphone device.

## Echo contract

Each channel exposes a bounded post-fader send to a shared delay. Delay time is clamped to 40–900 ms and feedback to 0–0.82. Echo return enters the protected mix bus before the limiter. The tail-kill command closes channel sends and temporarily collapses feedback before restoring the selected feedback setting.

## Recording contract

The recorder receives the post-limiter, post-master signal before the audition-only booth gain. `MediaRecorder` writes acknowledged chunks outside the AudioWorklet. Stopping produces a locally downloaded browser-supported audio container. PFL monitor audio is excluded.

## Claim boundary

This build proves source-level architecture and invariant behavior. It does not yet prove musical BPM accuracy, sample-accurate downbeat detection, key-locked time stretching, independent multi-device output, or universal recording codec support. Those require named browser/hardware benches.
