# Phase 5D.2 — Material + CRT Polish

This slice is a visual-only polish pass intended to make the booth feel more like a photographed retro hardware setup while preserving the existing playable architecture.

## Goals

- Make the CRT shell feel denser and more physical
- Increase glass curvature, phosphor glow, and subtle reflection layering
- Improve material separation between metal, plastic, and painted hardware
- Spread the warm practicals across the desk and nearby surfaces more convincingly
- Preserve every existing canonical control binding and performance authority rule

## Scope

- CSS-only presentation/material refinement
- Build/version labeling updated for traceability
- No changes to transport law, deck routing, drawer authority, or control IDs
