# Core integrity: Phase 5C.2 vs Phase 5C.1

- PASS `audio/backspin-processor.js` sha256=824b812a0b9c2ab04df02675304388f0f47453903e31781063dc4dd98e0fb3b3
- PASS `audio/engine.js` sha256=f4997a500fb09a13db54e3a449891222dac7c322e1cc774db17860f234ee6156
- PASS `audio/mixer-law.js` sha256=8534736b4ac5d71079a9400c838c02e27f7a68eb695b2bf30a15beeaad1d7700
- PASS `audio/protocol.js` sha256=48bf987d9c1190484e776690aed9fd9406125a69c22c3f6c11d69b1a9402d556
- PASS `audio/region-gate.js` sha256=b3b6b29e2bfcaf0d8876438d29bd8575133c9b42b48ba54145de6a14595a44e1
- PASS `audio/track-provider.js` sha256=788d7786199f27a6a9b30ad916a0a3f2d0b3538e329b939fa5ae5efb5059e356
- PASS `performance/tempo.js` sha256=625ccf38d66e536c44e0a75fe5aa2330d838a5fee5a71dddea8d3c5ba6f672a4
- PASS `performance/automix.js` sha256=4e093c15b7b7949f5221a3e64d5ed1a5d4137733d905c7b5a721c236f512df11
