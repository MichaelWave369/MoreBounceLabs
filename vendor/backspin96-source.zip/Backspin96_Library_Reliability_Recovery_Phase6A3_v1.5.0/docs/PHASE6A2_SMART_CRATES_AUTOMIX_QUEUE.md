# Phase 6A.2 — Smart Crates & Auto-Mix Queue

## Build decisions

1. The local file remains the only audio authority; Suno links remain optional provenance metadata.
2. Track prep metadata is persistent but never silently overrides the operator.
3. Smart Set planning uses BPM-family distance and an optional energy arc. It produces a queue, not an automatic performance.
4. PREP QUIET DECK chooses the less audible / unused deck and uses the canonical load path.
5. AUTO-FEED is opt-in and only runs after a completed Auto Mix when Stop Old Deck is enabled.
6. The protected AudioWorklet, buffer gate, mixer law, tempo engine, and Auto Mix law remain unchanged.

## Exit checks

- Legacy Phase 6A.1 IndexedDB libraries open without migration loss.
- Manifest v2 preserves favorites, ratings, energy, tags, notes, and manual BPM.
- Smart Set helpers are deterministic and BPM-family aware.
- Crate code still enters the decks only through `loadFile()`.
