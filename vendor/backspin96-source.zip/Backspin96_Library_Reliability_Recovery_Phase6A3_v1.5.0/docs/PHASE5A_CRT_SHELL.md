# Phase 5A — CRT Shell Architecture Note

## Status

Candidate implementation slice built on 05 August 2026. The working Phase 3 audio and control baseline is preserved.

## Two-plane boundary

### Protected performance plane

- AudioWorklet deck kernels
- predictive region pools and generation gates
- canonical deck, mixer, cue, loop, sync, Auto Mix, monitor, echo, and recording state
- normalized input events

### Degradable visual plane

- CRT shell and effects
- warehouse backdrop
- physical rig preview
- visual quality policy
- local visual preferences

The visual plane receives bounded snapshots. It never writes AudioWorklet state and never treats animation as evidence that transport changed.

## Visual State Bridge

The bridge accepts a sequence-stamped snapshot containing:

- deck platter angle, playing state, mode, BPM, live BPM, and loop lamp state;
- channel/master meter decibels;
- crossfader position;
- recording and Auto Mix lamps;
- audio-underrun counters for protection decisions.

It clamps values, rejects backward sequence movement, paints no faster than approximately 33 Hz, and updates only presentation elements.

## Quality ladder

1. Full CRT
2. Clean CRT
3. Effects Off
4. Safe Flat

Auto Protect may lower the tier. It does not automatically return from Safe Flat to the booth; restoration is an operator decision.

## Stop condition

Phase 5B must not begin until the operator confirms that:

- normal scratch and mixing remain intact in CRT Surface;
- Safe Flat works while audio is active;
- the physical preview mirrors the real state without cross-deck contamination;
- effect tuning does not make essential state unreadable;
- renderer kill cannot restart or interrupt audio.
