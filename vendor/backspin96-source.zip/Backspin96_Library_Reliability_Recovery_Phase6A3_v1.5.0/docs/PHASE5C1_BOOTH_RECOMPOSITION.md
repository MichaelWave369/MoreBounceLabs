# Backspin '96 Phase 5C.1 — Booth Recomposition

## Build decision

Phase 5C.1 changes presentation hierarchy only. The proven Phase 5B instrument remains canonical.

## Delivered

- One-viewport desktop Booth composition
- Compact status rail and health lamps
- Booth, Lab, and Safe Flat modes
- Diagnostics drawer that reparents existing nodes instead of rebuilding state
- CRT source router with Performance, Tunnel, and Health sources
- Responsive fit policy and explicit narrow-screen fallback
- Evidence additions for mode, source, drawer, viewport, DPR, and fit policy

## Stop rule

Do not add the complete warehouse asset shell until Booth mode, Lab reveal/hide, source switching, and Safe Flat preserve all deck and mixer behavior in the operator browser.
