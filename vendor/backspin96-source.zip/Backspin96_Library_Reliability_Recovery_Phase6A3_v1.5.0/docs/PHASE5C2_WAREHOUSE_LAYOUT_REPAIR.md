# Phase 5C.2 — Warehouse Room & Layout Repair

## Build decisions

1. Diagnostics moved from a right overlay to a bottom dock.
2. Booth fit is calculated from the remaining viewport after the dock height is removed.
3. The physical rig is the primary control surface in Booth mode.
4. The CRT Performance Monitor is a presentation-only mirror. It has no transport authority.
5. The canonical Phase 3 UI remains preserved for Safe Flat and as the target of tactile hardware bindings.
6. Warehouse dressing is expendable and quality-managed.

## Exit checks

- No deck or mixer area is covered by the Lab dock on the reference desktop viewport.
- Opening/closing/compacting the Lab causes a fit recalculation.
- Safe Flat remains complete after any CRT source selection.
- Physical controls continue to target the original canonical IDs.
- Audio core integrity comparison remains clean.
