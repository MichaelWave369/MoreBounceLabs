# Phase 5B — Tactile Hardware Architecture Note

## Status

Candidate implementation slice built on 05 August 2026. The operator-approved Phase 5A CRT shell remains the visual host, and the proven Phase 3 performance state remains canonical.

## Control boundary

The foreground hardware does not own deck or mixer state. Every hardware control uses one explicit binding:

```text
physical control → canonical DOM control/event → bounded performance control → audio system
```

The hardware adapter may press a canonical button or assign a lawful range value and dispatch the same input/change event already handled by the working app. It may not call AudioWorklet internals, write PCM, forge telemetry, or infer that an animation changed sound.

## Shared scratch path

Both the CRT platter and foreground platter enter the same scratch handler. The handler receives the active surface for geometry and pointer capture, then emits the same deck jog ratio and release contract. Deck A and Deck B retain independent gestures and timelines.

## Control inventory

### Per deck

- play/pause
- cue zero
- tap BPM
- sync from other deck
- load local file
- physical platter scratch
- pitch
- grid anchor
- hot cues 1–4
- 1-beat and 4-beat loops
- PFL

### Mixer

- trim / high / mid / low / filter / echo per channel
- channel fader per channel
- master level
- crossfader curve
- cue level and cue/master blend
- crossfader and hard cuts
- Auto Mix and operator veto
- recording start/stop
- echo-tail kill
- panic stop

## Visual State Bridge additions

- physical platter angle remains presentation-only;
- tonearms move between stopped, playing, and scratch indication;
- foreground play lamps, BPM readouts, meters, recording lamp, and Auto Mix lamp follow canonical state;
- foreground range controls periodically mirror canonical values without dispatching events.

## Failure behavior

- Missing target IDs disable only the affected physical control.
- Safe Flat removes the foreground hardware and leaves the canonical instrument available.
- Renderer or quality faults may remove decorative visuals but do not remove the canonical control path.
- A hardware adapter error cannot legally mutate sample-time state directly.

## Exit gate

Advance toward the room/warehouse slice only after a named browser run confirms:

- physical and CRT platter scratches are both playable;
- all foreground controls change the real audible state;
- no cross-deck action leakage occurs;
- manual crossfader motion vetoes Auto Mix;
- Safe Flat remains immediate;
- no new underruns appear in a matched Phase 5A/5B session.
