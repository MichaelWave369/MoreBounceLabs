# Phase 5C.3 protected-core integrity

All protected audio, timing, analysis, sync, and Auto Mix files are byte-identical to Phase 5C.2.

| File | SHA-256 | Match |
|---|---|---|
| `audio/backspin-processor.js` | `824b812a0b9c2ab04df02675304388f0f47453903e31781063dc4dd98e0fb3b3` | YES |
| `audio/engine.js` | `f4997a500fb09a13db54e3a449891222dac7c322e1cc774db17860f234ee6156` | YES |
| `audio/mixer-law.js` | `8534736b4ac5d71079a9400c838c02e27f7a68eb695b2bf30a15beeaad1d7700` | YES |
| `audio/protocol.js` | `48bf987d9c1190484e776690aed9fd9406125a69c22c3f6c11d69b1a9402d556` | YES |
| `audio/region-gate.js` | `b3b6b29e2bfcaf0d8876438d29bd8575133c9b42b48ba54145de6a14595a44e1` | YES |
| `audio/track-provider.js` | `788d7786199f27a6a9b30ad916a0a3f2d0b3538e329b939fa5ae5efb5059e356` | YES |
| `performance/automix.js` | `4e093c15b7b7949f5221a3e64d5ed1a5d4137733d905c7b5a721c236f512df11` | YES |
| `performance/tempo.js` | `625ccf38d66e536c44e0a75fe5aa2330d838a5fee5a71dddea8d3c5ba6f672a4` | YES |
| `analysis/bpm-core.js` | `70a5b4579277de3c911715775553efa4ac07ab36a0d4de081c0c58d919244f37` | YES |
| `analysis/bpm-worker.js` | `b6f9e4ce2cf7e76d2fde6a5214dc011d37a9d28a4d6fb86d0d3142e4ecb95cc4` | YES |
