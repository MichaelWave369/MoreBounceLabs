# Phase 5D.1a — Prop Visibility & Practical Lighting Repair

## Repair goals

1. Bring the record crates and sleeves into the visible lower side margins.
2. Put flyers and headphones on a dedicated pointer-safe front-bezel strip rather than behind the rig.
3. Turn the small glowing practicals into readable lamps with shades, articulated arms, bases, and warm light pools.
4. Improve inactive hardware contrast without pretending disabled controls are available.
5. Preserve the startup rule that Booth begins with Lab closed.

## Authority boundary

All new props are pointer-inert. They have no action or range targets and cannot write to deck, mixer, or AudioWorklet state.
