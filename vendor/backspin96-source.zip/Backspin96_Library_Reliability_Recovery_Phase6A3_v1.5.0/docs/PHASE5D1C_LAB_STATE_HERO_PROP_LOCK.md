# Phase 5D.1c — Lab State Repair & Hero Prop Lock

This repair slice resolves the screenshot-proven mismatch where the top rail said the Lab was closed while the docked drawer was still visible. It also strengthens the most important foreground prop and makes the warm practicals visibly illuminate nearby hardware.

## Main changes

- Enforced `.diagnostics-drawer[hidden] { display:none !important; }`.
- The top-right drawer trigger now toggles and truthfully reads OPEN LAB or CLOSE LAB.
- Drawer open/closed state is synchronized back to presentation mode authority.
- Front headphones promoted and repositioned as a visible hero prop.
- Crate labels raised for better readability.
- Practical-lamp spill increased across left/right deck surfaces.
