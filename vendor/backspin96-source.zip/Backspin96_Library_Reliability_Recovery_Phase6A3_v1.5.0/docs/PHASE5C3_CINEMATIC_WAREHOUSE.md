# Phase 5C.3 — Cinematic Warehouse Depth & Performance Framing

## Build decisions

1. The approved cinematic target is used as an art-direction north star, not as an image pasted behind the app.
2. Room depth is constructed from original DOM/CSS layers and remains expendable.
3. Full Booth and Performance Rig are presentation-only framing presets.
4. Lab defaults closed because performance is the default operating posture.
5. The CRT is a source-routed information monitor; physical hardware remains the Booth control surface.
6. Safe Flat preserves the complete canonical control interface.

## Exit checks

- Framing changes do not restart audio or create duplicate control state.
- Source hotkeys select only known visual sources.
- Lab starts closed in Booth mode.
- Room depth and material polish disappear safely under Effects Off or Safe Flat.
- Protected core files remain byte-identical to Phase 5C.2.
