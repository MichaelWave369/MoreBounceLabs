# Phase 5D.1b — Prop Anchoring & Practical Warmth

This repair slice focuses on compositional visibility rather than adding more prop types.

## Main changes

- Raised both record crates higher into the side framing lanes.
- Brought flyers and edge clutter into visible desk/front-bezel zones.
- Repositioned the headphones so they read as a hero prop.
- Enlarged lamp shades, visible armatures, and warm light pools.
- Improved offline readability for the physical control surface.
- Made props recede when Lab opens or when Performance Rig framing is selected.

## Intent

Keep the lived-in warehouse vibe, but make sure the user can actually see it in the real booth framing.
