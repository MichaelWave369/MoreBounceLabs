# Phase 6A.1 — Suno Crate Bridge

## Architecture

The Suno Crate Bridge is a local-first library layer. Downloaded audio is imported by the operator and stored in IndexedDB as a Blob alongside metadata. Optional Suno song or playlist links are stored only as provenance metadata. They are never treated as the performance audio transport.

## Features

- Multi-file audio import
- SHA-256 deduplication
- Persistent crates and optional source links
- Search, sort, preview, queue, Load A, and Load B
- Background BPM and duration analysis
- Portable JSON manifest export/import
- Dedicated CRT input 4: CRATE LIBRARY

## Safety boundary

The crate layer calls the existing canonical `DeckEngine.loadFile()` method. It does not write PCM directly to the worklet, alter region ownership, or create a second deck timeline.
