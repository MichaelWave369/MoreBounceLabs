import { detectBpmFromMono } from '../analysis/bpm-core.js';
import { auditTrackRecord, summarizeLibraryHealth, reconcileQueue, buildImportReceipt, matchRepairCandidate, sanitizeRecoveryManifest } from './library-reliability.js';

const DB_NAME = 'backspin96-suno-crates-v1';
const DB_VERSION = 2;
const QUEUE_KEY = 'backspin96.crate-queue.v1';
const ACTIVE_CRATE_KEY = 'backspin96.active-crate.v1';
const AUTO_FEED_KEY = 'backspin96.crate-auto-feed.v1';
const SORTS = new Set(['recent', 'title', 'artist', 'bpm', 'duration', 'rating', 'energy', 'played']);
const AUDIO_EXT = /\.(mp3|wav|m4a|aac|ogg|oga|flac|webm)$/i;
const DEFAULT_CRATE = { id: 'suno-imports', name: 'SUNO IMPORTS', sourceUrl: '', createdAt: 0 };

const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));

export function sanitizeCrateSort(value) {
  return SORTS.has(value) ? value : 'recent';
}

export function normalizeFilename(value = '') {
  return String(value).trim().toLowerCase().replace(/\s+/g, ' ');
}

export function inferTrackMetadata(filename = '') {
  const base = String(filename).replace(/\.[^.]+$/, '').replace(/[_]+/g, ' ').replace(/\s+/g, ' ').trim();
  const parts = base.split(/\s+-\s+/);
  if (parts.length >= 2) return { artist: parts.shift().trim() || 'UNKNOWN ARTIST', title: parts.join(' - ').trim() || base };
  return { artist: 'MIKEY / SUNO', title: base || 'UNTITLED TRACK' };
}

export function isSupportedAudioFile(file) {
  return Boolean(file && (String(file.type || '').startsWith('audio/') || AUDIO_EXT.test(String(file.name || ''))));
}

export function normalizeTrackTags(value) {
  const list = Array.isArray(value) ? value : String(value || '').split(',');
  return [...new Set(list.map((tag) => String(tag).trim().toLowerCase()).filter(Boolean))].slice(0, 12);
}

export function sanitizeTrackPrep(input = {}) {
  const bpmValue = Number(input.bpm);
  return {
    favorite: Boolean(input.favorite),
    rating: Math.round(clamp(input.rating, 0, 5)),
    energy: Math.round(clamp(input.energy || 3, 1, 5)),
    tags: normalizeTrackTags(input.tags),
    notes: String(input.notes || '').slice(0, 300),
    bpm: Number.isFinite(bpmValue) && bpmValue >= 30 && bpmValue <= 260 ? Number(bpmValue.toFixed(2)) : null,
  };
}

export function estimateEnergyFromMono(mono) {
  if (!mono?.length) return 3;
  const stride = Math.max(1, Math.floor(mono.length / 200_000));
  let sum = 0;
  let count = 0;
  for (let index = 0; index < mono.length; index += stride) {
    const sample = Number(mono[index]) || 0;
    sum += sample * sample;
    count += 1;
  }
  const rms = Math.sqrt(sum / Math.max(1, count));
  if (rms < 0.035) return 1;
  if (rms < 0.07) return 2;
  if (rms < 0.13) return 3;
  if (rms < 0.22) return 4;
  return 5;
}

export function tempoFamilyDistance(candidateBpm, targetBpm) {
  const candidate = Number(candidateBpm);
  const target = Number(targetBpm);
  if (!Number.isFinite(candidate) || !Number.isFinite(target) || candidate <= 0 || target <= 0) {
    return { distance: Infinity, factor: 1, normalizedBpm: null };
  }
  const families = [0.5, 1, 2].map((factor) => ({ factor, normalizedBpm: candidate * factor }));
  families.sort((a, b) => Math.abs(a.normalizedBpm - target) - Math.abs(b.normalizedBpm - target));
  return { ...families[0], distance: Math.abs(families[0].normalizedBpm - target) };
}

function targetEnergyForStep(profile, index, count) {
  const progress = count <= 1 ? 0.5 : index / (count - 1);
  if (profile === 'rise') return 1 + progress * 4;
  if (profile === 'cooldown') return 5 - progress * 4;
  if (profile === 'steady') return 3;
  return null;
}

export function selectSmartSetTracks(tracks = [], options = {}) {
  const targetBpm = clamp(options.targetBpm || 96, 30, 260);
  const tolerance = clamp(options.tolerance ?? 8, 0, 64);
  const count = Math.round(clamp(options.count || 8, 1, 64));
  const profile = ['rise', 'cooldown', 'steady', 'mixed'].includes(options.energyProfile) ? options.energyProfile : 'mixed';
  const favoritesOnly = Boolean(options.favoritesOnly);
  const excluded = new Set(options.excludeIds || []);
  const candidates = tracks.filter((track) => {
    if (!track?.fileAvailable || excluded.has(track.id) || !Number.isFinite(Number(track.bpm))) return false;
    if (favoritesOnly && !track.favorite) return false;
    return tempoFamilyDistance(track.bpm, targetBpm).distance <= tolerance;
  });
  const selected = [];
  const remaining = [...candidates];
  let currentBpm = targetBpm;
  while (selected.length < count && remaining.length) {
    const energyTarget = targetEnergyForStep(profile, selected.length, count);
    remaining.sort((a, b) => {
      const da = tempoFamilyDistance(a.bpm, currentBpm);
      const db = tempoFamilyDistance(b.bpm, currentBpm);
      const energyA = energyTarget == null ? 0 : Math.abs((Number(a.energy) || 3) - energyTarget) * 1.3;
      const energyB = energyTarget == null ? 0 : Math.abs((Number(b.energy) || 3) - energyTarget) * 1.3;
      const qualityA = (a.favorite ? -2 : 0) - (Number(a.rating) || 0) * 0.35 + (Number(a.playCount) || 0) * 0.01;
      const qualityB = (b.favorite ? -2 : 0) - (Number(b.rating) || 0) * 0.35 + (Number(b.playCount) || 0) * 0.01;
      return (da.distance + energyA + qualityA) - (db.distance + energyB + qualityB) || String(a.title).localeCompare(String(b.title));
    });
    const next = remaining.shift();
    selected.push(next);
    currentBpm = tempoFamilyDistance(next.bpm, currentBpm).normalizedBpm || currentBpm;
  }
  return selected;
}

export function chooseQuietDeck(crossfader, state = {}) {
  const value = clamp(crossfader, -1, 1);
  if (value <= -0.2) return 'B';
  if (value >= 0.2) return 'A';
  if (!state.trackA) return 'A';
  if (!state.trackB) return 'B';
  if (!state.playingA) return 'A';
  if (!state.playingB) return 'B';
  return 'B';
}

export function sanitizeManifest(input = {}) {
  const crates = Array.isArray(input.crates) ? input.crates.filter((crate) => crate && typeof crate.name === 'string').map((crate) => ({
    id: String(crate.id || crypto.randomUUID()),
    name: String(crate.name).slice(0, 80),
    sourceUrl: String(crate.sourceUrl || '').slice(0, 2048),
    createdAt: Number(crate.createdAt) || Date.now(),
  })) : [];
  const tracks = Array.isArray(input.tracks) ? input.tracks.filter((track) => track && typeof track.fileName === 'string').map((track) => {
    const inferred = inferTrackMetadata(track.fileName);
    const prep = sanitizeTrackPrep(track);
    return {
      id: String(track.id || crypto.randomUUID()),
      fileName: String(track.fileName),
      normalizedName: normalizeFilename(track.fileName),
      title: String(track.title || inferred.title).slice(0, 180),
      artist: String(track.artist || inferred.artist).slice(0, 120),
      crateId: String(track.crateId || DEFAULT_CRATE.id),
      bpm: prep.bpm,
      duration: Number.isFinite(Number(track.duration)) ? Number(track.duration) : null,
      status: 'missing-file',
      fileAvailable: false,
      sourceUrl: String(track.sourceUrl || '').slice(0, 2048),
      importedAt: Number(track.importedAt) || Date.now(),
      favorite: prep.favorite,
      rating: prep.rating,
      energy: prep.energy,
      tags: prep.tags,
      notes: prep.notes,
      playCount: Number(track.playCount) || 0,
      deletedAt: Number(track.deletedAt) || 0,
      integrityState: String(track.integrityState || (track.fileAvailable ? 'healthy' : 'missing')),
    };
  }) : [];
  return { version: 2, crates, tracks };
}

function requestToPromise(request) {
  return new Promise((resolve, reject) => {
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error('IndexedDB request failed'));
  });
}

function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('IndexedDB transaction failed'));
    tx.onabort = () => reject(tx.error || new Error('IndexedDB transaction aborted'));
  });
}

function formatDuration(seconds) {
  if (!Number.isFinite(seconds)) return '—';
  const minutes = Math.floor(seconds / 60);
  const remainder = Math.floor(seconds % 60);
  return `${minutes}:${String(remainder).padStart(2, '0')}`;
}

function escapeText(value) {
  return String(value ?? '');
}

export class SunoCrateBridge extends EventTarget {
  constructor({ root = document, loadDeck = null, openSource = null, onEvent = null, getMixState = null } = {}) {
    super();
    this.root = root;
    this.loadDeck = loadDeck;
    this.openSource = openSource;
    this.onEvent = onEvent;
    this.getMixState = getMixState;
    this.db = null;
    this.tracks = [];
    this.crates = [];
    this.queue = [];
    this.selected = new Set();
    this.visibleTrackIds = [];
    this.activeCrateId = DEFAULT_CRATE.id;
    this.previewUrl = '';
    this.analysisContext = null;
    this.analysisBusy = false;
    this.importBusy = false;
    this.autoFeed = false;
    this.receipts = [];
    this.health = summarizeLibraryHealth();
    this.queueRecovery = { queue: [], removed: [] };
    this.queueRevision = 0;
    this.queuePersistPromise = Promise.resolve();
    this.nodes = {
      file: root.querySelector('#crateFileInput'),
      manifest: root.querySelector('#crateManifestInput'),
      export: root.querySelector('#crateExportManifest'),
      analyze: root.querySelector('#crateAnalyzePending'),
      persist: root.querySelector('#cratePersistStorage'),
      scan: root.querySelector('#crateScanLibrary'),
      repair: root.querySelector('#crateRepairInput'),
      recovery: root.querySelector('#crateRecoveryInput'),
      exportRecovery: root.querySelector('#crateExportRecovery'),
      restoreQueue: root.querySelector('#crateRestoreQueue'),
      search: root.querySelector('#crateSearch'),
      filter: root.querySelector('#crateFilter'),
      sort: root.querySelector('#crateSort'),
      newCrate: root.querySelector('#crateNew'),
      saveSource: root.querySelector('#crateSaveSource'),
      favoritesOnly: root.querySelector('#crateFavoritesOnly'),
      trashOnly: root.querySelector('#crateTrashOnly'),
      readyOnly: root.querySelector('#crateReadyOnly'),
      list: root.querySelector('#crateTrackList'),
      queue: root.querySelector('#crateQueueList'),
      loadNextA: root.querySelector('#crateLoadNextA'),
      loadNextB: root.querySelector('#crateLoadNextB'),
      prepNext: root.querySelector('#cratePrepNext'),
      clearQueue: root.querySelector('#crateClearQueue'),
      autoFeed: root.querySelector('#crateAutoFeed'),
      queueCount: root.querySelector('#crateQueueCount'),
      selectAll: root.querySelector('#crateSelectAll'),
      batchQueue: root.querySelector('#crateBatchQueue'),
      batchMove: root.querySelector('#crateBatchMove'),
      batchFavorite: root.querySelector('#crateBatchFavorite'),
      batchClear: root.querySelector('#crateBatchClear'),
      batchTrash: root.querySelector('#crateBatchTrash'),
      selectedCount: root.querySelector('#crateSelectedCount'),
      smartBpm: root.querySelector('#crateSmartBpm'),
      smartTolerance: root.querySelector('#crateSmartTolerance'),
      smartCount: root.querySelector('#crateSmartCount'),
      smartEnergy: root.querySelector('#crateSmartEnergy'),
      smartBuild: root.querySelector('#crateBuildSmartSet'),
      count: root.querySelector('#crateTrackCount'),
      ready: root.querySelector('#crateReadyCount'),
      storage: root.querySelector('#crateStorageState'),
      healthState: root.querySelector('#crateHealthState'),
      healthyCount: root.querySelector('#crateHealthyCount'),
      missingCount: root.querySelector('#crateMissingCount'),
      reviewCount: root.querySelector('#crateReviewCount'),
      trashCount: root.querySelector('#crateTrashCount'),
      queueOrphanCount: root.querySelector('#crateQueueOrphanCount'),
      reliabilityGrade: root.querySelector('#crateReliabilityGrade'),
      lastReceipt: root.querySelector('#crateLastReceipt'),
      receiptList: root.querySelector('#crateReceiptList'),
      status: root.querySelector('#crateAnalysisStatus'),
      sourceLink: root.querySelector('#crateSourceLink'),
      preview: root.querySelector('#cratePreviewAudio'),
    };
  }

  async init() {
    this.db = await this.#openDb();
    await this.#ensureDefaultCrate();
    this.queue = await this.#loadQueue();
    this.receipts = await this.#loadReceipts();
    this.activeCrateId = this.#loadActiveCrate();
    this.autoFeed = this.#loadAutoFeed();
    if (this.nodes.autoFeed) this.nodes.autoFeed.checked = this.autoFeed;
    this.#wire();
    await this.refresh();
    await this.#updateStorage();
  }

  exportState() {
    return {
      trackCount: this.tracks.length,
      readyCount: this.tracks.filter((track) => track.status === 'ready').length,
      favoriteCount: this.tracks.filter((track) => track.favorite).length,
      crateCount: this.crates.length,
      queueLength: this.queue.length,
      selectedCount: this.selected.size,
      activeCrateId: this.activeCrateId,
      autoFeed: this.autoFeed,
      smartSetPlanner: true,
      persistentLibrary: true,
      sourceLinksAreMetadataOnly: true,
      reliabilityDesk: true,
      libraryHealth: this.health,
      receiptCount: this.receipts.length,
      queueRevision: this.queueRevision,
    };
  }

  async refresh() {
    this.tracks = (await this.#getAll('tracks')).map((track) => this.#normalizeStoredTrack(track));
    this.crates = await this.#getAll('crates');
    if (!this.crates.some((crate) => crate.id === this.activeCrateId)) this.activeCrateId = DEFAULT_CRATE.id;
    this.selected = new Set([...this.selected].filter((id) => this.tracks.some((track) => track.id === id)));
    this.queueRecovery = reconcileQueue(this.queue, this.tracks);
    this.queue = this.queueRecovery.queue;
    this.health = summarizeLibraryHealth(this.tracks, this.queue.concat(this.queueRecovery.removed.map((item) => item.id)), this.receipts);
    this.#saveQueue();
    this.#renderCrateOptions();
    this.render();
  }

  render() {
    const rows = this.#filteredTracks();
    this.visibleTrackIds = rows.map((track) => track.id);
    if (this.nodes.list) {
      this.nodes.list.replaceChildren();
      if (!rows.length) {
        const paragraph = document.createElement('p');
        paragraph.className = 'crate-empty';
        paragraph.textContent = this.tracks.length ? 'No tracks match the current crate, search, or prep filters.' : 'Import your downloaded Suno MP3/WAV files to build the first crate.';
        this.nodes.list.append(paragraph);
      }
      for (const track of rows) this.nodes.list.append(this.#renderTrackRow(track));
    }
    this.#renderQueue();
    this.#renderStats();
    this.#renderSourceLink();
    this.#renderSelectionState();
  }

  async importFiles(files) {
    const list = [...files].filter(isSupportedAudioFile);
    if (!list.length) {
      this.#status('NO SUPPORTED AUDIO FILES FOUND', 'bad');
      return;
    }
    this.importBusy = true;
    const receiptStartedAt = Date.now();
    const receiptNames = [];
    this.#status(`IMPORTING 0 / ${list.length}`, 'busy');
    let imported = 0;
    let duplicates = 0;
    let failed = 0;
    try {
      if (navigator.storage?.persist) await navigator.storage.persist();
      for (const file of list) {
        try {
          const result = await this.#importOne(file);
          result === 'duplicate' ? duplicates += 1 : imported += 1;
          receiptNames.push(file.name);
        } catch (error) {
          failed += 1;
          this.#emit('crate-import-failed', `${file.name}: ${error.message}`);
        }
        this.#status(`IMPORTING ${imported + duplicates + failed} / ${list.length}`, 'busy');
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    } finally {
      this.importBusy = false;
      await this.refresh();
      await this.#updateStorage();
      const receipt = buildImportReceipt({ type: 'import', startedAt: receiptStartedAt, endedAt: Date.now(), total: list.length, imported, duplicates, failed, names: receiptNames });
      await this.#recordReceipt(receipt);
      this.#status(`${imported} IMPORTED • ${duplicates} DUPLICATE • ${failed} FAILED`, failed ? 'warn' : 'ok');
      this.openSource?.();
      if (imported) this.analyzePending({ limit: 8 }).catch((error) => this.#emit('crate-analysis-error', error.message));
    }
  }

  async analyzePending({ limit = Infinity } = {}) {
    if (this.analysisBusy) return;
    const pending = this.tracks.filter((track) => track.fileAvailable && (!Number.isFinite(track.bpm) || track.status === 'new' || track.status === 'review')).slice(0, limit);
    if (!pending.length) {
      this.#status('NO PENDING TRACKS', 'ok');
      return;
    }
    this.analysisBusy = true;
    if (this.nodes.analyze) this.nodes.analyze.disabled = true;
    let done = 0;
    try {
      this.analysisContext = this.analysisContext || new AudioContext({ latencyHint: 'playback' });
      for (const track of pending) {
        this.#status(`ANALYZING ${done + 1} / ${pending.length}: ${track.title}`, 'busy');
        try {
          const bytes = await track.blob.arrayBuffer();
          const decoded = await this.analysisContext.decodeAudioData(bytes.slice(0));
          const mono = decoded.getChannelData(0).slice(0, Math.min(decoded.length, Math.floor(decoded.sampleRate * 90)));
          const result = detectBpmFromMono(mono, decoded.sampleRate);
          track.duration = decoded.duration;
          track.sampleRate = decoded.sampleRate;
          if (!track.manualBpm) track.bpm = Number.isFinite(result.bpm) ? result.bpm : null;
          track.confidence = result.confidence || 0;
          if (!track.energyEdited) {
            track.energy = estimateEnergyFromMono(mono);
            track.energySource = 'analysis-candidate';
          }
          track.status = track.bpm ? 'ready' : 'review';
          track.analyzedAt = Date.now();
          await this.#put('tracks', track);
        } catch (error) {
          track.status = 'review';
          track.analysisError = String(error.message || error);
          await this.#put('tracks', track);
        }
        done += 1;
        await new Promise((resolve) => setTimeout(resolve, 0));
      }
    } finally {
      this.analysisBusy = false;
      if (this.nodes.analyze) this.nodes.analyze.disabled = false;
      await this.refresh();
      this.#status(`${done} TRACKS ANALYZED`, 'ok');
    }
  }

  async loadTrack(trackId, deckId, { removeFromQueue = false } = {}) {
    const track = await this.#get('tracks', trackId);
    if (!track?.blob) throw new Error('Local audio file is missing. Re-import the matching file.');
    const file = new File([track.blob], track.fileName, { type: track.mimeType || track.blob.type || 'audio/mpeg', lastModified: track.lastModified || Date.now() });
    this.#status(`LOADING ${track.title} → DECK ${deckId}`, 'busy');
    await this.loadDeck?.(deckId, file, track);
    track.lastPlayedAt = Date.now();
    track.playCount = (track.playCount || 0) + 1;
    await this.#put('tracks', track);
    if (removeFromQueue) {
      const index = this.queue.indexOf(trackId);
      if (index >= 0) this.queue.splice(index, 1);
      this.#saveQueue();
    }
    this.#status(`${track.title} LOADED TO DECK ${deckId}`, 'ok');
    this.#emit('crate-load', `${track.title} → Deck ${deckId}`);
    await this.refresh();
  }

  async previewTrack(trackId) {
    const track = await this.#get('tracks', trackId);
    if (!track?.blob) throw new Error('Local audio file is missing.');
    if (this.previewUrl) URL.revokeObjectURL(this.previewUrl);
    this.previewUrl = URL.createObjectURL(track.blob);
    this.nodes.preview.src = this.previewUrl;
    this.nodes.preview.currentTime = 0;
    await this.nodes.preview.play();
    this.#status(`PREVIEWING ${track.title}`, 'ok');
  }

  queueTrack(trackId) {
    if (!this.queue.includes(trackId)) {
      this.queue.push(trackId);
      this.#saveQueue();
      this.#emit('crate-queue', this.tracks.find((track) => track.id === trackId)?.title || trackId);
    }
    this.render();
  }

  async loadNext(deckId) {
    const id = this.queue[0];
    if (!id) throw new Error('The play queue is empty.');
    await this.loadTrack(id, deckId, { removeFromQueue: true });
  }

  async prepNext() {
    const state = this.getMixState?.() || {};
    const deckId = chooseQuietDeck(state.crossfader, state);
    await this.loadNext(deckId);
    this.#status(`NEXT QUEUE TRACK PREPPED ON QUIET DECK ${deckId}`, 'ok');
    return deckId;
  }

  async handleAutoMixComplete({ source, stopped } = {}) {
    if (!this.autoFeed || !stopped || !this.queue.length || !['A', 'B'].includes(source)) return false;
    try {
      await this.loadNext(source);
      this.#status(`AUTO-FEED PREPPED NEXT TRACK ON DECK ${source}`, 'ok');
      this.#emit('crate-auto-feed', `Deck ${source}`);
      return true;
    } catch (error) {
      this.#status(`AUTO-FEED FAILED: ${error.message}`, 'warn');
      return false;
    }
  }

  buildSmartSet() {
    const targetBpm = Number(this.nodes.smartBpm?.value) || 96;
    const tolerance = Number(this.nodes.smartTolerance?.value) || 8;
    const count = Number(this.nodes.smartCount?.value) || 8;
    const energyProfile = this.nodes.smartEnergy?.value || 'mixed';
    const favoritesOnly = Boolean(this.nodes.favoritesOnly?.checked);
    const candidates = this.#filteredTracks({ ignoreSort: true, ignoreReadyFilter: false });
    const selected = selectSmartSetTracks(candidates, { targetBpm, tolerance, count, energyProfile, favoritesOnly });
    if (!selected.length) {
      this.#status('SMART SET FOUND NO BPM-COMPATIBLE READY TRACKS', 'warn');
      return [];
    }
    this.queue = selected.map((track) => track.id);
    this.#saveQueue();
    this.render();
    this.#status(`SMART SET BUILT • ${selected.length} TRACKS • ${targetBpm} BPM ±${tolerance}`, 'ok');
    this.#emit('crate-smart-set', `${selected.length} tracks / ${targetBpm} BPM / ${energyProfile}`);
    return selected;
  }

  async createCrate() {
    const name = prompt('Name the new Backspin crate:', 'NEW SUNO CRATE');
    if (!name?.trim()) return;
    const crate = { id: crypto.randomUUID(), name: name.trim().slice(0, 80).toUpperCase(), sourceUrl: '', createdAt: Date.now() };
    await this.#put('crates', crate);
    this.activeCrateId = crate.id;
    this.#saveActiveCrate();
    await this.refresh();
    if (this.nodes.filter) this.nodes.filter.value = crate.id;
    this.render();
    this.#status(`${crate.name} CREATED`, 'ok');
  }

  async saveSourceLink() {
    const crate = this.crates.find((item) => item.id === this.activeCrateId) || this.crates.find((item) => item.id === this.nodes.filter?.value);
    if (!crate) return;
    const value = prompt('Paste the optional Suno playlist/share link. It is stored as metadata only:', crate.sourceUrl || '');
    if (value == null) return;
    crate.sourceUrl = String(value).trim().slice(0, 2048);
    await this.#put('crates', crate);
    await this.refresh();
    this.#status(crate.sourceUrl ? 'SUNO SOURCE LINK SAVED' : 'SOURCE LINK CLEARED', 'ok');
  }

  exportManifest() {
    this.exportRecovery();
  }

  exportRecovery() {
    const payload = sanitizeRecoveryManifest({
      exportedAt: new Date().toISOString(), crates: this.crates,
      tracks: this.tracks.map(({ blob, ...track }) => ({ ...track, blobSize: blob?.size || 0 })),
      queue: this.queue, activeCrateId: this.activeCrateId, autoFeed: this.autoFeed, receipts: this.receipts,
    });
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = `backspin96-library-recovery-${new Date().toISOString().slice(0, 10)}.json`;
    anchor.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
    this.#status('LIBRARY RECOVERY MANIFEST EXPORTED', 'ok');
  }

  async importManifest(file) {
    const raw = JSON.parse(await file.text());
    const parsed = Number(raw?.version) >= 3 || raw?.kind === 'backspin96-library-recovery' ? sanitizeRecoveryManifest(raw) : sanitizeManifest(raw);
    for (const crate of parsed.crates) await this.#put('crates', crate);
    const existing = this.tracks;
    for (const imported of parsed.tracks) {
      const match = existing.find((track) => track.id === imported.id || (track.normalizedName === imported.normalizedName && track.fileAvailable));
      if (match) {
        const blob = match.blob;
        Object.assign(match, imported, { blob, fileAvailable: Boolean(blob?.size), status: blob?.size ? (imported.bpm ? 'ready' : 'new') : 'missing-file', integrityState: blob?.size ? 'healthy' : 'missing' });
        await this.#put('tracks', match);
      } else await this.#put('tracks', imported);
    }
    if (Array.isArray(parsed.receipts)) for (const receipt of parsed.receipts) await this.#put('receipts', buildImportReceipt(receipt));
    if (Array.isArray(parsed.queue)) this.queue = parsed.queue;
    if (parsed.activeCrateId) this.activeCrateId = parsed.activeCrateId;
    if (typeof parsed.autoFeed === 'boolean') this.autoFeed = parsed.autoFeed;
    this.#saveActiveCrate(); this.#saveAutoFeed(); this.#saveQueue();
    await this.#recordReceipt(buildImportReceipt({ type: 'recovery', total: parsed.tracks.length, imported: parsed.tracks.length, note: 'Recovery manifest imported' }));
    this.receipts = await this.#loadReceipts();
    await this.refresh();
    this.#status(`${parsed.crates.length} CRATES / ${parsed.tracks.length} RECOVERY RECORDS IMPORTED`, 'ok');
    this.openSource?.();
  }

  async scanLibrary() {
    const startedAt = Date.now();
    let healthy = 0, missing = 0, review = 0;
    for (const track of this.tracks) {
      if (track.deletedAt) continue;
      const blobSize = Number(track.blob?.size) || 0;
      if (!blobSize) {
        track.fileAvailable = false; track.status = 'missing-file'; track.integrityState = 'missing'; missing += 1;
      } else if (track.size && blobSize !== Number(track.size)) {
        track.fileAvailable = true; track.status = 'review'; track.integrityState = 'size-mismatch'; review += 1;
      } else {
        track.fileAvailable = true; track.integrityState = 'healthy'; if (track.status === 'missing-file') track.status = track.bpm ? 'ready' : 'new'; healthy += 1;
      }
      track.lastVerifiedAt = Date.now();
      await this.#put('tracks', track);
    }
    await this.#recordReceipt(buildImportReceipt({ type: 'audit', startedAt, total: this.tracks.length, imported: healthy, failed: missing, unmatched: review, note: `${healthy} healthy / ${missing} missing / ${review} review` }));
    this.receipts = await this.#loadReceipts();
    await this.refresh();
    this.#status(`SCAN COMPLETE • ${healthy} HEALTHY • ${missing} MISSING • ${review} REVIEW`, missing ? 'warn' : 'ok');
    return this.health;
  }

  async repairFiles(files) {
    const list = [...files].filter(isSupportedAudioFile);
    if (!list.length) return this.#status('NO SUPPORTED REPAIR FILES', 'bad');
    const startedAt = Date.now(); let repaired = 0, duplicates = 0, unmatched = 0, failed = 0; const names = [];
    const missing = this.tracks.filter((track) => !track.deletedAt && !track.fileAvailable);
    for (const file of list) {
      try {
        const bytes = await file.arrayBuffer();
        const digest = await crypto.subtle.digest('SHA-256', bytes);
        const hash = [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, '0')).join('');
        const candidate = { hash, fileName: file.name, normalizedName: normalizeFilename(file.name), size: file.size };
        const exact = this.tracks.find((track) => track.hash === hash && track.fileAvailable);
        if (exact) { duplicates += 1; continue; }
        const ranked = missing.map((track) => ({ track, score: matchRepairCandidate(track, candidate) })).filter((item) => item.score > 0).sort((a,b) => b.score-a.score);
        const target = ranked[0]?.track;
        if (!target) { unmatched += 1; continue; }
        target.hash = hash; target.blob = file; target.fileName = file.name; target.normalizedName = candidate.normalizedName; target.mimeType = file.type || target.mimeType || 'application/octet-stream'; target.size = file.size; target.lastModified = file.lastModified || Date.now(); target.fileAvailable = true; target.status = target.bpm ? 'ready' : 'new'; target.integrityState = 'healthy'; target.repairedAt = Date.now();
        await this.#put('tracks', target); repaired += 1; names.push(file.name);
      } catch (error) { failed += 1; this.#emit('crate-repair-failed', `${file.name}: ${error.message}`); }
    }
    await this.#recordReceipt(buildImportReceipt({ type: 'repair', startedAt, total: list.length, repaired, duplicates, unmatched, failed, names }));
    this.receipts = await this.#loadReceipts(); await this.refresh(); await this.#updateStorage();
    this.#status(`${repaired} REPAIRED • ${duplicates} DUPLICATE • ${unmatched} UNMATCHED • ${failed} FAILED`, failed || unmatched ? 'warn' : 'ok');
  }

  async restorePreviousQueue() {
    const previous = await this.#get('meta', 'queue-previous');
    if (!previous?.ids?.length) { this.#status('NO PREVIOUS QUEUE SNAPSHOT', 'warn'); return false; }
    const result = reconcileQueue(previous.ids, this.tracks);
    this.queue = result.queue; this.#saveQueue(); this.render();
    this.#status(`RESTORED ${this.queue.length} QUEUE ITEMS${result.removed.length ? ` • ${result.removed.length} UNPLAYABLE SKIPPED` : ''}`, result.removed.length ? 'warn' : 'ok');
    return true;
  }

  #wire() {
    this.nodes.file?.addEventListener('change', () => {
      const files = this.nodes.file.files;
      this.importFiles(files).finally(() => { this.nodes.file.value = ''; });
    });
    this.nodes.manifest?.addEventListener('change', () => {
      const file = this.nodes.manifest.files?.[0];
      if (file) this.importManifest(file).catch((error) => this.#status(error.message, 'bad')).finally(() => { this.nodes.manifest.value = ''; });
    });
    this.nodes.export?.addEventListener('click', () => this.exportManifest());
    this.nodes.exportRecovery?.addEventListener('click', () => this.exportRecovery());
    this.nodes.scan?.addEventListener('click', () => this.scanLibrary().catch((error) => this.#status(error.message, 'bad')));
    this.nodes.repair?.addEventListener('change', () => { const files = this.nodes.repair.files; this.repairFiles(files).finally(() => { this.nodes.repair.value = ''; }); });
    this.nodes.recovery?.addEventListener('change', () => { const file = this.nodes.recovery.files?.[0]; if (file) this.importManifest(file).catch((error) => this.#status(error.message, 'bad')).finally(() => { this.nodes.recovery.value = ''; }); });
    this.nodes.restoreQueue?.addEventListener('click', () => this.restorePreviousQueue().catch((error) => this.#status(error.message, 'bad')));
    this.nodes.analyze?.addEventListener('click', () => this.analyzePending());
    this.nodes.persist?.addEventListener('click', async () => {
      const ok = await navigator.storage?.persist?.();
      this.#status(ok ? 'PERSISTENT STORAGE GRANTED' : 'PERSISTENCE NOT GRANTED', ok ? 'ok' : 'warn');
      await this.#updateStorage();
    });
    this.nodes.search?.addEventListener('input', () => this.render());
    this.nodes.filter?.addEventListener('change', () => {
      if (this.nodes.filter.value !== 'all') {
        this.activeCrateId = this.nodes.filter.value;
        this.#saveActiveCrate();
      }
      this.render();
    });
    this.nodes.sort?.addEventListener('change', () => this.render());
    this.nodes.favoritesOnly?.addEventListener('change', () => this.render());
    this.nodes.readyOnly?.addEventListener('change', () => this.render());
    this.nodes.trashOnly?.addEventListener('change', () => this.render());
    this.nodes.newCrate?.addEventListener('click', () => this.createCrate());
    this.nodes.saveSource?.addEventListener('click', () => this.saveSourceLink());
    this.nodes.loadNextA?.addEventListener('click', () => this.loadNext('A').catch((error) => this.#status(error.message, 'bad')));
    this.nodes.loadNextB?.addEventListener('click', () => this.loadNext('B').catch((error) => this.#status(error.message, 'bad')));
    this.nodes.prepNext?.addEventListener('click', () => this.prepNext().catch((error) => this.#status(error.message, 'bad')));
    this.nodes.clearQueue?.addEventListener('click', () => { this.queue = []; this.#saveQueue(); this.render(); });
    this.nodes.autoFeed?.addEventListener('change', () => {
      this.autoFeed = Boolean(this.nodes.autoFeed.checked);
      this.#saveAutoFeed();
      this.#status(this.autoFeed ? 'AUTO-FEED ARMED — REQUIRES STOP OLD DECK' : 'AUTO-FEED OFF', this.autoFeed ? 'ok' : 'idle');
    });
    this.nodes.smartBuild?.addEventListener('click', () => this.buildSmartSet());
    this.nodes.selectAll?.addEventListener('change', () => {
      if (this.nodes.selectAll.checked) this.visibleTrackIds.forEach((id) => this.selected.add(id));
      else this.visibleTrackIds.forEach((id) => this.selected.delete(id));
      this.render();
    });
    this.nodes.batchQueue?.addEventListener('click', () => this.#batchQueue());
    this.nodes.batchMove?.addEventListener('click', () => this.#batchMove());
    this.nodes.batchFavorite?.addEventListener('click', () => this.#batchFavorite());
    this.nodes.batchTrash?.addEventListener('click', () => this.#batchTrash());
    this.nodes.batchClear?.addEventListener('click', () => { this.selected.clear(); this.render(); });
    this.nodes.list?.addEventListener('click', (event) => this.#handleListAction(event));
    this.nodes.list?.addEventListener('change', (event) => this.#handleSelectionChange(event));
    this.nodes.queue?.addEventListener('click', (event) => this.#handleQueueAction(event));
  }

  #filteredTracks({ ignoreSort = false, ignoreReadyFilter = false } = {}) {
    const query = String(this.nodes.search?.value || '').trim().toLowerCase();
    const filter = this.nodes.filter?.value || 'all';
    const sort = sanitizeCrateSort(this.nodes.sort?.value);
    const favoritesOnly = Boolean(this.nodes.favoritesOnly?.checked);
    const readyOnly = !ignoreReadyFilter && Boolean(this.nodes.readyOnly?.checked);
    const trashOnly = Boolean(this.nodes.trashOnly?.checked);
    let rows = this.tracks
      .filter((track) => trashOnly ? Boolean(track.deletedAt) : !track.deletedAt)
      .filter((track) => filter === 'all' || track.crateId === filter)
      .filter((track) => !favoritesOnly || track.favorite)
      .filter((track) => !readyOnly || (track.status === 'ready' && track.fileAvailable))
      .filter((track) => !query || [track.title, track.artist, track.fileName, track.bpm, track.crateId, ...(track.tags || [])].join(' ').toLowerCase().includes(query));
    if (ignoreSort) return rows;
    rows = [...rows].sort((a, b) => {
      if (sort === 'title') return a.title.localeCompare(b.title);
      if (sort === 'artist') return a.artist.localeCompare(b.artist);
      if (sort === 'bpm') return (Number(a.bpm) || 9999) - (Number(b.bpm) || 9999);
      if (sort === 'duration') return (Number(a.duration) || 999999) - (Number(b.duration) || 999999);
      if (sort === 'rating') return (Number(b.rating) || 0) - (Number(a.rating) || 0) || a.title.localeCompare(b.title);
      if (sort === 'energy') return (Number(b.energy) || 0) - (Number(a.energy) || 0) || a.title.localeCompare(b.title);
      if (sort === 'played') return (Number(b.lastPlayedAt) || 0) - (Number(a.lastPlayedAt) || 0);
      return (Number(b.importedAt) || 0) - (Number(a.importedAt) || 0);
    });
    return rows;
  }

  async #handleListAction(event) {
    const button = event.target.closest('button[data-track-action]');
    if (!button) return;
    const id = button.dataset.trackId;
    const action = button.dataset.trackAction;
    try {
      if (action === 'load-a') await this.loadTrack(id, 'A');
      if (action === 'load-b') await this.loadTrack(id, 'B');
      if (action === 'preview') await this.previewTrack(id);
      if (action === 'queue') this.queueTrack(id);
      if (action === 'favorite') await this.#toggleFavorite(id);
      if (action === 'edit') await this.#editTrack(id);
      if (action === 'trash' && confirm('Move this track to reversible Backspin trash?')) {
        const track = await this.#get('tracks', id); if (track) { track.deletedAt = Date.now(); await this.#put('tracks', track); }
        this.queue = this.queue.filter((queued) => queued !== id); this.selected.delete(id); this.#saveQueue(); await this.refresh();
      }
      if (action === 'restore') { const track = await this.#get('tracks', id); if (track) { track.deletedAt = 0; await this.#put('tracks', track); await this.refresh(); } }
      if (action === 'purge' && confirm('Permanently purge this local audio and metadata? This cannot be undone.')) { await this.#delete('tracks', id); this.selected.delete(id); await this.refresh(); }
      if (action === 'move') await this.#moveTrack(id);
    } catch (error) {
      this.#status(error.message, 'bad');
    }
  }

  #handleSelectionChange(event) {
    const checkbox = event.target.closest('input[data-track-select]');
    if (!checkbox) return;
    checkbox.checked ? this.selected.add(checkbox.dataset.trackSelect) : this.selected.delete(checkbox.dataset.trackSelect);
    this.#renderSelectionState();
  }

  #handleQueueAction(event) {
    const button = event.target.closest('button[data-queue-action]');
    if (!button) return;
    const index = Number(button.dataset.queueIndex);
    const action = button.dataset.queueAction;
    if (!Number.isInteger(index) || index < 0 || index >= this.queue.length) return;
    if (action === 'remove') this.queue.splice(index, 1);
    if (action === 'up' && index > 0) [this.queue[index - 1], this.queue[index]] = [this.queue[index], this.queue[index - 1]];
    if (action === 'down' && index < this.queue.length - 1) [this.queue[index + 1], this.queue[index]] = [this.queue[index], this.queue[index + 1]];
    this.#saveQueue();
    this.render();
  }

  async #toggleFavorite(id) {
    const track = await this.#get('tracks', id);
    if (!track) return;
    track.favorite = !track.favorite;
    await this.#put('tracks', track);
    await this.refresh();
  }

  async #editTrack(id) {
    const track = await this.#get('tracks', id);
    if (!track) return;
    const title = prompt('Track title:', track.title);
    if (title == null) return;
    const artist = prompt('Artist / project:', track.artist);
    if (artist == null) return;
    const bpmValue = prompt('BPM (30–260, blank keeps current):', Number.isFinite(track.bpm) ? String(track.bpm) : '');
    if (bpmValue == null) return;
    const energyValue = prompt('Energy 1–5:', String(track.energy || 3));
    if (energyValue == null) return;
    const ratingValue = prompt('Rating 0–5:', String(track.rating || 0));
    if (ratingValue == null) return;
    const tagsValue = prompt('Tags, comma separated:', (track.tags || []).join(', '));
    if (tagsValue == null) return;
    const notesValue = prompt('Notes:', track.notes || '');
    if (notesValue == null) return;
    const prep = sanitizeTrackPrep({
      favorite: track.favorite,
      bpm: bpmValue.trim() ? Number(bpmValue) : track.bpm,
      energy: Number(energyValue),
      rating: Number(ratingValue),
      tags: tagsValue,
      notes: notesValue,
    });
    track.title = String(title).trim().slice(0, 180) || track.title;
    track.artist = String(artist).trim().slice(0, 120) || track.artist;
    track.bpm = prep.bpm;
    track.manualBpm = Boolean(bpmValue.trim());
    track.energy = prep.energy;
    track.energyEdited = true;
    track.rating = prep.rating;
    track.tags = prep.tags;
    track.notes = prep.notes;
    track.status = track.bpm ? 'ready' : track.status;
    await this.#put('tracks', track);
    await this.refresh();
    this.#status(`${track.title} PREP METADATA SAVED`, 'ok');
  }

  async #moveTrack(id) {
    const track = await this.#get('tracks', id);
    const crate = this.#chooseCrate('Move to which crate?');
    if (!track || !crate) return;
    track.crateId = crate.id;
    await this.#put('tracks', track);
    await this.refresh();
  }

  #chooseCrate(message) {
    const choices = this.crates.map((crate, index) => `${index + 1}. ${crate.name}`).join('\n');
    const value = prompt(`${message}\n${choices}`, '1');
    const index = Number(value) - 1;
    return this.crates[index] || null;
  }

  #batchQueue() {
    for (const id of this.selected) if (!this.queue.includes(id) && this.tracks.some((track) => track.id === id && track.fileAvailable)) this.queue.push(id);
    this.#saveQueue();
    this.#status(`${this.selected.size} SELECTED TRACKS ADDED TO QUEUE`, 'ok');
    this.render();
  }

  async #batchMove() {
    if (!this.selected.size) return;
    const crate = this.#chooseCrate('Move selected tracks to which crate?');
    if (!crate) return;
    for (const id of this.selected) {
      const track = await this.#get('tracks', id);
      if (track) {
        track.crateId = crate.id;
        await this.#put('tracks', track);
      }
    }
    this.#status(`${this.selected.size} TRACKS MOVED TO ${crate.name}`, 'ok');
    await this.refresh();
  }

  async #batchFavorite() {
    if (!this.selected.size) return;
    for (const id of this.selected) {
      const track = await this.#get('tracks', id);
      if (track) {
        track.favorite = true;
        await this.#put('tracks', track);
      }
    }
    this.#status(`${this.selected.size} TRACKS FAVORITED`, 'ok');
    await this.refresh();
  }

  async #batchTrash() {
    if (!this.selected.size || !confirm(`Move ${this.selected.size} selected tracks to reversible trash?`)) return;
    let changed = 0;
    for (const id of this.selected) {
      const track = await this.#get('tracks', id);
      if (track && !track.deletedAt) { track.deletedAt = Date.now(); await this.#put('tracks', track); changed += 1; }
    }
    this.queue = this.queue.filter((id) => !this.selected.has(id)); this.selected.clear(); this.#saveQueue(); await this.refresh();
    this.#status(`${changed} TRACKS MOVED TO TRASH`, 'ok');
  }

  #renderTrackRow(track) {
    const row = document.createElement('article');
    row.className = 'crate-track-row smart-crate-row';
    row.dataset.status = track.status || 'new';
    row.dataset.favorite = String(Boolean(track.favorite));
    const integrity = auditTrackRecord(track);
    row.dataset.integrity = integrity.state;

    const select = document.createElement('input');
    select.type = 'checkbox';
    select.dataset.trackSelect = track.id;
    select.checked = this.selected.has(track.id);
    select.setAttribute('aria-label', `Select ${track.title}`);

    const favorite = document.createElement('button');
    favorite.className = 'crate-favorite';
    favorite.dataset.trackAction = 'favorite';
    favorite.dataset.trackId = track.id;
    favorite.textContent = track.favorite ? '★' : '☆';
    favorite.title = track.favorite ? 'Remove favorite' : 'Favorite track';

    const info = document.createElement('div');
    info.className = 'crate-track-info';
    const title = document.createElement('strong');
    title.textContent = escapeText(track.title);
    const meta = document.createElement('small');
    const tags = track.tags?.length ? ` • #${track.tags.join(' #')}` : '';
    meta.textContent = `${track.artist} • ${track.fileName}${tags}`;
    const prep = document.createElement('em');
    prep.textContent = `${'★'.repeat(track.rating || 0)}${'☆'.repeat(5 - (track.rating || 0))} • PLAYED ${track.playCount || 0}`;
    info.append(title, meta, prep);

    const bpm = document.createElement('b');
    bpm.textContent = Number.isFinite(track.bpm) ? track.bpm.toFixed(1) : '—';
    bpm.title = track.manualBpm ? 'Manual BPM authority' : 'Analyzed BPM candidate';

    const energy = document.createElement('div');
    energy.className = 'crate-energy';
    energy.title = `Energy ${track.energy || 3}/5`;
    for (let index = 1; index <= 5; index += 1) {
      const dot = document.createElement('i');
      dot.classList.toggle('is-on', index <= (track.energy || 3));
      energy.append(dot);
    }

    const status = document.createElement('span');
    status.className = 'crate-track-status';
    status.dataset.state = integrity.state;
    status.textContent = integrity.state === 'trash' ? 'TRASH' : integrity.state === 'missing' ? 'FILE NEEDED' : integrity.state === 'review' ? 'REVIEW' : (track.status || 'ready').toUpperCase();

    const actions = document.createElement('div');
    actions.className = 'crate-row-actions';
    const actionSet = track.deletedAt
      ? [['restore', 'RESTORE'], ['purge', 'PURGE']]
      : [['load-a', 'A'], ['load-b', 'B'], ['preview', '▶'], ['queue', '+Q'], ['edit', 'PREP'], ['move', 'CRATE'], ['trash', 'TRASH']];
    for (const [action, label] of actionSet) {
      const button = document.createElement('button');
      button.className = 'button'; button.dataset.trackAction = action; button.dataset.trackId = track.id; button.textContent = label;
      if (!integrity.playable && ['load-a','load-b','preview','queue'].includes(action)) button.disabled = true;
      actions.append(button);
    }

    const selectCell = document.createElement('div');
    selectCell.className = 'crate-select-cell';
    selectCell.append(select, favorite);
    row.append(selectCell, info, bpm, energy, status, actions);
    return row;
  }

  #renderQueue() {
    if (!this.nodes.queue) return;
    this.nodes.queue.replaceChildren();
    const tracks = this.queue.map((id) => this.tracks.find((track) => track.id === id)).filter(Boolean);
    if (this.nodes.queueCount) this.nodes.queueCount.textContent = `${tracks.length} TRACK${tracks.length === 1 ? '' : 'S'}`;
    if (!tracks.length) {
      const paragraph = document.createElement('p');
      paragraph.textContent = 'Queue is empty. Build a smart set or add tracks manually.';
      this.nodes.queue.append(paragraph);
      return;
    }
    tracks.forEach((track, index) => {
      const item = document.createElement('div');
      item.className = 'crate-queue-item smart-queue-item';
      const number = document.createElement('b');
      number.textContent = String(index + 1).padStart(2, '0');
      const name = document.createElement('span');
      name.textContent = track.title;
      const detail = document.createElement('small');
      detail.textContent = `${track.bpm ? `${track.bpm.toFixed(1)} BPM` : 'BPM —'} • E${track.energy || 3}`;
      const actions = document.createElement('div');
      actions.className = 'queue-item-actions';
      for (const [action, label] of [['up', '↑'], ['down', '↓'], ['remove', '×']]) {
        const button = document.createElement('button');
        button.className = 'button';
        button.dataset.queueAction = action;
        button.dataset.queueIndex = String(index);
        button.textContent = label;
        actions.append(button);
      }
      item.append(number, name, detail, actions);
      this.nodes.queue.append(item);
    });
  }

  #renderStats() {
    const ready = this.tracks.filter((track) => !track.deletedAt && track.status === 'ready' && track.fileAvailable).length;
    const favorites = this.tracks.filter((track) => !track.deletedAt && track.favorite).length;
    this.health = summarizeLibraryHealth(this.tracks, this.queue.concat(this.queueRecovery.removed.map((item) => item.id)), this.receipts);
    if (this.nodes.count) this.nodes.count.textContent = `${this.health.total} TRACK${this.health.total === 1 ? '' : 'S'}`;
    if (this.nodes.ready) this.nodes.ready.textContent = `${ready} READY • ${favorites} ★`;
    const bad = this.health.missing + this.health.queueOrphans;
    const state = bad ? 'bad' : this.health.review ? 'warn' : 'ok';
    const grade = bad ? 'REPAIR' : this.health.review ? 'REVIEW' : 'HEALTHY';
    if (this.nodes.healthState) { this.nodes.healthState.textContent = `${grade} • ${this.health.playable} PLAYABLE`; this.nodes.healthState.dataset.state = state; }
    if (this.nodes.reliabilityGrade) { this.nodes.reliabilityGrade.textContent = grade; this.nodes.reliabilityGrade.dataset.state = state; }
    if (this.nodes.healthyCount) this.nodes.healthyCount.textContent = String(this.health.healthy);
    if (this.nodes.missingCount) this.nodes.missingCount.textContent = String(this.health.missing);
    if (this.nodes.reviewCount) this.nodes.reviewCount.textContent = String(this.health.review);
    if (this.nodes.trashCount) this.nodes.trashCount.textContent = String(this.health.trash);
    if (this.nodes.queueOrphanCount) this.nodes.queueOrphanCount.textContent = String(this.health.queueOrphans);
    this.#renderReceipts();
  }

  #renderReceipts() {
    const recent = [...this.receipts].sort((a,b)=>(b.endedAt||0)-(a.endedAt||0)).slice(0,5);
    if (this.nodes.lastReceipt) this.nodes.lastReceipt.textContent = recent[0] ? `${recent[0].type.toUpperCase()} • ${new Date(recent[0].endedAt).toLocaleString()}` : 'NONE YET';
    if (!this.nodes.receiptList) return;
    this.nodes.receiptList.replaceChildren();
    if (!recent.length) { const p=document.createElement('p'); p.textContent='No import receipts yet.'; this.nodes.receiptList.append(p); return; }
    for (const receipt of recent) {
      const item=document.createElement('div'); item.className='crate-receipt';
      const kind=document.createElement('b'); kind.textContent=receipt.type.toUpperCase();
      const detail=document.createElement('span'); detail.textContent=`${receipt.imported||0} imported • ${receipt.repaired||0} repaired • ${receipt.failed||0} failed`;
      const when=document.createElement('em'); when.textContent=new Date(receipt.endedAt).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
      item.append(kind,detail,when); this.nodes.receiptList.append(item);
    }
  }

  #renderSelectionState() {
    if (this.nodes.selectedCount) this.nodes.selectedCount.textContent = `${this.selected.size} SELECTED`;
    if (this.nodes.selectAll) {
      const selectedVisible = this.visibleTrackIds.filter((id) => this.selected.has(id)).length;
      this.nodes.selectAll.checked = Boolean(this.visibleTrackIds.length && selectedVisible === this.visibleTrackIds.length);
      this.nodes.selectAll.indeterminate = selectedVisible > 0 && selectedVisible < this.visibleTrackIds.length;
    }
    for (const button of [this.nodes.batchQueue, this.nodes.batchMove, this.nodes.batchFavorite, this.nodes.batchTrash, this.nodes.batchClear]) {
      if (button) button.disabled = this.selected.size === 0;
    }
  }

  #renderCrateOptions() {
    if (!this.nodes.filter) return;
    const selected = this.nodes.filter.value || 'all';
    this.nodes.filter.replaceChildren();
    const all = document.createElement('option');
    all.value = 'all';
    all.textContent = 'ALL CRATES';
    this.nodes.filter.append(all);
    for (const crate of this.crates) {
      const option = document.createElement('option');
      option.value = crate.id;
      option.textContent = crate.name;
      this.nodes.filter.append(option);
    }
    this.nodes.filter.value = this.crates.some((crate) => crate.id === selected) ? selected : 'all';
  }

  #renderSourceLink() {
    const crate = this.crates.find((item) => item.id === this.activeCrateId);
    if (!this.nodes.sourceLink) return;
    if (crate?.sourceUrl) {
      this.nodes.sourceLink.href = crate.sourceUrl;
      this.nodes.sourceLink.textContent = 'OPEN SAVED SUNO SOURCE';
      this.nodes.sourceLink.removeAttribute('aria-disabled');
    } else {
      this.nodes.sourceLink.removeAttribute('href');
      this.nodes.sourceLink.textContent = 'NO LINK SAVED';
      this.nodes.sourceLink.setAttribute('aria-disabled', 'true');
    }
  }

  async #importOne(file) {
    const bytes = await file.arrayBuffer();
    const digest = await crypto.subtle.digest('SHA-256', bytes);
    const hash = [...new Uint8Array(digest)].map((value) => value.toString(16).padStart(2, '0')).join('');
    const id = `sha256-${hash}`;
    if (await this.#get('tracks', id)) return 'duplicate';
    const inferred = inferTrackMetadata(file.name);
    const record = {
      id,
      hash,
      fileName: file.name,
      normalizedName: normalizeFilename(file.name),
      title: inferred.title,
      artist: inferred.artist,
      crateId: this.activeCrateId || DEFAULT_CRATE.id,
      mimeType: file.type || 'application/octet-stream',
      size: file.size,
      lastModified: file.lastModified || Date.now(),
      blob: file,
      status: 'new',
      fileAvailable: true,
      bpm: null,
      duration: null,
      sourceUrl: '',
      importedAt: Date.now(),
      playCount: 0,
      favorite: false,
      rating: 0,
      energy: 3,
      tags: [],
      notes: '',
      integrityState: 'healthy',
      lastVerifiedAt: Date.now(),
      deletedAt: 0,
    };
    await this.#put('tracks', record);
    this.#emit('crate-import', file.name);
    return 'imported';
  }

  #normalizeStoredTrack(track) {
    const prep = sanitizeTrackPrep(track);
    return {
      ...track,
      favorite: prep.favorite,
      rating: prep.rating,
      energy: prep.energy,
      tags: prep.tags,
      notes: prep.notes,
      bpm: Number.isFinite(Number(track.bpm)) ? Number(track.bpm) : null,
      playCount: Number(track.playCount) || 0,
      deletedAt: Number(track.deletedAt) || 0,
      integrityState: String(track.integrityState || (track.fileAvailable ? 'healthy' : 'missing')),
    };
  }

  async #ensureDefaultCrate() {
    if (!await this.#get('crates', DEFAULT_CRATE.id)) await this.#put('crates', { ...DEFAULT_CRATE, createdAt: Date.now() });
  }

  async #openDb() {
    return new Promise((resolve, reject) => {
      const request = indexedDB.open(DB_NAME, DB_VERSION);
      request.onupgradeneeded = () => {
        const db = request.result;
        if (!db.objectStoreNames.contains('tracks')) {
          const store = db.createObjectStore('tracks', { keyPath: 'id' });
          store.createIndex('crateId', 'crateId');
          store.createIndex('normalizedName', 'normalizedName');
          store.createIndex('status', 'status');
        }
        if (!db.objectStoreNames.contains('crates')) db.createObjectStore('crates', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('receipts')) { const receipts = db.createObjectStore('receipts', { keyPath: 'id' }); receipts.createIndex('endedAt', 'endedAt'); }
        if (!db.objectStoreNames.contains('meta')) db.createObjectStore('meta', { keyPath: 'key' });
      };
      request.onsuccess = () => resolve(request.result);
      request.onerror = () => reject(request.error || new Error('Could not open crate database'));
    });
  }

  async #getAll(store) {
    const tx = this.db.transaction(store, 'readonly');
    return requestToPromise(tx.objectStore(store).getAll());
  }

  async #get(store, key) {
    const tx = this.db.transaction(store, 'readonly');
    return requestToPromise(tx.objectStore(store).get(key));
  }

  async #put(store, value) {
    const tx = this.db.transaction(store, 'readwrite');
    tx.objectStore(store).put(value);
    await txDone(tx);
    return value;
  }

  async #delete(store, key) {
    const tx = this.db.transaction(store, 'readwrite');
    tx.objectStore(store).delete(key);
    await txDone(tx);
  }

  async #loadQueue() {
    let local=[]; try { local=JSON.parse(localStorage.getItem(QUEUE_KEY)||'[]').filter((id)=>typeof id==='string'); } catch {}
    try { const state=await this.#get('meta','queue'); if (Array.isArray(state?.ids)) { this.queueRevision=Number(state.revision)||0; return state.ids; } } catch {}
    return local;
  }

  #saveQueue() {
    try { localStorage.setItem(QUEUE_KEY, JSON.stringify(this.queue)); } catch {}
    if (!this.db) return;
    const ids=[...this.queue]; const revision=++this.queueRevision;
    this.queuePersistPromise=this.queuePersistPromise.then(async()=>{
      const current=await this.#get('meta','queue').catch(()=>null);
      if(current?.ids&&JSON.stringify(current.ids)!==JSON.stringify(ids)) await this.#put('meta',{key:'queue-previous',ids:current.ids,revision:current.revision||0,updatedAt:current.updatedAt||Date.now()});
      await this.#put('meta',{key:'queue',ids,revision,updatedAt:Date.now()});
    }).catch(()=>{});
  }

  async #loadReceipts() {
    try { return (await this.#getAll('receipts')).sort((a,b)=>(b.endedAt||0)-(a.endedAt||0)).slice(0,100); }
    catch { return []; }
  }

  async #recordReceipt(receipt) {
    await this.#put('receipts', buildImportReceipt(receipt));
    this.receipts = await this.#loadReceipts();
  }

  #loadActiveCrate() {
    try { return localStorage.getItem(ACTIVE_CRATE_KEY) || DEFAULT_CRATE.id; }
    catch { return DEFAULT_CRATE.id; }
  }

  #saveActiveCrate() {
    try { localStorage.setItem(ACTIVE_CRATE_KEY, this.activeCrateId); }
    catch {}
  }

  #loadAutoFeed() {
    try { return localStorage.getItem(AUTO_FEED_KEY) === 'true'; }
    catch { return false; }
  }

  #saveAutoFeed() {
    try { localStorage.setItem(AUTO_FEED_KEY, String(this.autoFeed)); }
    catch {}
  }

  async #updateStorage() {
    try {
      const estimate = await navigator.storage?.estimate?.();
      const used = Number(estimate?.usage) || 0;
      const quota = Number(estimate?.quota) || 0;
      const persistent = await navigator.storage?.persisted?.();
      const format = (bytes) => bytes > 1073741824 ? `${(bytes / 1073741824).toFixed(1)} GB` : `${(bytes / 1048576).toFixed(0)} MB`;
      if (this.nodes.storage) this.nodes.storage.textContent = quota ? `${format(used)} / ${format(quota)}${persistent ? ' • PERSISTENT' : ''}` : 'STORAGE READY';
    } catch {
      if (this.nodes.storage) this.nodes.storage.textContent = 'STORAGE READY';
    }
  }

  #status(message, state = 'idle') {
    if (this.nodes.status) {
      this.nodes.status.textContent = String(message).slice(0, 180);
      this.nodes.status.dataset.state = state;
    }
    this.dispatchEvent(new CustomEvent('status', { detail: { message, state } }));
  }

  #emit(kind, detail) {
    this.onEvent?.(kind, detail);
    this.dispatchEvent(new CustomEvent('crate-event', { detail: { kind, detail } }));
  }
}
