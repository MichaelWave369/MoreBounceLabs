const clampCount=(value,min=0,max=100000)=>Math.max(min,Math.min(max,Math.floor(Number(value)||0)));

export function normalizeRecoveryQueue(queue=[]){
  const seen=new Set();
  return (Array.isArray(queue)?queue:[]).filter((id)=>typeof id==='string'&&id&&!seen.has(id)&&seen.add(id));
}

export function auditTrackRecord(track={}){
  if(track.deletedAt)return{state:'trash',playable:false,issue:'soft-deleted'};
  const blobSize=Number(track.blob?.size ?? track.blobSize ?? 0);
  const expectedSize=Number(track.size)||0;
  const available=Boolean(track.fileAvailable)&&blobSize>0;
  if(!available)return{state:'missing',playable:false,issue:'audio-blob-missing'};
  if(expectedSize>0&&blobSize!==expectedSize)return{state:'review',playable:true,issue:'size-mismatch'};
  if(track.status==='review'||track.analysisError)return{state:'review',playable:true,issue:'analysis-review'};
  return{state:'healthy',playable:true,issue:null};
}

export function reconcileQueue(queue=[],tracks=[]){
  const ids=normalizeRecoveryQueue(queue);
  const map=new Map((Array.isArray(tracks)?tracks:[]).map((track)=>[track.id,track]));
  const valid=[];const removed=[];
  for(const id of ids){
    const track=map.get(id);const audit=auditTrackRecord(track||{});
    if(track&&audit.playable)valid.push(id);else removed.push({id,reason:track?audit.issue:'record-missing'});
  }
  return{queue:valid,removed};
}

export function summarizeLibraryHealth(tracks=[],queue=[],receipts=[]){
  const summary={total:0,healthy:0,missing:0,review:0,trash:0,playable:0,queueOrphans:0,lastReceiptAt:0};
  for(const track of Array.isArray(tracks)?tracks:[]){
    summary.total+=1;const audit=auditTrackRecord(track);summary[audit.state]=(summary[audit.state]||0)+1;if(audit.playable)summary.playable+=1;
  }
  summary.queueOrphans=reconcileQueue(queue,tracks).removed.length;
  summary.lastReceiptAt=Math.max(0,...(Array.isArray(receipts)?receipts:[]).map((receipt)=>Number(receipt.endedAt||receipt.startedAt)||0));
  return summary;
}

export function buildImportReceipt(input={}){
  const startedAt=Number(input.startedAt)||Date.now();
  const endedAt=Math.max(startedAt,Number(input.endedAt)||Date.now());
  return{
    id:String(input.id||`receipt-${startedAt}-${Math.random().toString(36).slice(2,8)}`),
    type:['import','repair','audit','recovery'].includes(input.type)?input.type:'import',
    startedAt,endedAt,
    total:clampCount(input.total),imported:clampCount(input.imported),repaired:clampCount(input.repaired),duplicates:clampCount(input.duplicates),failed:clampCount(input.failed),unmatched:clampCount(input.unmatched),
    names:(Array.isArray(input.names)?input.names:[]).map((name)=>String(name).slice(0,180)).slice(0,100),
    note:String(input.note||'').slice(0,300),
  };
}

export function matchRepairCandidate(track={},candidate={}){
  if(track.deletedAt)return 0;
  if(track.hash&&candidate.hash&&track.hash===candidate.hash)return 100;
  const trackName=String(track.normalizedName||'');const candidateName=String(candidate.normalizedName||'');
  const trackSize=Number(track.size)||0;const candidateSize=Number(candidate.size)||0;
  if(trackName&&trackName===candidateName&&trackSize&&trackSize===candidateSize)return 90;
  if(trackName&&trackName===candidateName)return 70;
  if(trackSize&&trackSize===candidateSize&&String(track.fileName||'').toLowerCase()===String(candidate.fileName||'').toLowerCase())return 60;
  return 0;
}

export function sanitizeRecoveryManifest(input={}){
  const crates=Array.isArray(input.crates)?input.crates.filter((crate)=>crate&&typeof crate.name==='string').map((crate)=>({
    id:String(crate.id||crypto.randomUUID()),name:String(crate.name).slice(0,80),sourceUrl:String(crate.sourceUrl||'').slice(0,2048),createdAt:Number(crate.createdAt)||Date.now(),
  })):[];
  const tracks=Array.isArray(input.tracks)?input.tracks.filter((track)=>track&&typeof track.fileName==='string').map((track)=>({
    id:String(track.id||crypto.randomUUID()),hash:String(track.hash||''),fileName:String(track.fileName),normalizedName:String(track.normalizedName||String(track.fileName).trim().toLowerCase().replace(/\s+/g,' ')),
    title:String(track.title||track.fileName).slice(0,180),artist:String(track.artist||'UNKNOWN ARTIST').slice(0,120),crateId:String(track.crateId||'suno-imports'),mimeType:String(track.mimeType||''),size:Number(track.size)||0,lastModified:Number(track.lastModified)||0,
    bpm:Number.isFinite(Number(track.bpm))?Number(track.bpm):null,duration:Number.isFinite(Number(track.duration))?Number(track.duration):null,sampleRate:Number(track.sampleRate)||null,
    sourceUrl:String(track.sourceUrl||'').slice(0,2048),importedAt:Number(track.importedAt)||Date.now(),favorite:Boolean(track.favorite),rating:clampCount(track.rating,0,5),energy:clampCount(track.energy||3,1,5),
    tags:(Array.isArray(track.tags)?track.tags:[]).map((tag)=>String(tag).trim().toLowerCase()).filter(Boolean).slice(0,12),notes:String(track.notes||'').slice(0,300),playCount:clampCount(track.playCount),lastPlayedAt:Number(track.lastPlayedAt)||0,
    deletedAt:Number(track.deletedAt)||0,status:'missing-file',fileAvailable:false,integrityState:'missing',
  })):[];
  const receipts=(Array.isArray(input.receipts)?input.receipts:[]).map(buildImportReceipt).slice(0,100);
  return{version:3,kind:'backspin96-library-recovery',exportedAt:String(input.exportedAt||new Date().toISOString()),crates,tracks,queue:normalizeRecoveryQueue(input.queue),activeCrateId:String(input.activeCrateId||'suno-imports'),autoFeed:Boolean(input.autoFeed),receipts};
}
