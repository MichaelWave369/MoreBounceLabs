const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));

export function normalizeHardwareRange(value, min, max, step = 0) {
  const lo = Number(min);
  const hi = Number(max);
  let next = clamp(value, lo, hi);
  const quantum = Number(step) || 0;
  if (quantum > 0) next = Math.round((next - lo) / quantum) * quantum + lo;
  return clamp(next, lo, hi);
}

export function hardwareRangeAngle(value, min, max) {
  const lo = Number(min);
  const hi = Number(max);
  const t = hi > lo ? clamp((Number(value) - lo) / (hi - lo), 0, 1) : 0;
  return -135 + t * 270;
}

export function resolveHardwareTargetId(element) {
  return element?.dataset?.actionTarget || element?.dataset?.rangeTarget || element?.dataset?.mirrorTarget || '';
}

export class HardwareSurface extends EventTarget {
  constructor({ root = document } = {}) {
    super();
    this.root = root;
    this.controls = [];
    this.lastSyncAt = 0;
    this.activeGestures = new WeakMap();
    this.observer = null;
  }

  init() {
    this.controls = [...this.root.querySelectorAll('[data-action-target],[data-range-target],[data-mirror-target]')];
    for (const control of this.controls) this.#bindControl(control);

    for (const platter of this.root.querySelectorAll('[data-hardware-platter]')) {
      const deckId = platter.dataset.hardwarePlatter === 'B' ? 'B' : 'A';
      for (const type of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel']) {
        platter.addEventListener(type, (event) => {
          this.dispatchEvent(new CustomEvent('platter-pointer', { detail: { deckId, element: platter, event } }));
        });
      }
      platter.addEventListener('keydown', (event) => {
        this.dispatchEvent(new CustomEvent('platter-key', { detail: { deckId, element: platter, event } }));
      });
    }

    this.observer = new MutationObserver(() => this.sync());
    for (const control of this.controls) {
      const target = this.#targetFor(control);
      if (target) this.observer.observe(target, { attributes: true, childList: true, characterData: true, subtree: true });
    }
    this.sync(true);
  }

  sync(force = false, now = performance.now()) {
    if (!force && now - this.lastSyncAt < 80) return;
    this.lastSyncAt = now;
    for (const control of this.controls) this.#syncControl(control);
  }

  destroy() {
    this.observer?.disconnect();
    this.controls = [];
  }

  #bindControl(control) {
    const target = this.#targetFor(control);
    if (!target) {
      control.dataset.hardwareMissing = 'true';
      return;
    }

    if (control.dataset.actionTarget) {
      control.addEventListener('click', (event) => {
        if (control.disabled || target.disabled) return;
        target.click();
        this.#emitAction(control, target, 'press', event.shiftKey ? 'shift' : 'normal');
        queueMicrotask(() => this.sync(true));
      });
      control.addEventListener('contextmenu', (event) => {
        if (control.disabled || target.disabled || !control.dataset.contextTarget) return;
        event.preventDefault();
        const alternate = this.root.querySelector(`#${CSS.escape(control.dataset.contextTarget)}`);
        alternate?.click();
      });
    }

    if (control.dataset.rangeTarget) {
      const commit = () => {
        if (control.disabled || target.disabled) return;
        target.value = String(normalizeHardwareRange(control.value, target.min, target.max, target.step));
        target.dispatchEvent(new Event('input', { bubbles: true }));
        control.value = target.value;
        this.#paintRange(control);
        this.#emitAction(control, target, 'range', target.value);
      };
      control.addEventListener('input', commit);
      control.addEventListener('change', () => target.dispatchEvent(new Event('change', { bubbles: true })));

      if (control.classList.contains('hardware-rotary')) {
        control.addEventListener('pointerdown', (event) => {
          if (control.disabled) return;
          control.setPointerCapture(event.pointerId);
          this.activeGestures.set(control, { id: event.pointerId, y: event.clientY, value: Number(control.value) });
          event.preventDefault();
        });
        control.addEventListener('pointermove', (event) => {
          const gesture = this.activeGestures.get(control);
          if (!gesture || gesture.id !== event.pointerId) return;
          const min = Number(control.min);
          const max = Number(control.max);
          control.value = String(normalizeHardwareRange(gesture.value + (gesture.y - event.clientY) / 140 * (max - min), min, max, control.step));
          commit();
          event.preventDefault();
        });
        const end = (event) => {
          const gesture = this.activeGestures.get(control);
          if (!gesture || gesture.id !== event.pointerId) return;
          this.activeGestures.delete(control);
          event.preventDefault();
        };
        control.addEventListener('pointerup', end);
        control.addEventListener('pointercancel', end);
        control.addEventListener('wheel', (event) => {
          if (control.disabled) return;
          const step = Number(control.step) || (Number(control.max) - Number(control.min)) / 100;
          control.value = String(normalizeHardwareRange(Number(control.value) + (event.deltaY < 0 ? step * 4 : -step * 4), control.min, control.max, control.step));
          commit();
          event.preventDefault();
        }, { passive: false });
        control.addEventListener('dblclick', (event) => {
          if (control.disabled) return;
          control.value = String(control.dataset.default ?? target.dataset.default ?? target.value ?? 0);
          commit();
          event.preventDefault();
        });
      }
    }
  }

  #syncControl(control) {
    const target = this.#targetFor(control);
    if (!target) return;
    control.disabled = Boolean(target.disabled);
    control.classList.toggle('is-disabled', Boolean(target.disabled));

    if (control.dataset.rangeTarget && !this.activeGestures.has(control)) {
      control.min = target.min;
      control.max = target.max;
      control.step = target.step;
      control.value = target.value;
      this.#paintRange(control);
      const output = control.closest('[data-hardware-control]')?.querySelector('[data-hardware-value]');
      const canonicalOutputId = control.dataset.outputTarget;
      const canonicalOutput = canonicalOutputId ? this.root.querySelector(`#${CSS.escape(canonicalOutputId)}`) : null;
      if (output && canonicalOutput) output.textContent = canonicalOutput.textContent;
    }

    if (control.dataset.actionTarget) {
      const pressed = target.getAttribute('aria-pressed') === 'true' || target.classList.contains('is-active') || target.classList.contains('is-recording');
      if (control.dataset.stateDriven !== 'true') control.classList.toggle('is-active', pressed);
      control.setAttribute('aria-pressed', String(pressed));
      const mirrorText = control.querySelector('[data-button-text]');
      if (mirrorText && control.dataset.mirrorButtonText !== 'false') mirrorText.textContent = target.textContent.trim();
    }

    if (control.dataset.mirrorTarget) control.textContent = target.textContent;
  }

  #paintRange(control) {
    const angle = hardwareRangeAngle(control.value, control.min, control.max);
    control.parentElement?.style.setProperty('--hardware-angle', `${angle.toFixed(2)}deg`);
    const min = Number(control.min);
    const max = Number(control.max);
    const pct = max > min ? (Number(control.value) - min) / (max - min) * 100 : 0;
    control.style.setProperty('--hardware-value', `${clamp(pct, 0, 100).toFixed(2)}%`);
  }

  #targetFor(control) {
    const id = resolveHardwareTargetId(control);
    return id ? this.root.querySelector(`#${CSS.escape(id)}`) : null;
  }

  #emitAction(control, target, kind, value) {
    this.dispatchEvent(new CustomEvent('hardware-action', {
      detail: { kind, value, controlId: control.id || '', targetId: target.id || '' },
    }));
  }
}
