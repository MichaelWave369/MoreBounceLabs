export function decideVisualProtection({
  mode = 'crt', selected = 'auto', current = 'full', fps = 60,
  lowFpsStreak = 0, severeFpsStreak = 0, recoveryStreak = 0,
  longTasksDelta = 0, audioWarning = false, rendererFault = false,
} = {}) {
  if (rendererFault) return { mode: 'flat', quality: current, reason: 'Renderer fault → Safe Flat' };
  if (audioWarning) return { mode: 'flat', quality: 'off', reason: 'Audio health warning → Safe Flat' };
  if (mode === 'flat') return { mode, quality: current, reason: null };
  if (selected !== 'auto') return { mode, quality: selected === 'off' ? 'off' : selected, reason: null };
  if (severeFpsStreak >= 3) return { mode: 'flat', quality: 'off', reason: `Severe visual pressure (${Math.round(fps)} FPS) → Safe Flat` };
  if (lowFpsStreak >= 4 || longTasksDelta >= 3) return { mode, quality: 'reduced', reason: longTasksDelta >= 3 ? 'Long-task pressure → Clean CRT' : `Visual pressure (${Math.round(fps)} FPS) → Clean CRT` };
  if (current === 'reduced' && recoveryStreak >= 10) return { mode, quality: 'full', reason: 'Visual headroom recovered → Full CRT' };
  return { mode, quality: current, reason: null };
}

export class QualityManager extends EventTarget {
  constructor({ selected = 'auto', mode = 'crt', quality = 'full' } = {}) {
    super();
    this.selected = selected;
    this.mode = mode;
    this.quality = quality;
    this.lowFpsStreak = 0;
    this.severeFpsStreak = 0;
    this.recoveryStreak = 0;
    this.lastLongTasks = 0;
  }

  setPolicy(selected) {
    this.selected = ['auto', 'full', 'reduced', 'off'].includes(selected) ? selected : 'auto';
    this.#evaluate({ fps: 60, longTasksDelta: 0 });
  }

  setMode(mode) { this.mode = mode === 'flat' ? 'flat' : 'crt'; }
  setQuality(quality) { this.quality = ['full', 'reduced', 'off'].includes(quality) ? quality : 'full'; }

  reportFrame({ fps = 60, longTasks = this.lastLongTasks } = {}) {
    const safeFps = Number.isFinite(fps) ? fps : 60;
    this.lowFpsStreak = safeFps < 26 ? this.lowFpsStreak + 1 : Math.max(0, this.lowFpsStreak - 1);
    this.severeFpsStreak = safeFps < 17 ? this.severeFpsStreak + 1 : 0;
    this.recoveryStreak = safeFps > 50 ? this.recoveryStreak + 1 : 0;
    const longTasksDelta = Math.max(0, Number(longTasks || 0) - this.lastLongTasks);
    this.lastLongTasks = Number(longTasks || 0);
    this.#evaluate({ fps: safeFps, longTasksDelta });
  }

  reportAudioWarning(reason = 'Audio health warning') {
    this.#evaluate({ fps: 60, longTasksDelta: 0, audioWarning: true, overrideReason: reason });
  }

  reportRendererFault(reason = 'Renderer fault') {
    this.#evaluate({ fps: 0, longTasksDelta: 0, rendererFault: true, overrideReason: reason });
  }

  #evaluate({ fps, longTasksDelta, audioWarning = false, rendererFault = false, overrideReason = '' }) {
    const decision = decideVisualProtection({
      mode: this.mode, selected: this.selected, current: this.quality, fps,
      lowFpsStreak: this.lowFpsStreak, severeFpsStreak: this.severeFpsStreak,
      recoveryStreak: this.recoveryStreak, longTasksDelta, audioWarning, rendererFault,
    });
    if (overrideReason && decision.reason) decision.reason = `${overrideReason} → ${decision.mode === 'flat' ? 'Safe Flat' : decision.quality}`;
    if (decision.mode === this.mode && decision.quality === this.quality && !decision.reason) return;
    this.mode = decision.mode;
    this.quality = decision.quality;
    this.dispatchEvent(new CustomEvent('decision', { detail: decision }));
  }
}
