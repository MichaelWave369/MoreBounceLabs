const STORAGE_KEY='backspin96.lab-tab.v2';
const COMPACT_KEY='backspin96.lab-compact.v1';
const TABS=new Set(['health','pressure','fault','ledger']);
export function sanitizeLabTab(value){return TABS.has(value)?value:'health';}
export function sanitizeDrawerCompact(value){return value===true||value==='true';}

export class DiagnosticsDrawer extends EventTarget{
  constructor({root=document}={}){super();this.root=root;this.drawer=root.querySelector('#labDrawer');this.content=root.querySelector('#labDrawerContent');this.backdrop=root.querySelector('#labDrawerBackdrop');this.openButton=root.querySelector('#labDrawerOpen');this.closeButton=root.querySelector('#labDrawerClose');this.compactButton=root.querySelector('#labDrawerCompact');this.tabs=[...root.querySelectorAll('[data-lab-tab]')];this.tab='health';this.compact=false;this.lastFocus=null;this.opened=false;}
  init(){
    const pressure=this.root.querySelector('.stress-panel'),health=this.root.querySelector('.health-panel');
    if(pressure){pressure.dataset.labPanel='pressure';this.content?.append(pressure);}if(health){health.dataset.labPanel='health';this.content?.append(health);}
    this.closeButton?.addEventListener('click',()=>this.dispatchEvent(new Event('close-request')));
    this.compactButton?.addEventListener('click',()=>this.setCompact(!this.compact));
    this.tabs.forEach((tab)=>tab.addEventListener('click',()=>this.setTab(tab.dataset.labTab)));
    this.drawer?.addEventListener('keydown',(event)=>{if(event.code==='Escape'){event.preventDefault();this.dispatchEvent(new Event('close-request'));}});
    this.setTab(this.#loadTab());this.setCompact(this.#loadCompact(),{persist:false});this.close({restoreFocus:false,silent:true});
  }
  open({focus=true,silent=false}={}){if(!this.drawer)return;this.lastFocus=document.activeElement;this.opened=true;this.drawer.hidden=false;if(this.backdrop)this.backdrop.hidden=true;this.drawer.setAttribute('aria-hidden','false');this.#syncTriggerButton();this.#syncLayout();if(focus)requestAnimationFrame(()=>this.drawer.querySelector('[role="tab"].is-active,button,select,input')?.focus());this.dispatchEvent(new CustomEvent('drawer-layout-change',{detail:this.exportState()}));if(!silent)this.dispatchEvent(new CustomEvent('drawer-change',{detail:{open:true,tab:this.tab,compact:this.compact}}));}
  close({restoreFocus=true,silent=false}={}){if(!this.drawer)return;this.opened=false;this.drawer.hidden=true;if(this.backdrop)this.backdrop.hidden=true;this.drawer.setAttribute('aria-hidden','true');this.#syncTriggerButton();this.#syncLayout();if(restoreFocus&&this.lastFocus instanceof HTMLElement)this.lastFocus.focus();this.dispatchEvent(new CustomEvent('drawer-layout-change',{detail:this.exportState()}));if(!silent)this.dispatchEvent(new CustomEvent('drawer-change',{detail:{open:false,tab:this.tab,compact:this.compact}}));}
  setTab(tab){this.tab=sanitizeLabTab(tab);if(this.drawer)this.drawer.dataset.tab=this.tab;this.tabs.forEach((node)=>{const active=node.dataset.labTab===this.tab;node.classList.toggle('is-active',active);node.setAttribute('aria-selected',String(active));});try{localStorage.setItem(STORAGE_KEY,this.tab);}catch{}this.dispatchEvent(new CustomEvent('tab-change',{detail:{tab:this.tab}}));}
  setCompact(value,{persist=true}={}){this.compact=sanitizeDrawerCompact(value);if(this.drawer)this.drawer.dataset.compact=String(this.compact);if(this.compactButton){this.compactButton.textContent=this.compact?'EXPAND':'COMPACT';this.compactButton.setAttribute('aria-pressed',String(this.compact));}if(persist)try{localStorage.setItem(COMPACT_KEY,String(this.compact));}catch{}this.#syncLayout();this.dispatchEvent(new CustomEvent('drawer-layout-change',{detail:this.exportState()}));}
  exportState(){const height=this.opened&&this.drawer&&!this.drawer.hidden?Math.round(this.drawer.getBoundingClientRect().height):0;return{open:this.opened,tab:this.tab,compact:this.compact,height};}
  #syncTriggerButton(){if(!this.openButton)return;this.openButton.textContent=this.opened?'CLOSE LAB':'OPEN LAB';this.openButton.setAttribute('aria-expanded',String(this.opened));this.openButton.dataset.drawerAuthority=this.opened?'open':'closed';}
  #syncLayout(){document.body.dataset.labOpen=String(this.opened);document.body.dataset.labCompact=String(this.compact);if(this.drawer)this.drawer.toggleAttribute('hidden',!this.opened);requestAnimationFrame(()=>{const height=this.opened&&this.drawer&&!this.drawer.hidden?this.drawer.getBoundingClientRect().height:0;document.body.style.setProperty('--lab-drawer-height',`${Math.round(height)}px`);window.dispatchEvent(new Event('backspin-layout-change'));});}
  #loadTab(){try{return sanitizeLabTab(localStorage.getItem(STORAGE_KEY)||localStorage.getItem('backspin96.lab-tab.v1'));}catch{return'health';}}
  #loadCompact(){try{return sanitizeDrawerCompact(localStorage.getItem(COMPACT_KEY));}catch{return false;}}
}
