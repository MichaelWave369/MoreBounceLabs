const STORAGE_KEY='backspin96.booth-frame.v1';
const FRAMES=new Set(['full','rig']);
export function sanitizeBoothFrame(value){ return FRAMES.has(value)?value:'full'; }
export class FramingController extends EventTarget{
  constructor({root=document.body}={}){super();this.root=root;this.frame='full';this.nodes={full:document.querySelector('#frameFull'),rig:document.querySelector('#frameRig')};}
  init(){
    this.nodes.full?.addEventListener('click',()=>this.setFrame('full','Operator selected Full Booth'));
    this.nodes.rig?.addEventListener('click',()=>this.setFrame('rig','Operator selected Performance Rig'));
    window.addEventListener('keydown',(event)=>{
      if(!event.altKey||!event.shiftKey||event.repeat)return;
      if(event.code==='Digit1'){event.preventDefault();this.setFrame('full','Keyboard Full Booth shortcut');}
      if(event.code==='Digit2'){event.preventDefault();this.setFrame('rig','Keyboard Performance Rig shortcut');}
    });
    this.setFrame(this.#load(),'Restored framing preference',{persist:false});
  }
  setFrame(value,reason='Booth framing changed',{persist=true}={}){
    this.frame=sanitizeBoothFrame(value);this.root.dataset.boothFrame=this.frame;
    for(const[key,node]of Object.entries(this.nodes)){const active=key===this.frame;node?.classList.toggle('is-active',active);node?.setAttribute('aria-pressed',String(active));}
    if(persist)this.#save();window.dispatchEvent(new Event('backspin-layout-change'));
    this.dispatchEvent(new CustomEvent('frame-change',{detail:{frame:this.frame,reason}}));
  }
  exportState(){return{frame:this.frame};}
  #load(){try{return sanitizeBoothFrame(localStorage.getItem(STORAGE_KEY));}catch{return'full';}}
  #save(){try{localStorage.setItem(STORAGE_KEY,this.frame);}catch{}}
}
