const STORAGE_KEY = 'backspin96.presentation.v1';
const MODES = new Set(['booth', 'lab', 'flat']);
export function sanitizePresentationMode(value) { return MODES.has(value) ? value : 'booth'; }

export class ViewModeController extends EventTarget {
  constructor({ root = document.body, shell, drawer } = {}) {
    super(); this.root = root; this.shell = shell; this.drawer = drawer;
    this.nodes = { booth: document.querySelector('#viewCrt'), lab: document.querySelector('#viewLab'), flat: document.querySelector('#viewFlat') };
    this.mode = 'booth';
  }
  init() {
    this.nodes.booth?.addEventListener('click', () => this.setMode('booth', 'Operator selected Booth'));
    this.nodes.lab?.addEventListener('click', () => this.setMode('lab', 'Operator opened Lab'));
    this.nodes.flat?.addEventListener('click', () => this.setMode('flat', 'Operator selected Safe Flat'));
    document.querySelector('#labDrawerOpen')?.addEventListener('click', () => this.mode === 'lab' ? this.setMode('booth', 'Operator closed diagnostics drawer') : this.setMode('lab', 'Operator opened diagnostics drawer'));
    this.drawer?.addEventListener('close-request', () => this.setMode('booth', 'Lab drawer closed'));
    this.drawer?.addEventListener('drawer-change', (event) => {
      if (event.detail.open && this.mode !== 'lab') this.#apply('lab', 'Drawer authority synchronized to Lab', false);
      if (!event.detail.open && this.mode === 'lab') this.#apply('booth', 'Drawer authority synchronized to Booth', false);
    });
    this.shell?.addEventListener('mode-change', (event) => {
      if (event.detail.mode === 'flat' && this.mode !== 'flat') this.#apply('flat', event.detail.reason, false);
    });
    window.addEventListener('keydown', (event) => {
      if (!event.altKey || !event.shiftKey || event.repeat) return;
      if (event.code === 'KeyB') { event.preventDefault(); this.setMode('booth', 'Keyboard Booth shortcut'); }
      if (event.code === 'KeyL') { event.preventDefault(); this.setMode('lab', 'Keyboard Lab shortcut'); }
      if (event.code === 'KeyF') { event.preventDefault(); this.setMode('flat', 'Keyboard Safe Flat shortcut'); }
    });
    const saved = this.#load();
    const initial = this.shell?.settings?.mode === 'flat' ? 'flat' : (saved === 'flat' ? 'flat' : 'booth');
    this.#apply(initial, saved === 'lab' ? 'Lab defaults closed for performance startup' : 'Restored presentation preference', false);
  }
  setMode(mode, reason = 'Presentation changed', persist = true) { this.#apply(sanitizePresentationMode(mode), reason, persist); }
  #apply(mode, reason, persist) {
    this.mode = mode;
    if (mode === 'flat') { this.shell?.setMode('flat', reason, { persist }); this.drawer?.close({ restoreFocus: false, silent: true }); }
    else { this.shell?.setMode('crt', reason, { persist }); mode === 'lab' ? this.drawer?.open({ focus: true, silent: false }) : this.drawer?.close({ restoreFocus: false, silent: false }); }
    this.root.classList.remove('mode-booth', 'mode-lab', 'mode-flat'); this.root.classList.add(`mode-${mode}`); this.root.dataset.viewMode = mode;
    for (const [key, node] of Object.entries(this.nodes)) { node?.classList.toggle('is-active', key === mode); node?.setAttribute('aria-pressed', String(key === mode)); }
    const open = document.querySelector('#labDrawerOpen'); if (open) { open.setAttribute('aria-expanded', String(mode === 'lab')); open.textContent = mode === 'lab' ? 'CLOSE LAB' : 'OPEN LAB'; }
    if (persist) this.#save();
    this.dispatchEvent(new CustomEvent('mode-change', { detail: { mode, reason } }));
  }
  exportState() { return { mode: this.mode }; }
  #load() { try { return sanitizePresentationMode(localStorage.getItem(STORAGE_KEY) || 'booth'); } catch { return 'booth'; } }
  #save() { try { localStorage.setItem(STORAGE_KEY, this.mode); } catch {} }
}
