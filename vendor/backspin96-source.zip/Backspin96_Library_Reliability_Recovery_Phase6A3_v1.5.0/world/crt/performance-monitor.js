const clamp=(value,min,max)=>Math.max(min,Math.min(max,Number(value)||0));
export function rangePercent(value,min=0,max=1){ const span=Number(max)-Number(min); return span>0?clamp((Number(value)-Number(min))/span*100,0,100):0; }
export function meterPercentFromStyle(value){ return clamp(parseFloat(String(value||'0'))||0,0,100); }

export class PerformanceMonitor {
  constructor({root=document}={}){
    this.root=root; this.raf=0; this.lastDraw=0; this.active=true;
    this.source={A:root.querySelector('#a-waveform'),B:root.querySelector('#b-waveform')};
    this.dest={A:root.querySelector('#crtWaveA'),B:root.querySelector('#crtWaveB')};
    this.seek={A:root.querySelector('#a-seek'),B:root.querySelector('#b-seek')};
    this.progress={A:root.querySelector('#crtAProgress'),B:root.querySelector('#crtBProgress')};
    this.state={A:root.querySelector('#a-state'),B:root.querySelector('#b-state')};
    this.lamps={A:root.querySelector('#crtAStateLamp'),B:root.querySelector('#crtBStateLamp')};
    this.crossfader=root.querySelector('#crossfader'); this.xfadeThumb=root.querySelector('#crtXfadeThumb');
    this.meters={A:root.querySelector('#meterA'),master:root.querySelector('#meterMaster'),B:root.querySelector('#meterB')};
    this.monitorMeters={A:root.querySelector('#crtMeterA'),master:root.querySelector('#crtMeterMaster'),B:root.querySelector('#crtMeterB')};
    this.recordLamp=root.querySelector('#crtRecordLamp'); this.clock=root.querySelector('#crtMonitorClock');
  }
  init(){
    this.observer=new MutationObserver(()=>this.sync());
    for(const mirror of this.root.querySelectorAll('[data-monitor-mirror]')){ const target=this.root.querySelector(`#${CSS.escape(mirror.dataset.monitorMirror)}`); if(target)this.observer.observe(target,{childList:true,characterData:true,subtree:true,attributes:true}); }
    for(const node of [this.crossfader,...Object.values(this.seek)]) node?.addEventListener('input',()=>this.sync());
    this.sync(); this.#frame(performance.now());
  }
  sync(){
    for(const mirror of this.root.querySelectorAll('[data-monitor-mirror]')){ const target=this.root.querySelector(`#${CSS.escape(mirror.dataset.monitorMirror)}`); if(target)mirror.textContent=target.textContent; }
    for(const deckId of ['A','B']){
      const seek=this.seek[deckId]; const pct=seek?rangePercent(seek.value,seek.min,seek.max):0; this.progress[deckId]?.style.setProperty('--progress',`${pct}%`);
      const label=this.state[deckId]?.textContent?.trim()||'IDLE'; const active=['PLAYING','SCRATCH','LOOP'].some((word)=>label.includes(word));
      if(this.lamps[deckId])this.lamps[deckId].dataset.state=active?'active':label.includes('FAULT')||label.includes('STALLED')?'bad':'idle';
    }
    const x=this.crossfader?rangePercent(this.crossfader.value,this.crossfader.min,this.crossfader.max):50; this.xfadeThumb?.style.setProperty('--xfade',`${x}%`);
    for(const key of ['A','master','B']){ const pct=meterPercentFromStyle(this.meters[key]?.style.height); this.monitorMeters[key]?.style.setProperty('--meter',`${pct}%`); }
    const rec=this.root.querySelector('#recordingState')?.textContent||'READY'; if(this.recordLamp)this.recordLamp.dataset.state=rec.includes('RECORDING')?'active':'idle';
  }
  exportState(){ return {active:this.active,source:'canonical-waveform-mirror',authority:'none'}; }
  #frame(now){
    if(now-this.lastDraw>33){ this.lastDraw=now; this.sync(); this.#drawWave('A'); this.#drawWave('B'); if(this.clock)this.clock.textContent=new Date().toLocaleTimeString([],{hour12:false}); }
    this.raf=requestAnimationFrame((time)=>this.#frame(time));
  }
  #drawWave(deckId){
    const source=this.source[deckId],dest=this.dest[deckId]; if(!source||!dest)return; const rect=dest.getBoundingClientRect(); const dpr=Math.min(2,devicePixelRatio||1); const width=Math.max(10,Math.floor(rect.width*dpr)),height=Math.max(10,Math.floor(rect.height*dpr));
    if(dest.width!==width||dest.height!==height){dest.width=width;dest.height=height;}
    const ctx=dest.getContext('2d'); if(!ctx)return; ctx.clearRect(0,0,width,height); ctx.imageSmoothingEnabled=true;
    try{ctx.drawImage(source,0,0,width,height);}catch{}
    const gradient=ctx.createLinearGradient(0,0,width,0); if(deckId==='A'){gradient.addColorStop(0,'rgba(43,233,255,.16)');gradient.addColorStop(1,'rgba(204,73,255,.12)');}else{gradient.addColorStop(0,'rgba(255,176,64,.13)');gradient.addColorStop(1,'rgba(255,72,154,.15)');} ctx.fillStyle=gradient;ctx.fillRect(0,0,width,height);
    ctx.strokeStyle='rgba(255,255,255,.45)';ctx.lineWidth=Math.max(1,dpr);ctx.beginPath();ctx.moveTo(width/2,0);ctx.lineTo(width/2,height);ctx.stroke();
  }
}
