const STORAGE_KEY = 'backspin96.visual-world.v1';

export const DEFAULT_CRT_SETTINGS = Object.freeze({
  mode: 'crt',
  quality: 'auto',
  scanlines: 42,
  glow: 58,
  curvature: 44,
  reflection: 30,
});

const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));

export function sanitizeCrtSettings(candidate = {}) {
  return {
    mode: candidate.mode === 'flat' ? 'flat' : 'crt',
    quality: ['auto', 'full', 'reduced', 'off'].includes(candidate.quality) ? candidate.quality : 'auto',
    scanlines: clamp(candidate.scanlines ?? DEFAULT_CRT_SETTINGS.scanlines, 0, 100),
    glow: clamp(candidate.glow ?? DEFAULT_CRT_SETTINGS.glow, 0, 100),
    curvature: clamp(candidate.curvature ?? DEFAULT_CRT_SETTINGS.curvature, 0, 100),
    reflection: clamp(candidate.reflection ?? DEFAULT_CRT_SETTINGS.reflection, 0, 100),
  };
}

export class CrtShell extends EventTarget {
  constructor(root = document.body) {
    super();
    this.root = root;
    this.nodes = {
      viewCrt: document.querySelector('#viewCrt'),
      viewFlat: document.querySelector('#viewFlat'),
      quality: document.querySelector('#visualQuality'),
      qualityPill: document.querySelector('#visualQualityPill'),
      reason: document.querySelector('#visualModeReason'),
      scanlines: document.querySelector('#crtScanlines'),
      glow: document.querySelector('#crtGlow'),
      curvature: document.querySelector('#crtCurvature'),
      reflection: document.querySelector('#crtReflection'),
      scanlinesValue: document.querySelector('#crtScanlinesValue'),
      glowValue: document.querySelector('#crtGlowValue'),
      curvatureValue: document.querySelector('#crtCurvatureValue'),
      reflectionValue: document.querySelector('#crtReflectionValue'),
    };
    this.settings = this.#load();
    this.effectiveQuality = 'full';
  }

  init() {
    this.nodes.viewCrt?.addEventListener('click', () => this.setMode('crt', 'Operator selected CRT Surface'));
    this.nodes.viewFlat?.addEventListener('click', () => this.setMode('flat', 'Operator selected Safe Flat'));
    this.nodes.quality?.addEventListener('change', () => {
      this.settings.quality = this.nodes.quality.value;
      this.#save();
      const desired = this.settings.quality === 'auto' ? 'full' : this.settings.quality;
      this.setEffectiveQuality(desired, `Operator quality policy: ${this.settings.quality}`, { persist: false });
      this.dispatchEvent(new CustomEvent('policy-change', { detail: { selected: this.settings.quality } }));
    });

    for (const key of ['scanlines', 'glow', 'curvature', 'reflection']) {
      const input = this.nodes[key];
      input?.addEventListener('input', () => {
        this.settings[key] = clamp(input.value, 0, 100);
        this.applyTuning();
        this.#save();
      });
    }

    window.addEventListener('keydown', (event) => {
      if (!event.altKey || !event.shiftKey || event.repeat) return;
      if (event.code === 'KeyF') {
        event.preventDefault();
        this.setMode('flat', 'Keyboard recovery shortcut');
      }
      if (event.code === 'KeyC') {
        event.preventDefault();
        this.setMode('crt', 'Keyboard CRT shortcut');
      }
    });

    this.nodes.quality && (this.nodes.quality.value = this.settings.quality);
    for (const key of ['scanlines', 'glow', 'curvature', 'reflection']) {
      if (this.nodes[key]) this.nodes[key].value = String(this.settings[key]);
    }
    this.applyTuning();
    this.setMode(this.settings.mode, 'Restored local view preference', { persist: false });
    this.setEffectiveQuality(this.settings.quality === 'auto' ? 'full' : this.settings.quality, 'Restored local quality policy', { persist: false });
  }

  setMode(mode, reason = 'View mode changed', { persist = true } = {}) {
    const next = mode === 'flat' ? 'flat' : 'crt';
    this.settings.mode = next;
    this.root.classList.toggle('view-crt', next === 'crt');
    this.root.classList.toggle('view-flat', next === 'flat');
    this.nodes.viewCrt?.classList.toggle('is-active', next === 'crt');
    this.nodes.viewFlat?.classList.toggle('is-active', next === 'flat');
    this.nodes.viewCrt?.setAttribute('aria-pressed', String(next === 'crt'));
    this.nodes.viewFlat?.setAttribute('aria-pressed', String(next === 'flat'));
    if (next === 'flat') {
      this.nodes.qualityPill && (this.nodes.qualityPill.textContent = 'SAFE FLAT');
      this.nodes.qualityPill && (this.nodes.qualityPill.className = 'pill pill-ok');
    } else {
      this.#paintQualityPill();
    }
    if (this.nodes.reason) this.nodes.reason.textContent = reason;
    if (persist) this.#save();
    this.dispatchEvent(new CustomEvent('mode-change', { detail: { mode: next, reason } }));
  }

  setEffectiveQuality(quality, reason = 'Quality changed', { persist = false } = {}) {
    const next = ['full', 'reduced', 'off'].includes(quality) ? quality : 'full';
    this.effectiveQuality = next;
    this.root.classList.remove('crt-effects-full', 'crt-effects-reduced', 'crt-effects-off');
    this.root.classList.add(`crt-effects-${next}`);
    if (this.settings.mode === 'crt') this.#paintQualityPill();
    if (this.nodes.reason) this.nodes.reason.textContent = reason;
    if (persist) {
      this.settings.quality = next;
      if (this.nodes.quality) this.nodes.quality.value = next;
      this.#save();
    }
    this.dispatchEvent(new CustomEvent('quality-change', { detail: { quality: next, reason } }));
  }

  markAudioWarning(active, reason = '') {
    this.root.classList.toggle('visual-audio-warning', Boolean(active));
    if (active && this.nodes.reason) this.nodes.reason.textContent = reason || 'Audio warning forced visual protection';
  }

  applyTuning() {
    const s = sanitizeCrtSettings(this.settings);
    this.settings = s;
    const scan = s.scanlines / 100;
    const glow = s.glow / 100;
    const curve = s.curvature / 100;
    const reflection = s.reflection / 100;
    const style = this.root.style;
    style.setProperty('--crt-scanline-opacity', scan.toFixed(3));
    style.setProperty('--crt-glow-strength', glow.toFixed(3));
    style.setProperty('--crt-curvature', curve.toFixed(3));
    style.setProperty('--crt-reflection-opacity', reflection.toFixed(3));
    style.setProperty('--crt-case-glow', `${Math.round(5 + glow * 42)}px`);
    style.setProperty('--crt-screen-glow', `${Math.round(8 + glow * 62)}px`);
    style.setProperty('--crt-frame-radius', `${Math.round(16 + curve * 24)}px`);
    style.setProperty('--crt-screen-radius-x', `${Math.round(10 + curve * 42)}px`);
    style.setProperty('--crt-screen-radius-y', `${Math.round(7 + curve * 28)}px`);
    style.setProperty('--crt-screen-tilt', `${((curve - .5) * .22).toFixed(3)}deg`);
    style.setProperty('--crt-vignette-size', `${Math.round(75 + curve * 120)}px`);
    for (const key of ['scanlines', 'glow', 'curvature', 'reflection']) {
      if (this.nodes[`${key}Value`]) this.nodes[`${key}Value`].textContent = `${Math.round(s[key])}%`;
    }
  }

  #paintQualityPill() {
    if (!this.nodes.qualityPill) return;
    const labels = { full: 'FULL CRT', reduced: 'CLEAN CRT', off: 'EFFECTS OFF' };
    this.nodes.qualityPill.textContent = labels[this.effectiveQuality] || 'FULL CRT';
    this.nodes.qualityPill.className = this.effectiveQuality === 'off' ? 'pill pill-idle' : 'pill pill-ok';
  }

  #load() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      return sanitizeCrtSettings(raw ? JSON.parse(raw) : DEFAULT_CRT_SETTINGS);
    } catch {
      return { ...DEFAULT_CRT_SETTINGS };
    }
  }

  #save() {
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(sanitizeCrtSettings(this.settings))); }
    catch {}
  }
}
