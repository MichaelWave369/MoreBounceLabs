const STORAGE_KEY='backspin96.crt-source.v4';
const SOURCES=new Set(['performance','tunnel','health','library']);
export function sanitizeCrtSource(value){ return SOURCES.has(value)?value:'performance'; }
export class CrtSourceRouter extends EventTarget{
  constructor({root=document}={}){super();this.root=root;this.select=root.querySelector('#crtSourceSelect');this.layer=root.querySelector('#crtSourceLayer');this.instrument=root.querySelector('#instrumentSurface');this.performancePanel=root.querySelector('#crtSourcePerformance');this.tunnelPanel=root.querySelector('#crtSourceTunnel');this.healthPanel=root.querySelector('#crtSourceHealth');this.libraryPanel=root.querySelector('#crtSourceLibrary');this.tunnelHost=root.querySelector('#crtSourceTunnelHost');this.visualHost=root.querySelector('#visualHost');this.visualHome=null;this.visualNext=null;this.source='performance';this.observer=null;this.switchTimer=0;}
  init(){
    if(this.visualHost){this.visualHome=this.visualHost.parentNode;this.visualNext=this.visualHost.nextSibling;}
    this.select?.addEventListener('change',()=>this.setSource(this.select.value,'Operator selected CRT source'));
    window.addEventListener('keydown',(event)=>{if(!event.altKey||!event.shiftKey||event.repeat)return;if(event.code==='KeyP'){event.preventDefault();this.setSource('performance','Keyboard Performance Monitor shortcut');}if(event.code==='KeyT'){event.preventDefault();this.setSource('tunnel','Keyboard Signal Tunnel shortcut');}if(event.code==='KeyH'){event.preventDefault();this.setSource('health','Keyboard Health source shortcut');}if(event.code==='KeyY'){event.preventDefault();this.setSource('library','Keyboard Crate Library shortcut');}});
    this.observer=new MutationObserver(()=>this.syncMirrors());
    for(const node of this.root.querySelectorAll('[data-source-mirror]')){const target=this.root.querySelector(`#${CSS.escape(node.dataset.sourceMirror)}`);if(target)this.observer.observe(target,{childList:true,characterData:true,subtree:true,attributes:true});}
    this.setSource(this.#load(),'Restored CRT source',{persist:false,animate:false});this.syncMirrors();
  }
  setSource(source,reason='CRT source changed',{persist=true,animate=true}={}){
    const next=sanitizeCrtSource(source);this.source=next;if(this.select)this.select.value=next;if(this.layer)this.layer.hidden=false;
    if(animate&&this.layer){this.layer.classList.remove('is-switching');void this.layer.offsetWidth;this.layer.classList.add('is-switching');clearTimeout(this.switchTimer);this.switchTimer=setTimeout(()=>this.layer?.classList.remove('is-switching'),260);}
    if(this.performancePanel)this.performancePanel.hidden=next!=='performance';if(this.tunnelPanel)this.tunnelPanel.hidden=next!=='tunnel';if(this.healthPanel)this.healthPanel.hidden=next!=='health';if(this.libraryPanel)this.libraryPanel.hidden=next!=='library';
    if(next==='tunnel')this.#mountVisual(this.tunnelHost);else this.#restoreVisual();document.body.dataset.crtSource=next;if(persist)this.#save();this.syncMirrors();this.dispatchEvent(new CustomEvent('source-change',{detail:{source:next,reason}}));
  }
  syncMirrors(){for(const mirror of this.root.querySelectorAll('[data-source-mirror]')){const target=this.root.querySelector(`#${CSS.escape(mirror.dataset.sourceMirror)}`);if(target)mirror.textContent=target.textContent;}}
  exportState(){return{source:this.source,performanceDisplay:'dedicated-monitor',libraryDisplay:'smart-crate-and-automix-queue',sourceHotkeys:true,canonicalInstrument:'preserved-for-flat-and-bindings'};}
  #mountVisual(parent){if(this.visualHost&&parent&&this.visualHost.parentNode!==parent)parent.append(this.visualHost);}
  #restoreVisual(){if(!this.visualHost||!this.visualHome||this.visualHost.parentNode===this.visualHome)return;if(this.visualNext&&this.visualNext.parentNode===this.visualHome)this.visualHome.insertBefore(this.visualHost,this.visualNext);else this.visualHome.append(this.visualHost);}
  #load(){try{return sanitizeCrtSource(localStorage.getItem(STORAGE_KEY)||localStorage.getItem('backspin96.crt-source.v3')||localStorage.getItem('backspin96.crt-source.v2')||localStorage.getItem('backspin96.crt-source.v1'));}catch{return'performance';}}
  #save(){try{localStorage.setItem(STORAGE_KEY,this.source);}catch{}}
}
