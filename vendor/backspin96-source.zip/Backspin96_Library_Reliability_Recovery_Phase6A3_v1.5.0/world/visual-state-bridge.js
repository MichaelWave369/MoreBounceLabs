const clamp = (value, min, max) => Math.max(min, Math.min(max, Number(value) || 0));
const finite = (value, fallback = 0) => Number.isFinite(Number(value)) ? Number(value) : fallback;

export function dbToVisualPercent(db) {
  const value = Number(db);
  if (!Number.isFinite(value) || value <= -60) return 0;
  return clamp((value + 60) / 60 * 100, 0, 100);
}

export function normalizeVisualSnapshot(snapshot = {}) {
  const normalizeDeck = (deck = {}) => ({
    angle: finite(deck.angle),
    playing: Boolean(deck.playing),
    mode: String(deck.mode || 'ready').slice(0, 18),
    bpm: clamp(deck.bpm, 0, 999.9),
    liveBpm: clamp(deck.liveBpm, 0, 999.9),
    loop: Boolean(deck.loop),
  });
  return {
    sequence: Math.max(0, Math.floor(finite(snapshot.sequence))),
    decks: { A: normalizeDeck(snapshot.decks?.A), B: normalizeDeck(snapshot.decks?.B) },
    mixer: {
      crossfader: clamp(snapshot.mixer?.crossfader, -1, 1),
      meterA: dbToVisualPercent(snapshot.mixer?.meterA),
      meterB: dbToVisualPercent(snapshot.mixer?.meterB),
      meterMaster: dbToVisualPercent(snapshot.mixer?.meterMaster),
      recording: Boolean(snapshot.mixer?.recording),
      automix: Boolean(snapshot.mixer?.automix),
    },
    health: { audioWarning: Boolean(snapshot.health?.audioWarning) },
  };
}

export class VisualStateBridge {
  constructor(root = document) {
    this.root = root;
    this.fxRoot = root?.documentElement || document.documentElement;
    this.body = root?.body || document.body;
    this.lastSequence = -1;
    this.lastPaintAt = 0;
    this.nodes = {
      A: {
        platter: root.querySelector('#rigAPlatter'), bpm: root.querySelector('#rigABpm'), status: root.querySelector('#rigAStatus'),
        tonearm: root.querySelector('#rigATonearm'), play: root.querySelector('#rigAPlay'),
      },
      B: {
        platter: root.querySelector('#rigBPlatter'), bpm: root.querySelector('#rigBBpm'), status: root.querySelector('#rigBStatus'),
        tonearm: root.querySelector('#rigBTonearm'), play: root.querySelector('#rigBPlay'),
      },
      meterA: root.querySelector('#rigMeterA'), meterB: root.querySelector('#rigMeterB'), meterMaster: root.querySelector('#rigMeterMaster'),
      crossfader: root.querySelector('#rigCrossfader'), recording: root.querySelector('#rigRecordingLamp'), automix: root.querySelector('#rigAutomixLamp'),
    };
  }

  update(candidate, now = performance.now()) {
    const snapshot = normalizeVisualSnapshot(candidate);
    if (snapshot.sequence < this.lastSequence || now - this.lastPaintAt < 30) return false;
    this.lastSequence = snapshot.sequence;
    this.lastPaintAt = now;
    for (const deckId of ['A', 'B']) {
      const deck = snapshot.decks[deckId];
      const nodes = this.nodes[deckId];
      if (nodes.platter) {
        nodes.platter.style.transform = `rotate(${deck.angle}rad)`;
        nodes.platter.setAttribute('aria-valuenow', deck.playing ? '1' : '0');
      }
      if (nodes.bpm) nodes.bpm.textContent = deck.liveBpm > 0 ? `${deck.liveBpm.toFixed(1)} BPM` : deck.bpm > 0 ? `${deck.bpm.toFixed(1)} BPM` : '— BPM';
      if (nodes.status) {
        nodes.status.classList.toggle('is-on', deck.playing);
        nodes.status.title = deck.playing ? `${deck.mode} / playing` : 'ready / stopped';
      }
      nodes.play?.classList.toggle('is-active', deck.playing);
      if (nodes.tonearm) {
        nodes.tonearm.classList.toggle('is-playing', deck.playing);
        nodes.tonearm.classList.toggle('is-scratch', deck.mode === 'scratch');
      }
    }
    if (this.nodes.meterA) this.nodes.meterA.style.height = `${snapshot.mixer.meterA.toFixed(1)}%`;
    if (this.nodes.meterB) this.nodes.meterB.style.height = `${snapshot.mixer.meterB.toFixed(1)}%`;
    if (this.nodes.meterMaster) this.nodes.meterMaster.style.height = `${snapshot.mixer.meterMaster.toFixed(1)}%`;
    if (this.nodes.crossfader && document.activeElement !== this.nodes.crossfader) this.nodes.crossfader.value = String(snapshot.mixer.crossfader);
    this.nodes.recording?.classList.toggle('is-on', snapshot.mixer.recording);
    this.nodes.automix?.classList.toggle('is-on', snapshot.mixer.automix);

    this.#syncReactiveState(snapshot);
    return true;
  }

  #syncReactiveState(snapshot) {
    this.fxRoot?.style.setProperty('--reactive-a', snapshot.mixer.meterA.toFixed(1));
    this.fxRoot?.style.setProperty('--reactive-b', snapshot.mixer.meterB.toFixed(1));
    this.fxRoot?.style.setProperty('--reactive-master', snapshot.mixer.meterMaster.toFixed(1));
    if (this.body) {
      this.body.classList.toggle('deck-a-playing', snapshot.decks.A.playing);
      this.body.classList.toggle('deck-b-playing', snapshot.decks.B.playing);
      this.body.classList.toggle('recording-active', snapshot.mixer.recording);
      this.body.classList.toggle('automix-active', snapshot.mixer.automix);
      this.body.dataset.crossfaderSide = snapshot.mixer.crossfader < -0.2 ? 'a' : snapshot.mixer.crossfader > 0.2 ? 'b' : 'center';
    }
  }
}
