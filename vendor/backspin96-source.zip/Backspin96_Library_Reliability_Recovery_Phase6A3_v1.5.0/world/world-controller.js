import { CrtShell } from './crt/crt-shell.js';
import { QualityManager } from './quality-manager.js';
import { VisualStateBridge } from './visual-state-bridge.js';

export class WorldController extends EventTarget {
  constructor({ root = document.body } = {}) {
    super();
    this.shell = new CrtShell(root);
    this.bridge = new VisualStateBridge(document);
    this.quality = new QualityManager();
    this.lastUnderruns = { A: 0, B: 0 };
  }

  init() {
    this.shell.init();
    this.quality.setPolicy(this.shell.settings.quality);
    this.quality.setMode(this.shell.settings.mode);
    this.quality.setQuality(this.shell.effectiveQuality);

    this.shell.addEventListener('mode-change', (event) => {
      this.quality.setMode(event.detail.mode);
      this.#emit('mode', event.detail);
    });
    this.shell.addEventListener('quality-change', (event) => {
      this.quality.setQuality(event.detail.quality);
      this.#emit('quality', event.detail);
    });
    this.shell.addEventListener('policy-change', (event) => this.quality.setPolicy(event.detail.selected));
    this.quality.addEventListener('decision', (event) => {
      const { mode, quality, reason } = event.detail;
      if (mode !== this.shell.settings.mode) this.shell.setMode(mode, reason, { persist: false });
      if (quality !== this.shell.effectiveQuality) this.shell.setEffectiveQuality(quality, reason, { persist: false });
      this.#emit('protection', event.detail);
    });
  }

  updateSnapshot(snapshot, now) {
    this.bridge.update(snapshot, now);
    const underrunsA = Math.max(0, Number(snapshot?.health?.underrunsA) || 0);
    const underrunsB = Math.max(0, Number(snapshot?.health?.underrunsB) || 0);
    const newUnderrun = underrunsA > this.lastUnderruns.A || underrunsB > this.lastUnderruns.B;
    this.lastUnderruns = { A: underrunsA, B: underrunsB };
    if (newUnderrun) {
      this.shell.markAudioWarning(true, 'New audio underrun detected');
      this.quality.reportAudioWarning('New audio underrun detected');
      setTimeout(() => this.shell.markAudioWarning(false), 2500);
    }
  }

  reportFrameMetrics(fps, longTasks) { this.quality.reportFrame({ fps, longTasks }); }
  reportRendererState(state) {
    if (['killed', 'fault', 'lost'].includes(state)) this.quality.reportRendererFault(`Visual renderer ${state}`);
  }

  exportState() {
    return {
      mode: this.shell.settings.mode,
      buildSlice: '5D.1a',
      selectedQuality: this.shell.settings.quality,
      effectiveQuality: this.shell.effectiveQuality,
      tuning: {
        scanlines: this.shell.settings.scanlines,
        glow: this.shell.settings.glow,
        curvature: this.shell.settings.curvature,
        reflection: this.shell.settings.reflection,
      },
    };
  }

  #emit(kind, detail) { this.dispatchEvent(new CustomEvent('world-event', { detail: { kind, ...detail } })); }
}
