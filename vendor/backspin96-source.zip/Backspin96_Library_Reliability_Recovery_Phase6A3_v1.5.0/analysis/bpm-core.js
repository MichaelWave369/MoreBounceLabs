import { normalizeBpm } from '../performance/tempo.js';

export function detectBpmFromMono(samples, sampleRate, options = {}) {
  const minBpm = options.minBpm ?? 70;
  const maxBpm = options.maxBpm ?? 180;
  const maxSeconds = options.maxSeconds ?? 90;
  const envelopeRate = options.envelopeRate ?? 200;
  if (!(samples instanceof Float32Array) || samples.length < sampleRate * 4 || !Number.isFinite(sampleRate) || sampleRate <= 0) {
    return { bpm: null, confidence: 0, reason: 'insufficient-audio' };
  }

  const usableLength = Math.min(samples.length, Math.floor(sampleRate * maxSeconds));
  const hop = Math.max(32, Math.floor(sampleRate / envelopeRate));
  const envelopeLength = Math.floor(usableLength / hop);
  const energy = new Float32Array(envelopeLength);

  let previous = 0;
  let meanOnset = 0;
  for (let frame = 0; frame < envelopeLength; frame += 1) {
    const start = frame * hop;
    const end = Math.min(start + hop, usableLength);
    let sum = 0;
    for (let i = start; i < end; i += 1) sum += samples[i] * samples[i];
    const rms = Math.sqrt(sum / Math.max(1, end - start));
    const onset = Math.max(0, rms - previous * 0.88);
    previous = previous * 0.68 + rms * 0.32;
    energy[frame] = onset;
    meanOnset += onset;
  }
  meanOnset /= Math.max(1, energy.length);

  let variance = 0;
  for (let i = 0; i < energy.length; i += 1) {
    energy[i] = Math.max(0, energy[i] - meanOnset * 0.55);
    variance += energy[i] * energy[i];
  }
  if (variance < 1e-8) return { bpm: null, confidence: 0, reason: 'low-onset-energy' };

  const minLag = Math.floor(envelopeRate * 60 / maxBpm);
  const maxLag = Math.ceil(envelopeRate * 60 / minBpm);
  const scores = [];
  for (let lag = minLag; lag <= maxLag; lag += 1) {
    let cross = 0;
    let leftEnergy = 0;
    let rightEnergy = 0;
    for (let i = lag; i < energy.length; i += 1) {
      const a = energy[i];
      const b = energy[i - lag];
      cross += a * b;
      leftEnergy += a * a;
      rightEnergy += b * b;
    }
    const normalized = cross / Math.sqrt(Math.max(1e-12, leftEnergy * rightEnergy));
    const bpm = envelopeRate * 60 / lag;
    const centerPreference = 1 - Math.min(0.10, Math.abs(bpm - 120) / 1200);
    scores.push({ lag, bpm, score: normalized * centerPreference });
  }

  scores.sort((a, b) => b.score - a.score);
  const best = scores[0];
  if (!best || !Number.isFinite(best.score)) return { bpm: null, confidence: 0, reason: 'no-candidate' };

  // Prefer the slower musically plausible harmonic when it is almost as strong.
  let selected = best;
  const half = scores.find((candidate) => Math.abs(candidate.bpm - best.bpm / 2) < 1.25);
  if (half && half.score >= best.score * 0.88) selected = half;

  const competitors = scores.filter((candidate) => Math.abs(candidate.bpm - selected.bpm) > 2);
  const second = competitors[0]?.score ?? 0;
  const confidence = Math.max(0, Math.min(1, (selected.score - second * 0.72) / Math.max(0.08, selected.score)));
  const normalizedBpm = normalizeBpm(selected.bpm, minBpm, maxBpm);
  return {
    bpm: normalizedBpm ? Math.round(normalizedBpm * 10) / 10 : null,
    confidence: Math.round(confidence * 1000) / 1000,
    reason: normalizedBpm ? 'candidate' : 'no-candidate',
    score: selected.score,
    analyzedSeconds: usableLength / sampleRate,
  };
}
