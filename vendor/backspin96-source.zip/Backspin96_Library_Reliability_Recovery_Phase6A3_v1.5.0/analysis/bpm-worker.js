import { detectBpmFromMono } from './bpm-core.js';

self.onmessage = (event) => {
  const { requestId, samples, sampleRate, options } = event.data ?? {};
  try {
    const result = detectBpmFromMono(samples, sampleRate, options);
    self.postMessage({ requestId, ok: true, result });
  } catch (error) {
    self.postMessage({ requestId, ok: false, error: error?.message ?? String(error) });
  }
};
