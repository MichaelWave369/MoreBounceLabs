import { BUILD_ID, DEFAULT_REGION_FRAMES, DEFAULT_SLOT_COUNT, percentile } from './protocol.js';
import { TrackProvider, buildDemoTrack } from './track-provider.js';
import { dbToGain, crossfaderGains, faderGain, filterFrequencies, monitorBlendGains, echoDelaySeconds } from './mixer-law.js';
import { effectiveBpm, syncPitchPercent, smartSyncPitchPercent, loopBoundsFromBeats } from '../performance/tempo.js';

export class BackspinDeck extends EventTarget {
  constructor(deckId) {
    super();
    this.deckId = deckId === 'B' ? 'B' : 'A';
    this.context = null;
    this.node = null;
    this.provider = new TrackProvider();
    this.track = null;
    this.generation = 0;
    this.sequence = 0;
    this.playing = false;
    this.regionFrames = DEFAULT_REGION_FRAMES;
    this.utilizationHistory = [];
    this.telemetry = null;
    this.ledger = [];
    this.lastTransportAt = 0;
    this.ready = false;
    this.processorReady = false;
    this.processorError = null;
    this.watchdogTimer = null;
    this.watchdogFaulted = false;
    this.processorReadyResolve = null;
    this.processorReadyReject = null;
    this.pitchPercent = 0;
    this.bpm = null;
    this.bpmSource = 'unknown';
    this.bpmConfidence = 0;
    this.tempoFamilyFactor = 1;
    this.bpmAnalysisWorker = null;
    this.bpmAnalysisRequest = 0;
    this.beatOffsetFrame = 0;
    this.hotCues = [null, null, null, null];
    this.loop = { enabled: false, startFrame: 0, endFrame: 0, beats: 4 };
  }

  attach(context, outputNode) {
    this.disposeNode();
    this.context = context;
    this.processorError = null;
    this.processorReady = false;

    const processorReady = new Promise((resolve, reject) => {
      this.processorReadyResolve = resolve;
      this.processorReadyReject = reject;
    });

    this.node = new AudioWorkletNode(context, 'backspin-processor', {
      numberOfInputs: 0,
      numberOfOutputs: 1,
      outputChannelCount: [2],
      processorOptions: {
        buildId: BUILD_ID,
        deckId: this.deckId,
        regionFrames: this.regionFrames,
        slotCount: DEFAULT_SLOT_COUNT,
      },
    });
    this.node.port.onmessage = (event) => this.#onWorkletMessage(event.data);
    this.node.addEventListener('processorerror', (event) => this.#handleProcessorError(event));
    this.node.connect(outputNode);
    return processorReady;
  }

  markReady() {
    this.ready = true;
    this.#startWatchdog();
  }

  async loadDemoTrack() {
    if (!this.context) throw new Error(`Deck ${this.deckId} has no AudioContext.`);
    const track = buildDemoTrack(this.context.sampleRate, 24, this.deckId);
    this.#installTrack(track, 'generated-demo');
  }

  async loadFile(file) {
    if (!this.ready || !this.context) throw new Error(`Deck ${this.deckId} is not started.`);
    this.pause();
    const bytes = await file.arrayBuffer();
    const decoded = await this.context.decodeAudioData(bytes.slice(0));
    const channels = [];
    for (let c = 0; c < Math.min(2, decoded.numberOfChannels); c += 1) {
      channels.push(decoded.getChannelData(c).slice());
    }
    if (channels.length === 1) channels.push(channels[0].slice());
    const track = {
      id: `file-${this.deckId}-${crypto.randomUUID()}`,
      name: file.name,
      sampleRate: decoded.sampleRate,
      length: decoded.length,
      duration: decoded.duration,
      channels,
      deck: this.deckId,
    };
    this.#installTrack(track, 'local-file');
    this.#analyzeTrackBpm(track);
  }

  #installTrack(track, source) {
    this.track = track;
    this.pitchPercent = 0;
    this.beatOffsetFrame = 0;
    this.hotCues = [null, null, null, null];
    this.loop = { enabled: false, startFrame: 0, endFrame: 0, beats: 4 };
    this.tempoFamilyFactor = 1;
    if (Number.isFinite(track.bpm)) {
      this.bpm = track.bpm;
      this.bpmSource = 'embedded';
      this.bpmConfidence = 1;
    } else {
      this.bpm = null;
      this.bpmSource = 'analyzing';
      this.bpmConfidence = 0;
    }
    this.provider.load(track);
    this.generation += 1;
    this.node?.port.postMessage({
      type: 'load-track',
      deckId: this.deckId,
      trackId: track.id,
      trackLength: track.length,
      generation: this.generation,
      regionFrames: this.regionFrames,
      effectiveFrame: this.#effectiveFrame(),
    });
    this.#record('track-load', {
      deckId: this.deckId,
      source,
      trackId: track.id,
      name: track.name,
      frames: track.length,
      generation: this.generation,
    });
    this.dispatchEvent(new CustomEvent('track', { detail: { ...track, deckId: this.deckId, bpm: this.bpm, bpmSource: this.bpmSource, bpmConfidence: this.bpmConfidence } }));
    this.#dispatchBpm();
  }

  async play(effectiveFrame = null) {
    if (!this.ready || !this.track || this.processorError || !this.context) return;
    if (this.context.state !== 'running') await this.context.resume();
    this.playing = true;
    this.#sendCommand('set-playing', { playing: true }, effectiveFrame);
    this.#record('play', { deckId: this.deckId, generation: this.generation, contextState: this.context.state });
  }

  pause(effectiveFrame = null) {
    if (!this.ready) return;
    this.playing = false;
    this.#sendCommand('set-playing', { playing: false }, effectiveFrame);
    this.#record('pause', { deckId: this.deckId, generation: this.generation });
  }

  async togglePlay() {
    if (this.playing) this.pause();
    else await this.play();
  }

  cueStart() {
    this.seekToFrame(0, 'cue');
  }

  seekNormalized(value, reason = 'seek') {
    if (!this.track) return;
    const frame = Math.floor(Math.max(0, Math.min(1, value)) * Math.max(0, this.track.length - 1));
    this.seekToFrame(frame, reason);
  }

  seekToFrame(frame, reason = 'seek') {
    if (!this.ready || !this.track) return;
    this.generation += 1;
    this.#sendCommand('seek', {
      sourceFrame: Math.max(0, Math.min(this.track.length - 1, Math.floor(frame))),
      generation: this.generation,
      reason,
    });
    this.#record('generation-seek', { deckId: this.deckId, frame, reason, generation: this.generation });
  }

  setPitchPercent(percent) {
    this.pitchPercent = Math.max(-50, Math.min(50, Number(percent) || 0));
    const ratio = 1 + this.pitchPercent / 100;
    this.#sendCommand('set-pitch', { pitchRatio: ratio });
    this.dispatchEvent(new CustomEvent('pitch', { detail: { deckId: this.deckId, percent: this.pitchPercent, ratio, effectiveBpm: this.getEffectiveBpm() } }));
    this.#dispatchBpm();
  }

  setManualBpm(value, source = 'tap') {
    const bpm = Number(value);
    if (!Number.isFinite(bpm) || bpm < 40 || bpm > 260) return false;
    this.bpm = bpm;
    this.bpmSource = source;
    this.bpmConfidence = 1;
    this.tempoFamilyFactor = 1;
    this.#record('bpm-manual', { deckId: this.deckId, bpm, source });
    this.#dispatchBpm();
    return true;
  }

  getBaseBpm() {
    return Number.isFinite(this.bpm) ? this.bpm : null;
  }

  getGridBpm() {
    const base = this.getBaseBpm();
    return base ? base * this.tempoFamilyFactor : null;
  }

  setTempoFamilyFactor(factor = 1) {
    const allowed = [0.5, 1, 2];
    const requested = Number(factor) || 1;
    this.tempoFamilyFactor = allowed.reduce((best, value) => Math.abs(value - requested) < Math.abs(best - requested) ? value : best, 1);
    this.#record('tempo-family', { deckId: this.deckId, factor: this.tempoFamilyFactor });
    this.#dispatchBpm();
  }

  getEffectiveBpm() {
    return effectiveBpm(this.getGridBpm(), 1 + this.pitchPercent / 100);
  }

  setJogRatio(ratio, mode = 'scratch') {
    this.#sendCommand('set-jog', { targetJogRatio: Math.max(-4, Math.min(4, Number(ratio) || 0)), mode });
  }

  releaseJog(mode = 'vinyl') {
    this.#sendCommand('release-jog', { releaseMode: mode });
  }

  setGridHere() {
    const frame = Math.max(0, Math.floor(this.telemetry?.sourceFrame ?? 0));
    this.beatOffsetFrame = frame;
    this.#record('beat-grid-set', { deckId: this.deckId, beatOffsetFrame: frame });
    this.dispatchEvent(new CustomEvent('grid', { detail: { deckId: this.deckId, beatOffsetFrame: frame } }));
    return frame;
  }

  setHotCue(index, frame = this.telemetry?.sourceFrame) {
    const cueIndex = Math.max(0, Math.min(3, Math.floor(Number(index) || 0)));
    if (!this.track || !Number.isFinite(frame)) return null;
    const value = Math.max(0, Math.min(this.track.length - 1, Math.floor(frame)));
    this.hotCues[cueIndex] = value;
    this.#record('hot-cue-set', { deckId: this.deckId, cueIndex, frame: value });
    this.dispatchEvent(new CustomEvent('hotcue', { detail: { deckId: this.deckId, cueIndex, frame: value, cues: [...this.hotCues] } }));
    return value;
  }

  clearHotCue(index) {
    const cueIndex = Math.max(0, Math.min(3, Math.floor(Number(index) || 0)));
    this.hotCues[cueIndex] = null;
    this.#record('hot-cue-clear', { deckId: this.deckId, cueIndex });
    this.dispatchEvent(new CustomEvent('hotcue', { detail: { deckId: this.deckId, cueIndex, frame: null, cues: [...this.hotCues] } }));
  }

  triggerHotCue(index) {
    const cueIndex = Math.max(0, Math.min(3, Math.floor(Number(index) || 0)));
    const frame = this.hotCues[cueIndex];
    if (!Number.isFinite(frame)) return false;
    if (this.loop.enabled) this.clearLoop();
    this.seekToFrame(frame, `hot-cue-${cueIndex + 1}`);
    this.#record('hot-cue-trigger', { deckId: this.deckId, cueIndex, frame });
    return true;
  }

  setLoopBeats(beats) {
    const telemetry = this.telemetry;
    const bpm = this.getGridBpm();
    if (!telemetry || !bpm || !this.track) return null;
    const bounds = loopBoundsFromBeats(telemetry.sourceFrame, telemetry.sampleRate, bpm, beats, this.beatOffsetFrame);
    if (!bounds) return null;
    bounds.endFrame = Math.min(this.track.length, bounds.endFrame);
    if (bounds.endFrame <= bounds.startFrame + 1) return null;
    this.loop = { enabled: true, ...bounds };
    this.#sendCommand('set-loop', this.loop);
    this.#record('loop-set', { deckId: this.deckId, ...this.loop });
    this.dispatchEvent(new CustomEvent('loop', { detail: { deckId: this.deckId, ...this.loop } }));
    return { ...this.loop };
  }

  toggleLoopBeats(beats) {
    const beatCount = Math.max(1, Math.round(Number(beats) || 1));
    if (this.loop.enabled && this.loop.beats === beatCount) {
      this.clearLoop();
      return null;
    }
    return this.setLoopBeats(beatCount);
  }

  clearLoop() {
    this.loop = { ...this.loop, enabled: false };
    this.#sendCommand('clear-loop', {});
    this.#record('loop-clear', { deckId: this.deckId });
    this.dispatchEvent(new CustomEvent('loop', { detail: { deckId: this.deckId, ...this.loop } }));
  }

  setRegionFrames(frames) {
    const next = Number(frames);
    if (![8192, 16384, 32768].includes(next) || next === this.regionFrames) return;
    this.regionFrames = next;
    if (this.track && this.node) {
      this.generation += 1;
      this.node.port.postMessage({
        type: 'set-region-frames',
        deckId: this.deckId,
        regionFrames: next,
        generation: this.generation,
        effectiveFrame: this.#effectiveFrame(),
      });
      this.#record('region-size-change', { deckId: this.deckId, regionFrames: next, generation: this.generation });
    }
  }

  setProviderDelay(ms) {
    this.provider.setDelay(ms);
    this.#record('provider-delay', { deckId: this.deckId, ms: Number(ms) || 0 });
  }

  dropNextRegion() {
    this.provider.dropNextRegion();
    this.#record('fault-arm', { deckId: this.deckId, fault: 'drop-next-region' });
  }

  describe() {
    return {
      deckId: this.deckId,
      ready: this.ready,
      processorReady: this.processorReady,
      processorError: this.processorError,
      generation: this.generation,
      track: this.track ? {
        id: this.track.id,
        name: this.track.name,
        duration: this.track.duration,
        length: this.track.length,
        bpm: this.bpm,
        bpmSource: this.bpmSource,
        bpmConfidence: this.bpmConfidence,
      } : null,
      pitchPercent: this.pitchPercent,
      effectiveBpm: this.getEffectiveBpm(),
      gridBpm: this.getGridBpm(),
      tempoFamilyFactor: this.tempoFamilyFactor,
      beatOffsetFrame: this.beatOffsetFrame,
      hotCues: [...this.hotCues],
      loop: { ...this.loop },
      telemetry: this.telemetry,
      provider: {
        delayMs: this.provider.delayMs,
        requests: this.provider.requests,
        completions: this.provider.completions,
        drops: this.provider.drops,
      },
      utilization: {
        count: this.utilizationHistory.length,
        p50: percentile(this.utilizationHistory, 50),
        p95: percentile(this.utilizationHistory, 95),
        p99: percentile(this.utilizationHistory, 99),
        max: this.utilizationHistory.length ? Math.max(...this.utilizationHistory) : 0,
      },
      ledger: this.ledger,
    };
  }

  disposeNode() {
    clearInterval(this.watchdogTimer);
    this.watchdogTimer = null;
    try { this.node?.disconnect(); } catch {}
    try { this.node?.port?.close(); } catch {}
    try { this.bpmAnalysisWorker?.terminate(); } catch {}
    this.bpmAnalysisWorker = null;
    this.node = null;
    this.ready = false;
    this.playing = false;
  }

  #dispatchBpm() {
    this.dispatchEvent(new CustomEvent('bpm', {
      detail: {
        deckId: this.deckId,
        bpm: this.bpm,
        source: this.bpmSource,
        confidence: this.bpmConfidence,
        pitchPercent: this.pitchPercent,
        effectiveBpm: this.getEffectiveBpm(),
        gridBpm: this.getGridBpm(),
        tempoFamilyFactor: this.tempoFamilyFactor,
      },
    }));
  }

  #analyzeTrackBpm(track) {
    if (!track?.channels?.[0] || !Number.isFinite(track.sampleRate)) return;
    try { this.bpmAnalysisWorker?.terminate(); } catch {}
    const worker = new Worker(`./analysis/bpm-worker.js?build=${encodeURIComponent(BUILD_ID)}`, { type: 'module' });
    this.bpmAnalysisWorker = worker;
    const requestId = ++this.bpmAnalysisRequest;
    const maxFrames = Math.min(track.channels[0].length, Math.floor(track.sampleRate * 90));
    const samples = track.channels[0].slice(0, maxFrames);
    this.#record('bpm-analysis-start', { deckId: this.deckId, trackId: track.id, analyzedFrames: samples.length });
    worker.onmessage = (event) => {
      const message = event.data ?? {};
      if (requestId !== this.bpmAnalysisRequest || this.track?.id !== track.id) return;
      if (this.bpmSource === 'tap' || this.bpmSource === 'manual') {
        this.#record('bpm-analysis-discarded', { deckId: this.deckId, trackId: track.id, reason: 'operator-bpm-precedence', candidate: message.result ?? null });
      } else if (message.ok && Number.isFinite(message.result?.bpm)) {
        this.bpm = message.result.bpm;
        this.bpmSource = 'analyzed';
        this.bpmConfidence = message.result.confidence ?? 0;
        this.#record('bpm-analysis-complete', { deckId: this.deckId, trackId: track.id, ...message.result });
      } else {
        this.bpm = null;
        this.bpmSource = 'unknown';
        this.bpmConfidence = 0;
        this.#record('bpm-analysis-failed', { deckId: this.deckId, trackId: track.id, reason: message.error ?? message.result?.reason ?? 'unknown' });
      }
      this.#dispatchBpm();
      worker.terminate();
      if (this.bpmAnalysisWorker === worker) this.bpmAnalysisWorker = null;
    };
    worker.onerror = (event) => {
      if (requestId !== this.bpmAnalysisRequest) return;
      this.bpm = null;
      this.bpmSource = 'unknown';
      this.bpmConfidence = 0;
      this.#record('bpm-analysis-failed', { deckId: this.deckId, trackId: track.id, reason: event.message ?? 'worker-error' });
      this.#dispatchBpm();
      worker.terminate();
      if (this.bpmAnalysisWorker === worker) this.bpmAnalysisWorker = null;
    };
    worker.postMessage({ requestId, samples, sampleRate: track.sampleRate }, [samples.buffer]);
  }

  #sendCommand(command, payload, effectiveFrame = null) {
    if (!this.node) return;
    this.node.port.postMessage({
      type: 'command',
      deckId: this.deckId,
      command,
      payload,
      sequence: ++this.sequence,
      effectiveFrame: Number.isFinite(effectiveFrame) ? effectiveFrame : this.#effectiveFrame(),
      sentAtMs: performance.now(),
    });
  }

  #effectiveFrame() {
    const estimated = this.context ? Math.floor(this.context.currentTime * this.context.sampleRate) : 0;
    const current = this.telemetry?.currentFrame ?? estimated;
    return current + 256;
  }

  #handleProcessorError(event) {
    const message = event?.message || `Deck ${this.deckId} AudioWorklet stopped after an uncaught error.`;
    this.processorError = message;
    this.ready = false;
    this.playing = false;
    this.processorReadyReject?.(new Error(message));
    this.#record('processor-error', { deckId: this.deckId, message });
    this.dispatchEvent(new CustomEvent('fault', { detail: { deckId: this.deckId, source: 'processor', message } }));
  }

  #startWatchdog() {
    clearInterval(this.watchdogTimer);
    this.watchdogFaulted = false;
    const startedAt = performance.now();
    this.watchdogTimer = setInterval(() => {
      if (!this.ready || !this.context || this.context.state === 'closed') return;
      const reference = this.lastTransportAt || startedAt;
      const ageMs = performance.now() - reference;
      if (ageMs > 1800 && !this.watchdogFaulted) {
        this.watchdogFaulted = true;
        const message = `Deck ${this.deckId}: no AudioWorklet telemetry for ${Math.round(ageMs)} ms.`;
        this.#record('worklet-watchdog', { deckId: this.deckId, ageMs, contextState: this.context.state });
        this.dispatchEvent(new CustomEvent('fault', { detail: { deckId: this.deckId, source: 'watchdog', message } }));
      } else if (ageMs < 900) {
        this.watchdogFaulted = false;
      }
    }, 400);
  }

  async #onWorkletMessage(message) {
    if (!message || typeof message.type !== 'string') return;
    if (message.deckId && message.deckId !== this.deckId) return;
    if (message.type === 'processor-ready') {
      this.processorReady = true;
      this.processorReadyResolve?.(message);
      this.processorReadyResolve = null;
      this.processorReadyReject = null;
      this.#record('processor-ready', {
        deckId: this.deckId,
        buildId: message.buildId,
        sampleRate: message.sampleRate,
        timingSource: message.timingSource,
      });
      this.dispatchEvent(new CustomEvent('processor-ready', { detail: message }));
      return;
    }
    if (message.type === 'processor-fault') {
      const text = message.message || message.fault || `Deck ${this.deckId} AudioWorklet reported a guarded fault.`;
      this.#record('processor-guarded-fault', message);
      this.dispatchEvent(new CustomEvent('fault', { detail: { deckId: this.deckId, source: 'processor-guard', message: text } }));
      return;
    }
    if (message.type === 'region-request') {
      this.dispatchEvent(new CustomEvent('region-request', { detail: message }));
      const requestNode = this.node;
      const result = await this.provider.fulfill(message);
      if (!requestNode || this.node !== requestNode) return;
      if (!result.ok) {
        this.#record('region-not-delivered', {
          deckId: this.deckId,
          reason: result.reason,
          regionId: message.regionId,
          generation: message.generation,
        });
        requestNode.port.postMessage({
          type: 'region-failed',
          deckId: this.deckId,
          trackId: message.trackId,
          generation: message.generation,
          regionId: message.regionId,
          requestSeq: message.requestSeq,
          reason: result.reason,
        });
        return;
      }
      requestNode.port.postMessage(result.message, result.transfer);
      return;
    }
    if (message.type === 'telemetry') {
      this.telemetry = message;
      if (Number.isFinite(message.callbackUtilizationPeak)) {
        this.utilizationHistory.push(message.callbackUtilizationPeak);
        if (this.utilizationHistory.length > 600) this.utilizationHistory.shift();
      }
      this.lastTransportAt = performance.now();
      this.dispatchEvent(new CustomEvent('telemetry', { detail: message }));
      return;
    }
    if (message.type === 'ledger') {
      this.#record(message.event, { deckId: this.deckId, ...(message.detail ?? {}) });
    }
  }

  #record(event, detail = {}) {
    const record = {
      at: new Date().toISOString(),
      monotonicMs: performance.now(),
      event,
      detail: { deckId: this.deckId, ...detail },
    };
    this.ledger.push(record);
    if (this.ledger.length > 400) this.ledger.shift();
    this.dispatchEvent(new CustomEvent('ledger', { detail: record }));
  }
}

export class BackspinMixerSystem extends EventTarget {
  constructor() {
    super();
    this.context = null;
    this.ready = false;
    this.decks = {
      A: new BackspinDeck('A'),
      B: new BackspinDeck('B'),
    };
    this.channels = {};
    this.mixBus = null;
    this.limiter = null;
    this.masterGain = null;
    this.masterAnalyser = null;
    this.boothMasterGain = null;
    this.monitorBus = null;
    this.monitorGain = null;
    this.monitorLevel = 0.72;
    this.monitorMix = 0;
    this.pfl = { A: false, B: false };
    this.echoInput = null;
    this.echoDelay = null;
    this.echoFeedback = null;
    this.echoWet = null;
    this.echoTimeMs = 280;
    this.echoFeedbackValue = 0.38;
    this.recorderDestination = null;
    this.mediaRecorder = null;
    this.recordingChunks = [];
    this.recordingStartedAt = null;
    this.crossfader = 0;
    this.crossfaderCurve = 0;
    this.masterValue = 0.86;
    this.ledger = [];
    this.#wireDeckEvents();
  }

  async start() {
    if (this.ready && this.context && this.context.state !== 'closed') {
      await this.resume();
      return;
    }
    await this.dispose();
    this.context = new AudioContext({ latencyHint: 'interactive' });
    this.context.addEventListener('statechange', () => {
      const state = this.context?.state ?? 'closed';
      this.#record('audio-context-state', { state });
      this.dispatchEvent(new CustomEvent('context-state', { detail: { state } }));
    });
    await this.context.audioWorklet.addModule(`./audio/backspin-processor.js?build=${encodeURIComponent(BUILD_ID)}`);
    this.#buildMixerGraph();

    const handshakes = [
      this.decks.A.attach(this.context, this.channels.A.input),
      this.decks.B.attach(this.context, this.channels.B.input),
    ];

    await this.resume();
    await Promise.race([
      Promise.all(handshakes),
      new Promise((_, reject) => setTimeout(() => reject(new Error('Dual AudioWorklet handshake timed out.')), 2500)),
    ]);

    this.decks.A.markReady();
    this.decks.B.markReady();
    await Promise.all([this.decks.A.loadDemoTrack(), this.decks.B.loadDemoTrack()]);
    this.ready = true;
    this.#record('mixer-start', {
      sampleRate: this.context.sampleRate,
      baseLatency: this.context.baseLatency,
      decks: ['A', 'B'],
    });
    this.dispatchEvent(new CustomEvent('ready', { detail: this.describe() }));
  }

  async resume() {
    if (!this.context) throw new Error('Audio context is not available.');
    if (this.context.state !== 'running') await this.context.resume();
    if (this.context.state !== 'running') throw new Error(`Audio context did not enter running state (state=${this.context.state}).`);
  }

  pauseAll() {
    const effectiveFrame = this.context ? Math.floor(this.context.currentTime * this.context.sampleRate) + 384 : null;
    this.decks.A.pause(effectiveFrame);
    this.decks.B.pause(effectiveFrame);
    this.#record('panic-stop', {});
  }

  async startBoth() {
    await this.resume();
    const effectiveFrame = Math.floor(this.context.currentTime * this.context.sampleRate) + 512;
    await Promise.all([this.decks.A.play(effectiveFrame), this.decks.B.play(effectiveFrame)]);
    this.#record('dual-start', {});
  }

  setCrossfader(position) {
    if (!this.context || !this.channels.A || !this.channels.B) return;
    this.crossfader = Math.max(-1, Math.min(1, Number(position) || 0));
    const gains = crossfaderGains(this.crossfader, this.crossfaderCurve);
    const now = this.context.currentTime;
    this.channels.A.crossfade.gain.setTargetAtTime(gains.a, now, 0.006);
    this.channels.B.crossfade.gain.setTargetAtTime(gains.b, now, 0.006);
    this.dispatchEvent(new CustomEvent('mixer-change', { detail: { control: 'crossfader', value: this.crossfader, gains } }));
  }

  cutTo(deckId) {
    this.setCrossfader(deckId === 'A' ? -1 : deckId === 'B' ? 1 : 0);
  }

  setCrossfaderCurve(value) {
    this.crossfaderCurve = Math.max(0, Math.min(1, Number(value) || 0));
    this.setCrossfader(this.crossfader);
    this.#record('crossfader-curve', { value: this.crossfaderCurve });
  }

  syncDeck(targetDeckId, sourceDeckId, { strategy = 'smart' } = {}) {
    const target = this.decks[targetDeckId];
    const source = this.decks[sourceDeckId];
    if (!target || !source) return { ok: false, reason: 'unknown-deck' };
    const sourceBpm = source.getEffectiveBpm();
    const targetBpm = target.getBaseBpm();
    let result;
    if (strategy === 'blend') {
      result = { ok: false, reason: 'blend-only', percent: target.pitchPercent, unclamped: 0, targetFamilyFactor: 1, targetFamilyBpm: targetBpm };
    } else if (strategy === 'exact') {
      result = syncPitchPercent(sourceBpm, targetBpm, { min: -16, max: 16 });
      if (result.reason !== 'missing-bpm') {
        target.setTempoFamilyFactor(1);
        target.setPitchPercent(result.percent);
      }
    } else {
      result = smartSyncPitchPercent(sourceBpm, targetBpm, { min: -16, max: 16 });
      if (result.ok) {
        target.setTempoFamilyFactor(result.targetFamilyFactor);
        target.setPitchPercent(result.percent);
      }
      else if (result.reason === 'outside-pitch-range') result = { ...result, reason: 'blend-only', percent: target.pitchPercent };
    }
    this.#record('tempo-sync', { targetDeckId, sourceDeckId, strategy, sourceBpm, targetBaseBpm: targetBpm, ...result });
    this.dispatchEvent(new CustomEvent('tempo-sync', { detail: { targetDeckId, sourceDeckId, strategy, sourceBpm, targetBaseBpm: targetBpm, ...result } }));
    return result;
  }

  setTrim(deckId, db) {
    const channel = this.channels[deckId];
    if (!channel || !this.context) return;
    channel.state.trimDb = Number(db) || 0;
    channel.trim.gain.setTargetAtTime(dbToGain(channel.state.trimDb), this.context.currentTime, 0.01);
  }

  setEq(deckId, band, db) {
    const channel = this.channels[deckId];
    const node = channel?.[band];
    if (!node || !this.context) return;
    const value = Math.max(-24, Math.min(12, Number(db) || 0));
    channel.state[`${band}Db`] = value;
    node.gain.setTargetAtTime(value, this.context.currentTime, 0.012);
  }

  setFilter(deckId, value) {
    const channel = this.channels[deckId];
    if (!channel || !this.context) return;
    const normalized = Math.max(-1, Math.min(1, Number(value) || 0));
    const frequencies = filterFrequencies(normalized);
    channel.state.filter = normalized;
    channel.highpass.frequency.setTargetAtTime(frequencies.highpassHz, this.context.currentTime, 0.015);
    channel.lowpass.frequency.setTargetAtTime(frequencies.lowpassHz, this.context.currentTime, 0.015);
  }

  setChannelFader(deckId, value) {
    const channel = this.channels[deckId];
    if (!channel || !this.context) return;
    const normalized = Math.max(0, Math.min(1, Number(value) || 0));
    channel.state.fader = normalized;
    channel.volume.gain.setTargetAtTime(faderGain(normalized), this.context.currentTime, 0.008);
  }

  setEchoSend(deckId, value) {
    const channel = this.channels[deckId];
    if (!channel || !this.context) return;
    const normalized = Math.max(0, Math.min(1, Number(value) || 0));
    channel.state.echoSend = normalized;
    channel.echoSend.gain.setTargetAtTime(normalized * normalized * 0.72, this.context.currentTime, 0.012);
  }

  setEchoTime(valueMs) {
    if (!this.echoDelay || !this.context) return;
    this.echoTimeMs = Math.max(40, Math.min(900, Number(valueMs) || 280));
    this.echoDelay.delayTime.setTargetAtTime(echoDelaySeconds(this.echoTimeMs), this.context.currentTime, 0.02);
  }

  setEchoFeedback(value) {
    if (!this.echoFeedback || !this.context) return;
    this.echoFeedbackValue = Math.max(0, Math.min(0.82, Number(value) || 0));
    this.echoFeedback.gain.setTargetAtTime(this.echoFeedbackValue, this.context.currentTime, 0.02);
  }

  killEcho() {
    this.setEchoSend('A', 0);
    this.setEchoSend('B', 0);
    if (this.echoFeedback && this.context) this.echoFeedback.gain.setTargetAtTime(0, this.context.currentTime, 0.008);
    setTimeout(() => {
      if (this.echoFeedback && this.context) this.echoFeedback.gain.setTargetAtTime(this.echoFeedbackValue, this.context.currentTime, 0.03);
    }, 900);
    this.#record('echo-kill', {});
  }

  setPfl(deckId, enabled) {
    const channel = this.channels[deckId];
    if (!channel || !this.context) return;
    this.pfl[deckId] = Boolean(enabled);
    channel.state.pfl = this.pfl[deckId];
    channel.cueSend.gain.setTargetAtTime(this.pfl[deckId] ? 1 : 0, this.context.currentTime, 0.008);
    this.#record('pfl-change', { deckId, enabled: this.pfl[deckId] });
  }

  setCueLevel(value) {
    this.monitorLevel = Math.max(0, Math.min(1, Number(value) || 0));
    this.#applyMonitorBlend();
  }

  setCueMix(value) {
    this.monitorMix = Math.max(0, Math.min(1, Number(value) || 0));
    this.#applyMonitorBlend();
  }

  startRecording() {
    if (!this.ready || !this.recorderDestination) throw new Error('Audio graph is not ready.');
    if (typeof MediaRecorder === 'undefined') throw new Error('MediaRecorder is unavailable in this browser.');
    if (this.mediaRecorder?.state === 'recording') return false;
    const preferred = ['audio/webm;codecs=opus', 'audio/webm', 'audio/ogg;codecs=opus'];
    const mimeType = preferred.find((type) => MediaRecorder.isTypeSupported?.(type)) || '';
    this.recordingChunks = [];
    this.mediaRecorder = new MediaRecorder(this.recorderDestination.stream, mimeType ? { mimeType } : undefined);
    this.mediaRecorder.addEventListener('dataavailable', (event) => {
      if (event.data?.size) this.recordingChunks.push(event.data);
    });
    this.recordingStartedAt = performance.now();
    this.mediaRecorder.start(1000);
    this.#record('recording-start', { mimeType: this.mediaRecorder.mimeType || mimeType || 'browser-default' });
    this.dispatchEvent(new CustomEvent('recording-state', { detail: { recording: true } }));
    return true;
  }

  stopRecording() {
    if (!this.mediaRecorder || this.mediaRecorder.state !== 'recording') return Promise.resolve(null);
    const recorder = this.mediaRecorder;
    return new Promise((resolve) => {
      recorder.addEventListener('stop', () => {
        const blob = new Blob(this.recordingChunks, { type: recorder.mimeType || 'audio/webm' });
        const durationMs = this.recordingStartedAt ? performance.now() - this.recordingStartedAt : 0;
        this.#record('recording-stop', { bytes: blob.size, durationMs, mimeType: blob.type });
        this.dispatchEvent(new CustomEvent('recording-state', { detail: { recording: false, blob, durationMs } }));
        this.mediaRecorder = null;
        this.recordingChunks = [];
        this.recordingStartedAt = null;
        resolve(blob);
      }, { once: true });
      recorder.stop();
    });
  }

  setMaster(value) {
    if (!this.masterGain || !this.context) return;
    this.masterValue = Math.max(0, Math.min(1.2, Number(value) || 0));
    this.masterGain.gain.setTargetAtTime(faderGain(Math.min(1, this.masterValue)) * (this.masterValue > 1 ? this.masterValue : 1), this.context.currentTime, 0.01);
  }

  getMeters() {
    return {
      A: this.#readAnalyser(this.channels.A?.analyser),
      B: this.#readAnalyser(this.channels.B?.analyser),
      master: this.#readAnalyser(this.masterAnalyser),
    };
  }

  describe() {
    return {
      buildId: BUILD_ID,
      ready: this.ready,
      contextState: this.context?.state ?? 'none',
      sampleRate: this.context?.sampleRate ?? null,
      baseLatency: this.context?.baseLatency ?? null,
      outputLatency: this.context?.outputLatency ?? null,
      mixer: {
        crossfader: this.crossfader,
        crossfaderCurve: this.crossfaderCurve,
        master: this.masterValue,
        monitorLevel: this.monitorLevel,
        monitorMix: this.monitorMix,
        pfl: { ...this.pfl },
        echoTimeMs: this.echoTimeMs,
        echoFeedback: this.echoFeedbackValue,
        recording: this.mediaRecorder?.state === 'recording',
        channelA: this.channels.A?.state ?? null,
        channelB: this.channels.B?.state ?? null,
      },
      decks: {
        A: this.decks.A.describe(),
        B: this.decks.B.describe(),
      },
      ledger: this.ledger,
    };
  }

  exportEvidence(extra = {}) {
    return {
      schema: 'parallax.backspin96.phase5a.evidence.v1',
      exportedAt: new Date().toISOString(),
      userAgent: navigator.userAgent,
      crossOriginIsolated,
      ...this.describe(),
      ...extra,
    };
  }

  async dispose() {
    this.ready = false;
    this.decks.A.disposeNode();
    this.decks.B.disposeNode();
    if (this.context && this.context.state !== 'closed') {
      try { await this.context.close(); } catch {}
    }
    this.context = null;
    this.channels = {};
    this.mixBus = null;
    this.limiter = null;
    this.masterGain = null;
    this.masterAnalyser = null;
    this.boothMasterGain = null;
    this.monitorBus = null;
    this.monitorGain = null;
    this.echoInput = null;
    this.echoDelay = null;
    this.echoFeedback = null;
    this.echoWet = null;
    this.recorderDestination = null;
    this.mediaRecorder = null;
  }

  #buildMixerGraph() {
    const context = this.context;
    this.mixBus = new GainNode(context, { gain: 1 });
    this.limiter = new DynamicsCompressorNode(context, {
      threshold: -1.5,
      knee: 0,
      ratio: 20,
      attack: 0.003,
      release: 0.12,
    });
    this.masterGain = new GainNode(context, { gain: faderGain(this.masterValue) });
    this.masterAnalyser = new AnalyserNode(context, { fftSize: 256, smoothingTimeConstant: 0.65 });
    this.boothMasterGain = new GainNode(context, { gain: 1 });
    this.monitorBus = new GainNode(context, { gain: 1 });
    this.monitorGain = new GainNode(context, { gain: 0 });
    this.recorderDestination = context.createMediaStreamDestination();

    this.echoInput = new GainNode(context, { gain: 1 });
    this.echoDelay = new DelayNode(context, { maxDelayTime: 1.2, delayTime: echoDelaySeconds(this.echoTimeMs) });
    this.echoFeedback = new GainNode(context, { gain: this.echoFeedbackValue });
    this.echoWet = new GainNode(context, { gain: 0.5 });
    this.echoInput.connect(this.echoDelay).connect(this.echoWet).connect(this.mixBus);
    this.echoDelay.connect(this.echoFeedback).connect(this.echoDelay);

    this.mixBus.connect(this.limiter).connect(this.masterGain).connect(this.masterAnalyser);
    this.masterAnalyser.connect(this.boothMasterGain).connect(context.destination);
    this.masterAnalyser.connect(this.recorderDestination);
    this.monitorBus.connect(this.monitorGain).connect(context.destination);

    this.channels.A = this.#makeChannel('A');
    this.channels.B = this.#makeChannel('B');
    this.setCrossfader(0);
    this.#applyMonitorBlend();
  }

  #makeChannel(deckId) {
    const context = this.context;
    const input = new GainNode(context, { gain: 1 });
    const trim = new GainNode(context, { gain: 1 });
    const low = new BiquadFilterNode(context, { type: 'lowshelf', frequency: 220, gain: 0 });
    const mid = new BiquadFilterNode(context, { type: 'peaking', frequency: 1_150, Q: 0.82, gain: 0 });
    const high = new BiquadFilterNode(context, { type: 'highshelf', frequency: 5_200, gain: 0 });
    const highpass = new BiquadFilterNode(context, { type: 'highpass', frequency: 20, Q: 0.85 });
    const lowpass = new BiquadFilterNode(context, { type: 'lowpass', frequency: 20_000, Q: 0.85 });
    const volume = new GainNode(context, { gain: 1 });
    const analyser = new AnalyserNode(context, { fftSize: 256, smoothingTimeConstant: 0.58 });
    const crossfade = new GainNode(context, { gain: Math.SQRT1_2 });
    const cueSend = new GainNode(context, { gain: 0 });
    const echoSend = new GainNode(context, { gain: 0 });
    input.connect(trim).connect(low).connect(mid).connect(high).connect(highpass).connect(lowpass).connect(volume).connect(analyser);
    analyser.connect(crossfade).connect(this.mixBus);
    lowpass.connect(cueSend).connect(this.monitorBus);
    analyser.connect(echoSend).connect(this.echoInput);
    return {
      deckId,
      input,
      trim,
      low,
      mid,
      high,
      highpass,
      lowpass,
      volume,
      analyser,
      crossfade,
      cueSend,
      echoSend,
      state: {
        trimDb: 0,
        lowDb: 0,
        midDb: 0,
        highDb: 0,
        filter: 0,
        fader: 1,
        echoSend: 0,
        pfl: false,
      },
    };
  }

  #applyMonitorBlend() {
    if (!this.context || !this.boothMasterGain || !this.monitorGain) return;
    const gains = monitorBlendGains(this.monitorMix, this.monitorLevel);
    const now = this.context.currentTime;
    this.boothMasterGain.gain.setTargetAtTime(gains.master, now, 0.012);
    this.monitorGain.gain.setTargetAtTime(gains.cue, now, 0.012);
  }

  #readAnalyser(analyser) {
    if (!analyser) return { rms: 0, peak: 0, db: -96 };
    const data = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(data);
    let sum = 0;
    let peak = 0;
    for (const sample of data) {
      sum += sample * sample;
      peak = Math.max(peak, Math.abs(sample));
    }
    const rms = Math.sqrt(sum / Math.max(1, data.length));
    const db = rms > 0 ? 20 * Math.log10(rms) : -96;
    return { rms, peak, db: Math.max(-96, db) };
  }

  #wireDeckEvents() {
    for (const deck of Object.values(this.decks)) {
      deck.addEventListener('fault', (event) => {
        this.ready = false;
        this.dispatchEvent(new CustomEvent('fault', { detail: event.detail }));
      });
      deck.addEventListener('ledger', (event) => {
        const record = event.detail;
        this.ledger.push(record);
        if (this.ledger.length > 800) this.ledger.shift();
        this.dispatchEvent(new CustomEvent('ledger', { detail: record }));
      });
    }
  }

  #record(event, detail = {}) {
    const record = {
      at: new Date().toISOString(),
      monotonicMs: performance.now(),
      event,
      detail,
    };
    this.ledger.push(record);
    if (this.ledger.length > 800) this.ledger.shift();
    this.dispatchEvent(new CustomEvent('ledger', { detail: record }));
  }
}
