import { clamp } from './protocol.js';

export class TrackProvider {
  constructor() {
    this.track = null;
    this.delayMs = 0;
    this.dropNext = false;
    this.requests = 0;
    this.completions = 0;
    this.drops = 0;
  }

  setDelay(ms) {
    this.delayMs = Math.max(0, Number(ms) || 0);
  }

  dropNextRegion() {
    this.dropNext = true;
  }

  load(track) {
    this.track = track;
  }

  unload() {
    this.track = null;
  }

  async fulfill(request) {
    this.requests += 1;
    const track = this.track;
    if (!track || track.id !== request.trackId) {
      return { ok: false, reason: 'track-unavailable', request };
    }

    if (this.dropNext) {
      this.dropNext = false;
      this.drops += 1;
      await wait(this.delayMs);
      return { ok: false, reason: 'injected-drop', request };
    }

    if (this.delayMs) await wait(this.delayMs);

    const start = clamp(Math.floor(request.startFrame), 0, Math.max(0, track.length - 1));
    const requested = Math.max(2, Math.floor(request.frameCount));
    const available = Math.max(1, track.length - start);
    const validFrameCount = Math.min(requested, available);
    const transferFrameCount = Math.min(validFrameCount + 1, available);
    const channels = track.channels.map((channel) => channel.slice(start, start + transferFrameCount));
    this.completions += 1;

    return {
      ok: true,
      message: {
        type: 'region-ready',
        deckId: request.deckId,
        trackId: request.trackId,
        regionId: request.regionId,
        generation: request.generation,
        requestSeq: request.requestSeq,
        startFrame: request.startFrame,
        frameCount: request.frameCount,
        validFrameCount,
        continuityToken: start ^ validFrameCount ^ request.generation,
        channels,
        readyAtMs: performance.now(),
        stillUseful: true,
      },
      transfer: channels.map((channel) => channel.buffer),
    };
  }
}

function wait(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function buildDemoTrack(sampleRate, seconds = 24, variant = 'A') {
  const deck = variant === 'B' ? 'B' : 'A';
  const length = Math.floor(sampleRate * seconds);
  const left = new Float32Array(length);
  const right = new Float32Array(length);
  const bpm = 96;
  const beatFrames = sampleRate * 60 / bpm;
  const barFrames = beatFrames * 4;

  let noiseState = deck === 'A' ? 0x96bacc : 0xb00b96;
  const noise = () => {
    noiseState ^= noiseState << 13;
    noiseState ^= noiseState >>> 17;
    noiseState ^= noiseState << 5;
    return ((noiseState >>> 0) / 0xffffffff) * 2 - 1;
  };

  for (let i = 0; i < length; i += 1) {
    const t = i / sampleRate;
    const beatPhase = (i % beatFrames) / beatFrames;
    const barBeat = Math.floor((i % barFrames) / beatFrames);
    let sample = 0;

    if (deck === 'A') {
      const kickEnv = Math.exp(-beatPhase * 18);
      const kickFreq = 48 + 72 * Math.exp(-beatPhase * 30);
      const kick = Math.sin(2 * Math.PI * kickFreq * t) * kickEnv * (barBeat === 0 || barBeat === 2 ? 0.92 : 0.28);

      const snarePhase = ((i - beatFrames) % (beatFrames * 2) + beatFrames * 2) % (beatFrames * 2) / beatFrames;
      const snareEnv = snarePhase < 0.24 ? Math.exp(-snarePhase * 18) : 0;
      const snare = noise() * snareEnv * 0.38;

      const eighthFrames = beatFrames / 2;
      const hatPhase = (i % eighthFrames) / eighthFrames;
      const hat = noise() * Math.exp(-hatPhase * 32) * 0.1;

      const bassFreq = [48.999, 55.0, 65.406, 55.0][barBeat];
      const bass = Math.sin(2 * Math.PI * bassFreq * t) * 0.16 * (0.65 + 0.35 * Math.sin(Math.PI * beatPhase));

      const stabPhase = (i % (barFrames * 2)) / (barFrames * 2);
      const stabEnv = stabPhase < 0.08 ? Math.exp(-stabPhase * 36) : 0;
      const stab = (Math.sin(2 * Math.PI * 196 * t) + Math.sin(2 * Math.PI * 293.66 * t)) * stabEnv * 0.055;
      sample = Math.tanh((kick + snare + hat + bass + stab) * 1.35) * 0.72;
    } else {
      const halfBeat = beatFrames / 2;
      const kickPhase = (i % (beatFrames * 2)) / beatFrames;
      const kickEnv = kickPhase < 0.45 ? Math.exp(-kickPhase * 15) : 0;
      const kick = Math.sin(2 * Math.PI * (43 + 55 * Math.exp(-kickPhase * 25)) * t) * kickEnv * 0.62;

      const clapOffset = beatFrames;
      const clapPhase = ((i - clapOffset) % (beatFrames * 2) + beatFrames * 2) % (beatFrames * 2) / beatFrames;
      const clapEnv = clapPhase < 0.17 ? Math.exp(-clapPhase * 24) : 0;
      const clap = (noise() * 0.27 + Math.sin(2 * Math.PI * 620 * t) * 0.08) * clapEnv;

      const hatPhase = (i % halfBeat) / halfBeat;
      const openHatPhase = ((i - halfBeat) % beatFrames + beatFrames) % beatFrames / beatFrames;
      const hats = noise() * Math.exp(-hatPhase * 42) * 0.065
        + noise() * (openHatPhase < 0.34 ? Math.exp(-openHatPhase * 7) : 0) * 0.045;

      const root = [36.708, 43.654, 41.203, 32.703][barBeat];
      const sub = Math.sin(2 * Math.PI * root * t) * 0.22 * (0.72 + 0.28 * Math.sin(Math.PI * beatPhase));
      const chordGate = beatPhase < 0.3 ? Math.exp(-beatPhase * 7) : 0;
      const chord = (Math.sin(2 * Math.PI * 146.83 * t)
        + Math.sin(2 * Math.PI * 174.61 * t)
        + Math.sin(2 * Math.PI * 220 * t)) * chordGate * 0.032;
      const dubDelay = Math.sin(2 * Math.PI * 0.25 * t) * Math.sin(2 * Math.PI * 293.66 * t) * 0.018;
      sample = Math.tanh((kick + clap + hats + sub + chord + dubDelay) * 1.45) * 0.68;
    }

    const pan = Math.sin(2 * Math.PI * (deck === 'A' ? 0.11 : 0.071) * t) * 0.08;
    left[i] = sample * (1 - pan);
    right[i] = sample * (1 + pan);
  }

  return {
    id: `demo-${deck}-${sampleRate}-${seconds}`,
    name: deck === 'A' ? `Backspin Lab Break — ${bpm} BPM` : `Warehouse Dub Tool — ${bpm} BPM`,
    sampleRate,
    length,
    duration: length / sampleRate,
    channels: [left, right],
    bpm,
    deck,
  };
}
