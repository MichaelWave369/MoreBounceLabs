class BackspinProcessor extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const config = options.processorOptions ?? {};
    this.buildId = config.buildId ?? 'unknown';
    this.regionFrames = config.regionFrames ?? 16_384;
    this.slotCount = config.slotCount ?? 4;
    this.slots = Array.from({ length: this.slotCount }, (_, regionId) => this.#emptySlot(regionId));
    this.pending = new Map();
    this.requestSeq = 0;
    this.commandQueue = [];
    this.stats = {
      quanta: 0,
      underruns: 0,
      staleRejected: 0,
      duplicateRejected: 0,
      wrongRangeRejected: 0,
      failedRegions: 0,
      urgentRequests: 0,
      commandsApplied: 0,
      commandDrops: 0,
      callbackUtilizationTotal: 0,
      callbackUtilizationPeak: 0,
      meterSquareTotal: 0,
      meterFrameTotal: 0,
      meterPeak: 0,
      lastFault: 'none',
    };
    this.deck = {
      deckId: config.deckId === 'B' ? 'B' : 'A',
      trackId: null,
      trackLength: 0,
      generation: 0,
      sourceFrame: 0,
      playing: false,
      pitchRatio: 1,
      jogRatio: 1,
      targetJogRatio: 1,
      mode: 'normal',
      releaseMode: 'vinyl',
      lastSampleL: 0,
      lastSampleR: 0,
      recoveryGain: 1,
      loopEnabled: false,
      loopStart: 0,
      loopEnd: 0,
      loopBeats: 0,
    };
    this.lastTelemetryQuantum = 0;
    this.guardedFaultCount = 0;
    this.lastGuardedFaultQuantum = -100000;
    this.timingSource = typeof globalThis.performance?.now === 'function' ? 'performance.now' : 'Date.now';
    this.port.onmessage = (event) => this.#onMessage(event.data);
    this.port.postMessage({
      type: 'processor-ready',
      buildId: this.buildId,
      deckId: this.deck.deckId,
      sampleRate,
      currentFrame,
      timingSource: this.timingSource,
    });
  }

  #emptySlot(regionId) {
    return {
      regionId,
      state: 'free',
      trackId: null,
      generation: -1,
      requestSeq: -1,
      startFrame: 0,
      frameCount: 0,
      validFrameCount: 0,
      channels: null,
      continuityToken: 0,
    };
  }

  #onMessage(message) {
    if (!message || typeof message.type !== 'string') return;
    switch (message.type) {
      case 'load-track': {
        if (message.deckId && message.deckId !== this.deck.deckId) return;
        this.deck.trackId = message.trackId;
        this.deck.trackLength = message.trackLength;
        this.deck.generation = message.generation;
        this.deck.sourceFrame = 0;
        this.deck.loopEnabled = false;
        this.deck.loopStart = 0;
        this.deck.loopEnd = 0;
        this.deck.loopBeats = 0;
        this.regionFrames = message.regionFrames ?? this.regionFrames;
        this.#invalidateSlots('track-load');
        this.#ensureCoverage('track-load');
        break;
      }
      case 'set-region-frames': {
        this.regionFrames = message.regionFrames;
        this.deck.generation = message.generation;
        this.#invalidateSlots('region-size-change');
        this.#ensureCoverage('region-size-change');
        break;
      }
      case 'command': {
        if (message.deckId && message.deckId !== this.deck.deckId) return;
        if (this.commandQueue.length >= 256) {
          this.stats.commandDrops += 1;
          this.stats.lastFault = 'command-queue-overflow';
          break;
        }
        this.commandQueue.push(message);
        this.commandQueue.sort((a, b) => a.effectiveFrame - b.effectiveFrame || a.sequence - b.sequence);
        break;
      }
      case 'region-ready':
        if (!message.deckId || message.deckId === this.deck.deckId) this.#acceptRegion(message);
        break;
      case 'region-failed': {
        if (message.deckId && message.deckId !== this.deck.deckId) return;
        const key = this.#pendingKey(message);
        this.pending.delete(key);
        this.stats.failedRegions += 1;
        this.stats.lastFault = message.reason ?? 'region-failed';
        break;
      }
      default:
        break;
    }
  }

  #applyDueCommands() {
    while (this.commandQueue.length && this.commandQueue[0].effectiveFrame <= currentFrame) {
      const message = this.commandQueue.shift();
      const p = message.payload ?? {};
      switch (message.command) {
        case 'set-playing':
          this.deck.playing = Boolean(p.playing);
          break;
        case 'set-pitch':
          this.deck.pitchRatio = this.#clamp(p.pitchRatio ?? 1, 0.5, 1.5);
          break;
        case 'set-jog':
          this.deck.targetJogRatio = this.#clamp(p.targetJogRatio ?? 1, -4, 4);
          this.deck.mode = p.mode ?? 'scratch';
          break;
        case 'release-jog':
          this.deck.releaseMode = p.releaseMode ?? 'vinyl';
          if (this.deck.releaseMode === 'direct') this.deck.jogRatio = 1;
          if (this.deck.releaseMode !== 'hold') this.deck.targetJogRatio = 1;
          this.deck.mode = this.deck.loopEnabled ? 'loop' : 'normal';
          break;
        case 'set-loop':
          if (p.enabled && Number.isFinite(p.startFrame) && Number.isFinite(p.endFrame) && p.endFrame > p.startFrame + 1) {
            this.deck.loopEnabled = true;
            this.deck.loopStart = this.#clamp(p.startFrame, 0, Math.max(0, this.deck.trackLength - 1));
            this.deck.loopEnd = this.#clamp(p.endFrame, this.deck.loopStart + 1, this.deck.trackLength);
            this.deck.loopBeats = Math.max(1, Math.round(p.beats ?? 1));
            this.deck.mode = 'loop';
            this.#ensureCoverage('loop-set');
          }
          break;
        case 'clear-loop':
          this.deck.loopEnabled = false;
          this.deck.loopBeats = 0;
          this.deck.mode = 'normal';
          break;
        case 'seek':
          this.deck.generation = p.generation;
          this.deck.sourceFrame = this.#clamp(p.sourceFrame ?? 0, 0, Math.max(0, this.deck.trackLength - 1));
          this.deck.lastSampleL = 0;
          this.deck.lastSampleR = 0;
          this.#invalidateSlots(p.reason ?? 'seek');
          this.#ensureCoverage(p.reason ?? 'seek');
          break;
        default:
          break;
      }
      this.stats.commandsApplied += 1;
    }
  }

  #invalidateSlots(reason) {
    for (let i = 0; i < this.slots.length; i += 1) this.slots[i] = this.#emptySlot(i);
    this.pending.clear();
    this.port.postMessage({
      type: 'ledger',
      event: 'regions-invalidated',
      detail: { deckId: this.deck.deckId, reason, generation: this.deck.generation },
    });
  }

  #slotForStart(startFrame) {
    return Math.abs(Math.floor(startFrame / this.regionFrames)) % this.slotCount;
  }

  #pendingKey(message) {
    return `${message.deckId ?? this.deck.deckId}:${message.trackId}:${message.generation}:${message.regionId}:${message.requestSeq}`;
  }

  #requestRegion(startFrame, reason = 'playback', urgent = false) {
    if (!this.deck.trackId || this.deck.trackLength <= 0) return;
    const aligned = Math.floor(Math.max(0, startFrame) / this.regionFrames) * this.regionFrames;
    if (aligned >= this.deck.trackLength) return;
    if (this.#findRegion(aligned, this.deck.generation, true)) return;
    for (const pending of this.pending.values()) {
      if (pending.trackId === this.deck.trackId && pending.generation === this.deck.generation && pending.startFrame === aligned) return;
    }

    const regionId = this.#slotForStart(aligned);
    const requestSeq = ++this.requestSeq;
    const request = {
      type: 'region-request',
      deckId: this.deck.deckId,
      trackId: this.deck.trackId,
      regionId,
      generation: this.deck.generation,
      requestSeq,
      startFrame: aligned,
      frameCount: this.regionFrames,
      requestedAtMs: currentTime * 1000,
      deadlineMs: currentTime * 1000 + (urgent ? 18 : 70),
      reason,
      urgent,
    };
    this.pending.set(this.#pendingKey(request), request);
    if (urgent) this.stats.urgentRequests += 1;
    this.port.postMessage(request);
  }

  #ensureCoverage(reason = 'playback') {
    if (!this.deck.trackId) return;
    const currentStart = Math.floor(this.deck.sourceFrame / this.regionFrames) * this.regionFrames;
    this.#requestRegion(currentStart, reason, true);
    if (this.deck.loopEnabled) {
      this.#requestRegion(this.deck.loopStart, 'loop-start', true);
      this.#requestRegion(Math.max(this.deck.loopStart, this.deck.loopEnd - 1), 'loop-end', false);
    }

    const ratio = this.deck.pitchRatio * this.deck.targetJogRatio;
    if (this.deck.mode === 'scratch' || Math.abs(ratio) < 0.2) {
      this.#requestRegion(currentStart - this.regionFrames, 'scratch-reverse', false);
      this.#requestRegion(currentStart + this.regionFrames, 'scratch-forward', false);
    } else if (ratio >= 0) {
      this.#requestRegion(currentStart + this.regionFrames, 'forward-lookahead', false);
      this.#requestRegion(currentStart + this.regionFrames * 2, 'forward-reserve', false);
    } else {
      this.#requestRegion(currentStart - this.regionFrames, 'reverse-lookahead', false);
      this.#requestRegion(currentStart - this.regionFrames * 2, 'reverse-reserve', false);
    }
  }

  #acceptRegion(message) {
    if (message.deckId && message.deckId !== this.deck.deckId) {
      this.stats.staleRejected += 1;
      this.stats.lastFault = 'wrong-deck';
      return;
    }
    if (message.trackId !== this.deck.trackId || message.generation !== this.deck.generation) {
      this.stats.staleRejected += 1;
      this.stats.lastFault = 'stale-generation';
      return;
    }
    const key = this.#pendingKey(message);
    const request = this.pending.get(key);
    if (!request) {
      const duplicate = this.slots.some((slot) => slot.state === 'ready'
        && slot.trackId === message.trackId
        && slot.generation === message.generation
        && slot.startFrame === message.startFrame);
      if (duplicate) this.stats.duplicateRejected += 1;
      else this.stats.staleRejected += 1;
      this.stats.lastFault = duplicate ? 'duplicate-completion' : 'unexpected-completion';
      return;
    }
    if (request.startFrame !== message.startFrame || request.frameCount !== message.frameCount) {
      this.stats.wrongRangeRejected += 1;
      this.stats.lastFault = 'wrong-range';
      this.pending.delete(key);
      return;
    }
    const channels = message.channels;
    if (!channels || !channels.length || !channels[0]?.length) {
      this.stats.failedRegions += 1;
      this.stats.lastFault = 'missing-pcm';
      this.pending.delete(key);
      return;
    }
    this.slots[message.regionId] = {
      regionId: message.regionId,
      state: 'ready',
      trackId: message.trackId,
      generation: message.generation,
      requestSeq: message.requestSeq,
      startFrame: message.startFrame,
      frameCount: message.frameCount,
      validFrameCount: message.validFrameCount,
      channels,
      continuityToken: message.continuityToken,
    };
    this.pending.delete(key);
  }

  #findRegion(sourceFrame, generation = this.deck.generation, exactStart = false) {
    for (const slot of this.slots) {
      if (slot.state !== 'ready' || slot.trackId !== this.deck.trackId || slot.generation !== generation) continue;
      if (exactStart) {
        if (slot.startFrame === sourceFrame) return slot;
      } else if (sourceFrame >= slot.startFrame && sourceFrame < slot.startFrame + slot.validFrameCount) {
        return slot;
      }
    }
    return null;
  }

  #readSample(sourceFrame) {
    const slot = this.#findRegion(sourceFrame);
    if (!slot) return null;
    const local = sourceFrame - slot.startFrame;
    const i0 = Math.floor(local);
    const frac = local - i0;
    const i1 = Math.min(i0 + 1, slot.channels[0].length - 1);
    if (i0 < 0 || i0 >= slot.validFrameCount) return null;
    const l0 = slot.channels[0][i0] ?? 0;
    const l1 = slot.channels[0][i1] ?? l0;
    const rightChannel = slot.channels[1] ?? slot.channels[0];
    const r0 = rightChannel[i0] ?? 0;
    const r1 = rightChannel[i1] ?? r0;
    return [l0 + (l1 - l0) * frac, r0 + (r1 - r0) * frac];
  }

  #renderFrame() {
    if (!this.deck.playing || !this.deck.trackId || this.deck.trackLength <= 0) return [0, 0];
    const smoothing = this.deck.mode === 'scratch' ? 0.12 : 0.025;
    this.deck.jogRatio += (this.deck.targetJogRatio - this.deck.jogRatio) * smoothing;
    const ratio = this.deck.pitchRatio * this.deck.jogRatio;
    const sample = this.#readSample(this.deck.sourceFrame);
    let left;
    let right;

    if (sample) {
      [left, right] = sample;
      this.deck.recoveryGain = Math.min(1, this.deck.recoveryGain + 0.05);
    } else {
      this.stats.underruns += 1;
      this.stats.lastFault = 'underrun';
      this.deck.recoveryGain = Math.max(0, this.deck.recoveryGain - 0.08);
      left = this.deck.lastSampleL * this.deck.recoveryGain;
      right = this.deck.lastSampleR * this.deck.recoveryGain;
      this.#ensureCoverage('urgent-underrun');
    }

    this.deck.lastSampleL = left;
    this.deck.lastSampleR = right;
    this.deck.sourceFrame += ratio;

    if (this.deck.loopEnabled) {
      const length = this.deck.loopEnd - this.deck.loopStart;
      if (length > 1 && ratio >= 0 && this.deck.sourceFrame >= this.deck.loopEnd) {
        this.deck.sourceFrame = this.deck.loopStart + ((this.deck.sourceFrame - this.deck.loopStart) % length);
        this.#ensureCoverage('loop-wrap-forward');
      } else if (length > 1 && ratio < 0 && this.deck.sourceFrame < this.deck.loopStart) {
        const distance = (this.deck.loopStart - this.deck.sourceFrame) % length;
        this.deck.sourceFrame = this.deck.loopEnd - distance;
        if (this.deck.sourceFrame >= this.deck.loopEnd) this.deck.sourceFrame = this.deck.loopStart;
        this.#ensureCoverage('loop-wrap-reverse');
      }
    } else {
      if (this.deck.sourceFrame >= this.deck.trackLength) this.deck.sourceFrame = 0;
      if (this.deck.sourceFrame < 0) this.deck.sourceFrame = Math.max(0, this.deck.trackLength - 1);
    }

    return [left, right];
  }

  process(_inputs, outputs) {
    try {
      return this.#processQuantum(outputs);
    } catch (error) {
      this.guardedFaultCount += 1;
      this.stats.lastFault = `guarded:${error?.name ?? 'Error'}`;
      for (const output of outputs) {
        for (const channel of output) channel.fill(0);
      }
      if (this.stats.quanta - this.lastGuardedFaultQuantum >= 128) {
        this.lastGuardedFaultQuantum = this.stats.quanta;
        this.port.postMessage({
          type: 'processor-fault',
          deckId: this.deck.deckId,
          guarded: true,
          fault: this.stats.lastFault,
          message: error?.message ?? String(error),
          quanta: this.stats.quanta,
          guardedFaultCount: this.guardedFaultCount,
        });
      }
      this.stats.quanta += 1;
      return true;
    }
  }

  #processQuantum(outputs) {
    const startedAt = this.#clockMs();
    this.#applyDueCommands();
    const output = outputs[0];
    const left = output[0];
    const right = output[1] ?? output[0];

    let quantumSquare = 0;
    let quantumPeak = 0;
    for (let i = 0; i < left.length; i += 1) {
      const sample = this.#renderFrame();
      left[i] = sample[0];
      right[i] = sample[1];
      const monoEnergy = (sample[0] * sample[0] + sample[1] * sample[1]) * 0.5;
      quantumSquare += monoEnergy;
      quantumPeak = Math.max(quantumPeak, Math.abs(sample[0]), Math.abs(sample[1]));
    }
    this.stats.meterSquareTotal += quantumSquare;
    this.stats.meterFrameTotal += left.length;
    this.stats.meterPeak = Math.max(this.stats.meterPeak, quantumPeak);

    this.stats.quanta += 1;
    if ((this.stats.quanta & 7) === 0) this.#ensureCoverage(this.deck.mode);

    const finishedAt = this.#clockMs();
    const elapsedMs = Math.max(0, finishedAt - startedAt);
    const budgetMs = (left.length / sampleRate) * 1000;
    const utilization = budgetMs > 0 ? elapsedMs / budgetMs : 0;
    this.stats.callbackUtilizationTotal += utilization;
    this.stats.callbackUtilizationPeak = Math.max(this.stats.callbackUtilizationPeak, utilization);

    if (this.stats.quanta - this.lastTelemetryQuantum >= 48) {
      const ready = this.slots.filter((slot) => slot.state === 'ready').length;
      const rms = this.stats.meterFrameTotal > 0
        ? Math.sqrt(this.stats.meterSquareTotal / this.stats.meterFrameTotal)
        : 0;
      this.port.postMessage({
        type: 'telemetry',
        buildId: this.buildId,
        atMs: currentTime * 1000,
        currentFrame,
        sampleRate,
        quantumFrames: left.length,
        deckId: this.deck.deckId,
        trackId: this.deck.trackId,
        generation: this.deck.generation,
        playing: this.deck.playing,
        sourceFrame: this.deck.sourceFrame,
        trackLength: this.deck.trackLength,
        pitchRatio: this.deck.pitchRatio,
        jogRatio: this.deck.jogRatio,
        targetJogRatio: this.deck.targetJogRatio,
        mode: this.deck.mode,
        loopEnabled: this.deck.loopEnabled,
        loopStart: this.deck.loopStart,
        loopEnd: this.deck.loopEnd,
        loopBeats: this.deck.loopBeats,
        regionFrames: this.regionFrames,
        regionReady: ready,
        regionPending: this.pending.size,
        quanta: this.stats.quanta,
        underruns: this.stats.underruns,
        staleRejected: this.stats.staleRejected,
        duplicateRejected: this.stats.duplicateRejected,
        wrongRangeRejected: this.stats.wrongRangeRejected,
        failedRegions: this.stats.failedRegions,
        urgentRequests: this.stats.urgentRequests,
        commandsApplied: this.stats.commandsApplied,
        commandDrops: this.stats.commandDrops,
        callbackUtilizationAverage: this.stats.callbackUtilizationTotal / this.stats.quanta,
        callbackUtilizationPeak: this.stats.callbackUtilizationPeak,
        outputRms: rms,
        outputPeak: this.stats.meterPeak,
        timingSource: this.timingSource,
        guardedFaultCount: this.guardedFaultCount,
        lastFault: this.stats.lastFault,
      });
      this.stats.callbackUtilizationPeak = 0;
      this.stats.meterSquareTotal = 0;
      this.stats.meterFrameTotal = 0;
      this.stats.meterPeak = 0;
      this.lastTelemetryQuantum = this.stats.quanta;
    }

    return true;
  }

  #clockMs() {
    if (typeof globalThis.performance?.now === 'function') return globalThis.performance.now();
    return Date.now();
  }

  #clamp(value, min, max) {
    return Math.min(max, Math.max(min, Number.isFinite(value) ? value : min));
  }
}

registerProcessor('backspin-processor', BackspinProcessor);
