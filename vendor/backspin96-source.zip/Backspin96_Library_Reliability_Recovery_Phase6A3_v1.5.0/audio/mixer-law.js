import { clamp } from './protocol.js';

export function equalPowerGains(position) {
  const x = clamp(Number(position) || 0, -1, 1);
  const angle = (x + 1) * Math.PI / 4;
  return {
    a: Math.cos(angle),
    b: Math.sin(angle),
  };
}

export function crossfaderGains(position, curve = 0) {
  const base = equalPowerGains(position);
  const sharpness = clamp(Number(curve) || 0, 0, 1);
  const exponent = 1 + sharpness * 7;
  return {
    a: base.a ** exponent,
    b: base.b ** exponent,
  };
}

export function dbToGain(db) {
  return 10 ** (clamp(Number(db) || 0, -96, 24) / 20);
}

export function faderGain(value) {
  const normalized = clamp(Number(value) || 0, 0, 1);
  return normalized * normalized;
}

export function filterFrequencies(value) {
  const x = clamp(Number(value) || 0, -1, 1);
  const exp = (min, max, t) => min * ((max / min) ** clamp(t, 0, 1));
  return {
    highpassHz: x > 0 ? exp(20, 5_000, x) : 20,
    lowpassHz: x < 0 ? exp(20_000, 120, -x) : 20_000,
  };
}

export function monitorBlendGains(value, cueLevel = 0.7) {
  const x = clamp(Number(value) || 0, 0, 1);
  const level = clamp(Number(cueLevel) || 0, 0, 1);
  return {
    master: Math.cos(x * Math.PI / 2),
    cue: Math.sin(x * Math.PI / 2) * level,
  };
}

export function echoDelaySeconds(valueMs) {
  return clamp(Number(valueMs) || 0, 40, 900) / 1000;
}
