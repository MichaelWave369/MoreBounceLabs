export const BUILD_ID = 'PB96-5B-v0.6.0';
export const DEFAULT_REGION_FRAMES = 16_384;
export const DEFAULT_SLOT_COUNT = 4;
export const DECK_IDS = Object.freeze(['A', 'B']);

export function makeRegionKey(message) {
  return [message.deckId, message.trackId, message.generation, message.startFrame, message.frameCount].join(':');
}

export function isFiniteNumber(value) {
  return typeof value === 'number' && Number.isFinite(value);
}

export function clamp(value, min, max) {
  return Math.min(max, Math.max(min, value));
}

export function percentile(values, p) {
  if (!values.length) return 0;
  const copy = [...values].sort((a, b) => a - b);
  const index = Math.min(copy.length - 1, Math.max(0, Math.ceil((p / 100) * copy.length) - 1));
  return copy[index];
}
