import { makeRegionKey } from './protocol.js';

/**
 * RegionCompletionGate mirrors the invariant used by the AudioWorklet.
 * It is deliberately pure enough to test under Node without browser APIs.
 */
export class RegionCompletionGate {
  constructor() {
    this.expected = new Map();
    this.acceptedKeys = new Set();
  }

  expect(request) {
    this.expected.set(request.regionId, { ...request, key: makeRegionKey(request) });
  }

  invalidateGeneration(trackId, generation) {
    for (const [regionId, request] of this.expected.entries()) {
      if (request.trackId === trackId && request.generation !== generation) {
        this.expected.delete(regionId);
      }
    }
  }

  evaluate(result, nowMs = performance.now()) {
    const expected = this.expected.get(result.regionId);
    if (!expected) return { accepted: false, reason: 'unexpected-region' };
    if (expected.deckId !== result.deckId) return { accepted: false, reason: 'wrong-deck' };
    if (expected.trackId !== result.trackId) return { accepted: false, reason: 'wrong-track' };
    if (expected.generation !== result.generation) return { accepted: false, reason: 'stale-generation' };
    if (expected.requestSeq !== result.requestSeq) return { accepted: false, reason: 'obsolete-request' };
    if (result.startFrame !== expected.startFrame || result.frameCount !== expected.frameCount) {
      return { accepted: false, reason: 'wrong-range' };
    }
    const key = makeRegionKey(result) + ':' + result.requestSeq;
    if (this.acceptedKeys.has(key)) return { accepted: false, reason: 'duplicate-completion' };
    if (nowMs > expected.deadlineMs && !result.stillUseful) return { accepted: false, reason: 'late' };
    if (!result.channels || !result.channels.length) return { accepted: false, reason: 'missing-pcm' };
    this.acceptedKeys.add(key);
    this.expected.delete(result.regionId);
    return { accepted: true, reason: 'ready' };
  }
}
