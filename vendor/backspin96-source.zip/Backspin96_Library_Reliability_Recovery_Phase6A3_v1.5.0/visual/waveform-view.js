export function buildPeakModel(channel, sampleRate, blockFrames = 128, overviewBins = 1200) {
  if (!(channel instanceof Float32Array) || !channel.length) {
    return {
      length: 0,
      sampleRate,
      blockFrames,
      min: new Float32Array(0),
      max: new Float32Array(0),
      overviewMin: new Float32Array(0),
      overviewMax: new Float32Array(0),
    };
  }

  const blockCount = Math.ceil(channel.length / blockFrames);
  const min = new Float32Array(blockCount);
  const max = new Float32Array(blockCount);
  for (let block = 0; block < blockCount; block += 1) {
    const start = block * blockFrames;
    const end = Math.min(channel.length, start + blockFrames);
    let lo = 1;
    let hi = -1;
    for (let frame = start; frame < end; frame += 1) {
      const value = Number.isFinite(channel[frame]) ? channel[frame] : 0;
      if (value < lo) lo = value;
      if (value > hi) hi = value;
    }
    min[block] = lo === 1 ? 0 : lo;
    max[block] = hi === -1 ? 0 : hi;
  }

  const bins = Math.max(64, Math.min(4096, overviewBins));
  const overviewMin = new Float32Array(bins);
  const overviewMax = new Float32Array(bins);
  for (let x = 0; x < bins; x += 1) {
    const firstBlock = Math.floor(x / bins * blockCount);
    const lastBlock = Math.max(firstBlock + 1, Math.ceil((x + 1) / bins * blockCount));
    let lo = 1;
    let hi = -1;
    for (let block = firstBlock; block < Math.min(lastBlock, blockCount); block += 1) {
      if (min[block] < lo) lo = min[block];
      if (max[block] > hi) hi = max[block];
    }
    overviewMin[x] = lo === 1 ? 0 : lo;
    overviewMax[x] = hi === -1 ? 0 : hi;
  }

  return { length: channel.length, sampleRate, blockFrames, min, max, overviewMin, overviewMax };
}

export function predictSourceFrame(transport, receivedAtMs, nowMs) {
  if (!transport || !(transport.trackLength > 0)) return 0;
  let frame = Number.isFinite(transport.sourceFrame) ? transport.sourceFrame : 0;
  if (transport.playing) {
    const elapsedSeconds = Math.max(0, Math.min(0.25, (nowMs - receivedAtMs) / 1000));
    const ratio = (Number.isFinite(transport.pitchRatio) ? transport.pitchRatio : 1)
      * (Number.isFinite(transport.jogRatio) ? transport.jogRatio : 1);
    frame += elapsedSeconds * transport.sampleRate * ratio;
  }
  const length = transport.trackLength;
  return ((frame % length) + length) % length;
}

export class MovingWaveform {
  constructor(canvas, options = {}) {
    this.deckId = options.deckId === 'B' ? 'B' : 'A';
    this.canvas = canvas;
    this.ctx = canvas.getContext('2d', { alpha: false });
    this.model = null;
    this.track = null;
    this.transport = null;
    this.transportReceivedAt = 0;
    this.lastRenderAt = -Infinity;
    this.lastFrame = -1;
    this.cssWidth = 0;
    this.cssHeight = 0;
    this.windowSeconds = 12;
    this.targetWindowSeconds = 12;
    this.needsPaint = true;
    this.resizeObserver = typeof ResizeObserver === 'function'
      ? new ResizeObserver(() => { this.needsPaint = true; })
      : null;
    this.resizeObserver?.observe(canvas);
    this.#resize();
    this.#paintEmpty();
  }

  installTrack(track) {
    this.track = track;
    this.model = buildPeakModel(track.channels[0], track.sampleRate, 128, 1200);
    this.lastFrame = -1;
    this.needsPaint = true;
    this.render(performance.now(), true);
  }

  setTransport(transport, receivedAtMs = performance.now()) {
    this.transport = transport;
    this.transportReceivedAt = receivedAtMs;
    this.targetWindowSeconds = transport?.mode === 'scratch' ? 4
      : transport?.jogRatio < -0.05 ? 8
        : 12;
    this.needsPaint = true;
  }

  render(now = performance.now(), force = false) {
    if (!this.model || !this.track) {
      if (force || this.needsPaint) this.#paintEmpty();
      return;
    }
    if (!force && now - this.lastRenderAt < 1000 / 30) return;
    this.lastRenderAt = now;
    this.#resize();

    this.windowSeconds += (this.targetWindowSeconds - this.windowSeconds) * 0.12;
    const frame = this.transport
      ? predictSourceFrame(this.transport, this.transportReceivedAt, now)
      : 0;
    if (!force && !this.needsPaint && Math.abs(frame - this.lastFrame) < 0.25 && Math.abs(this.windowSeconds - this.targetWindowSeconds) < 0.01) return;
    this.lastFrame = frame;
    this.needsPaint = false;
    this.#paint(frame);
  }

  #resize() {
    const rect = this.canvas.getBoundingClientRect();
    const cssWidth = Math.max(1, Math.round(rect.width || 1200));
    const cssHeight = Math.max(1, Math.round(rect.height || 150));
    const dpr = Math.min(2, globalThis.devicePixelRatio || 1);
    const pixelWidth = Math.max(1, Math.round(cssWidth * dpr));
    const pixelHeight = Math.max(1, Math.round(cssHeight * dpr));
    if (this.canvas.width !== pixelWidth || this.canvas.height !== pixelHeight) {
      this.canvas.width = pixelWidth;
      this.canvas.height = pixelHeight;
      this.needsPaint = true;
    }
    this.cssWidth = cssWidth;
    this.cssHeight = cssHeight;
    this.ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  #paintEmpty() {
    this.#resize();
    const { ctx } = this;
    const width = this.cssWidth;
    const height = this.cssHeight;
    ctx.fillStyle = '#05050a';
    ctx.fillRect(0, 0, width, height);
    ctx.strokeStyle = 'rgba(85,231,255,.13)';
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(0, height / 2);
    ctx.lineTo(width, height / 2);
    ctx.stroke();
    ctx.fillStyle = 'rgba(255,255,255,.32)';
    ctx.font = '600 11px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.textAlign = 'center';
    ctx.fillText(`DECK ${this.deckId} • LOAD A TRACK`, width / 2, height / 2 - 9);
  }

  #paint(sourceFrame) {
    const { ctx, model } = this;
    const width = this.cssWidth;
    const height = this.cssHeight;
    const overviewHeight = Math.max(18, Math.min(26, Math.round(height * 0.17)));
    const mainHeight = height - overviewHeight - 1;
    const centerY = mainHeight / 2;
    const framesVisible = Math.max(model.sampleRate, this.windowSeconds * model.sampleRate);
    const startFrame = sourceFrame - framesVisible / 2;
    const framesPerPixel = framesVisible / Math.max(1, width);

    const background = ctx.createLinearGradient(0, 0, 0, mainHeight);
    background.addColorStop(0, '#090713');
    background.addColorStop(0.5, '#04040a');
    background.addColorStop(1, '#0b0711');
    ctx.fillStyle = background;
    ctx.fillRect(0, 0, width, mainHeight);

    this.#drawTimeGrid(startFrame, framesVisible, mainHeight);

    const waveGradient = ctx.createLinearGradient(0, 0, width, 0);
    if (this.deckId === 'A') {
      waveGradient.addColorStop(0, '#55e7ff');
      waveGradient.addColorStop(0.52, '#9896ff');
      waveGradient.addColorStop(1, '#c569ff');
      ctx.shadowColor = 'rgba(85,231,255,.32)';
    } else {
      waveGradient.addColorStop(0, '#ffbf5b');
      waveGradient.addColorStop(0.48, '#ff7b64');
      waveGradient.addColorStop(1, '#ff5bbd');
      ctx.shadowColor = 'rgba(255,123,100,.32)';
    }
    ctx.fillStyle = waveGradient;
    ctx.shadowBlur = 5;

    for (let x = 0; x < width; x += 1) {
      const from = startFrame + x * framesPerPixel;
      const to = from + framesPerPixel;
      const peak = this.#aggregateWrapped(from, to);
      const yTop = centerY - peak.max * (mainHeight * 0.44);
      const yBottom = centerY - peak.min * (mainHeight * 0.44);
      ctx.fillRect(x, yTop, 1.2, Math.max(1, yBottom - yTop));
    }
    ctx.shadowBlur = 0;

    ctx.strokeStyle = 'rgba(255,255,255,.10)';
    ctx.beginPath();
    ctx.moveTo(0, centerY + 0.5);
    ctx.lineTo(width, centerY + 0.5);
    ctx.stroke();

    this.#drawOverview(sourceFrame, mainHeight + 1, overviewHeight);
    this.#drawLabels(sourceFrame, mainHeight);
  }

  #drawTimeGrid(startFrame, framesVisible, mainHeight) {
    const { ctx, model } = this;
    const width = this.cssWidth;
    const startSeconds = startFrame / model.sampleRate;
    const endSeconds = (startFrame + framesVisible) / model.sampleRate;
    const minorStep = this.windowSeconds <= 5 ? 0.25 : 0.5;
    const first = Math.ceil(startSeconds / minorStep) * minorStep;
    for (let second = first; second <= endSeconds; second += minorStep) {
      const x = (second - startSeconds) / (endSeconds - startSeconds) * width;
      const whole = Math.abs(second - Math.round(second)) < 1e-6;
      ctx.strokeStyle = whole ? 'rgba(255,255,255,.115)' : 'rgba(255,255,255,.045)';
      ctx.lineWidth = whole ? 1 : 0.5;
      ctx.beginPath();
      ctx.moveTo(Math.round(x) + 0.5, 0);
      ctx.lineTo(Math.round(x) + 0.5, mainHeight);
      ctx.stroke();
    }
  }

  #aggregateWrapped(fromFrame, toFrame) {
    const { model } = this;
    if (!model.length) return { min: 0, max: 0 };
    const span = Math.max(1, toFrame - fromFrame);
    const samplePoints = Math.max(1, Math.min(12, Math.ceil(span / model.blockFrames) + 1));
    let lo = 1;
    let hi = -1;
    for (let i = 0; i < samplePoints; i += 1) {
      const frame = fromFrame + (i / Math.max(1, samplePoints - 1)) * span;
      const wrapped = ((frame % model.length) + model.length) % model.length;
      const block = Math.min(model.min.length - 1, Math.floor(wrapped / model.blockFrames));
      if (model.min[block] < lo) lo = model.min[block];
      if (model.max[block] > hi) hi = model.max[block];
    }
    return { min: lo === 1 ? 0 : lo, max: hi === -1 ? 0 : hi };
  }

  #drawOverview(sourceFrame, top, height) {
    const { ctx, model } = this;
    const width = this.cssWidth;
    ctx.fillStyle = '#030307';
    ctx.fillRect(0, top, width, height);
    const mid = top + height / 2;
    ctx.fillStyle = this.deckId === 'A' ? 'rgba(85,231,255,.38)' : 'rgba(255,123,100,.38)';
    for (let x = 0; x < width; x += 1) {
      const bin = Math.min(model.overviewMin.length - 1, Math.floor(x / width * model.overviewMin.length));
      const yTop = mid - model.overviewMax[bin] * height * 0.42;
      const yBottom = mid - model.overviewMin[bin] * height * 0.42;
      ctx.fillRect(x, yTop, 1, Math.max(1, yBottom - yTop));
    }

    const progress = model.length ? sourceFrame / model.length : 0;
    const x = progress * width;
    ctx.fillStyle = this.deckId === 'A' ? 'rgba(197,105,255,.18)' : 'rgba(255,91,189,.18)';
    ctx.fillRect(0, top, x, height);
    ctx.fillStyle = this.deckId === 'A' ? '#c569ff' : '#ff5bbd';
    ctx.fillRect(Math.max(0, Math.min(width - 2, x - 1)), top, 2, height);

    const viewportFraction = Math.min(1, this.windowSeconds * model.sampleRate / model.length);
    const viewportWidth = Math.max(3, viewportFraction * width);
    ctx.strokeStyle = 'rgba(255,255,255,.55)';
    ctx.strokeRect(Math.max(0.5, Math.min(width - viewportWidth - 0.5, x - viewportWidth / 2)), top + 1.5, viewportWidth, height - 3);
  }

  #drawLabels(sourceFrame, mainHeight) {
    const { ctx, model } = this;
    const width = this.cssWidth;
    const seconds = sourceFrame / model.sampleRate;
    const minutes = Math.floor(seconds / 60);
    const remainder = seconds - minutes * 60;
    const mode = this.transport?.mode?.toUpperCase?.() ?? 'READY';
    const direction = (this.transport?.jogRatio ?? 1) < -0.02 ? 'REV' : 'FWD';
    ctx.font = '700 10px ui-monospace, SFMono-Regular, Menlo, monospace';
    ctx.textBaseline = 'top';
    ctx.fillStyle = 'rgba(255,255,255,.55)';
    ctx.textAlign = 'left';
    ctx.fillText(`-${(this.windowSeconds / 2).toFixed(1)}s`, 8, 7);
    ctx.textAlign = 'right';
    ctx.fillText(`+${(this.windowSeconds / 2).toFixed(1)}s`, width - 8, 7);
    ctx.textAlign = 'center';
    ctx.fillStyle = 'rgba(255,255,255,.82)';
    ctx.fillText(`${minutes}:${remainder.toFixed(2).padStart(5, '0')}  •  ${mode}  •  ${direction}`, width / 2, 7);

  }
}
