/**
 * Self-contained hostile WebGL2 scene.
 * It intentionally stresses the visual/main-thread lane without adding a runtime dependency.
 */
export class StressScene extends EventTarget {
  constructor(host) {
    super();
    this.host = host;
    this.canvas = null;
    this.gl = null;
    this.program = null;
    this.running = false;
    this.level = 35;
    this.cpuBurn = false;
    this.frameTimes = [];
    this.lastFrameAt = 0;
    this.fps = 0;
    this.animationId = 0;
    this.startedAt = performance.now();
    this.resizeObserver = new ResizeObserver(() => this.resize());
    this.init();
  }

  init() {
    this.dispose();
    this.canvas = document.createElement('canvas');
    this.canvas.setAttribute('aria-hidden', 'true');
    this.host.replaceChildren(this.canvas);
    this.gl = this.canvas.getContext('webgl2', {
      antialias: false,
      alpha: false,
      powerPreference: 'high-performance',
      preserveDrawingBuffer: false,
    });
    if (!this.gl) {
      this.host.textContent = 'WebGL2 unavailable. Visual pressure lane disabled.';
      this.dispatchEvent(new CustomEvent('state', { detail: { running: false, unavailable: true } }));
      return;
    }

    const vertexSource = `#version 300 es
      precision highp float;
      uniform float uTime;
      uniform float uLevel;
      uniform vec2 uResolution;
      out float vGlow;
      out vec3 vColor;

      float hash(float n) { return fract(sin(n * 91.3458) * 47453.5453); }

      void main() {
        float id = float(gl_VertexID);
        float speed = 5.0 + uLevel * 12.0;
        float z = -mod(id * 0.0137 + uTime * speed, 92.0) - 1.5;
        float angle = id * 2.399963 + uTime * (0.08 + mod(id, 23.0) * 0.0007);
        float ring = 2.0 + mod(id, 317.0) * 0.020 + sin(id * 0.017 + uTime) * 0.55;
        float wobble = sin(id * 0.007 + uTime * 0.7) * 1.8;
        vec2 xy = vec2(cos(angle), sin(angle)) * (ring + wobble);
        xy.y += sin(angle * 0.37 + uTime) * 2.2;

        float aspect = max(0.1, uResolution.x / uResolution.y);
        float perspective = 1.7 / max(1.0, -z);
        gl_Position = vec4(xy.x * perspective / aspect, xy.y * perspective, 0.0, 1.0);
        gl_PointSize = clamp((38.0 + uLevel * 24.0) / max(1.0, -z), 1.0, 10.0);

        float hue = fract(id * 0.000137 + uTime * 0.018);
        vColor = 0.55 + 0.45 * cos(6.28318 * (hue + vec3(0.0, 0.33, 0.67)));
        vColor = mix(vColor, vec3(0.45, 0.1, 0.95), 0.28);
        vGlow = clamp(1.0 - (-z / 94.0), 0.08, 1.0);
      }
    `;

    const fragmentSource = `#version 300 es
      precision highp float;
      in float vGlow;
      in vec3 vColor;
      out vec4 outColor;
      void main() {
        vec2 p = gl_PointCoord * 2.0 - 1.0;
        float radius = dot(p, p);
        if (radius > 1.0) discard;
        float alpha = smoothstep(1.0, 0.0, radius) * (0.18 + vGlow * 0.78);
        outColor = vec4(vColor * (0.35 + vGlow * 1.4), alpha);
      }
    `;

    const gl = this.gl;
    const vertex = compile(gl, gl.VERTEX_SHADER, vertexSource);
    const fragment = compile(gl, gl.FRAGMENT_SHADER, fragmentSource);
    this.program = gl.createProgram();
    gl.attachShader(this.program, vertex);
    gl.attachShader(this.program, fragment);
    gl.linkProgram(this.program);
    if (!gl.getProgramParameter(this.program, gl.LINK_STATUS)) {
      throw new Error(`WebGL program link failed: ${gl.getProgramInfoLog(this.program)}`);
    }
    gl.deleteShader(vertex);
    gl.deleteShader(fragment);
    this.uniforms = {
      time: gl.getUniformLocation(this.program, 'uTime'),
      level: gl.getUniformLocation(this.program, 'uLevel'),
      resolution: gl.getUniformLocation(this.program, 'uResolution'),
    };
    gl.disable(gl.DEPTH_TEST);
    gl.enable(gl.BLEND);
    gl.blendFunc(gl.SRC_ALPHA, gl.ONE);
    gl.clearColor(0.006, 0.003, 0.018, 1);

    this.resizeObserver.observe(this.host);
    this.running = true;
    this.startedAt = performance.now();
    this.resize();
    this.animate();
  }

  setLevel(level) {
    this.level = Math.max(0, Math.min(100, Number(level) || 0));
  }

  setCpuBurn(enabled) {
    this.cpuBurn = Boolean(enabled);
  }

  resize() {
    if (!this.gl || !this.canvas) return;
    const dpr = Math.min(devicePixelRatio || 1, 1.75);
    const width = Math.max(1, Math.floor(this.host.clientWidth * dpr));
    const height = Math.max(1, Math.floor(this.host.clientHeight * dpr));
    if (this.canvas.width !== width || this.canvas.height !== height) {
      this.canvas.width = width;
      this.canvas.height = height;
      this.gl.viewport(0, 0, width, height);
    }
  }

  kill() {
    this.running = false;
    cancelAnimationFrame(this.animationId);
    this.dispatchEvent(new CustomEvent('state', { detail: { running: false } }));
  }

  recover() {
    if (this.running) return;
    if (!this.gl || this.gl.isContextLost()) this.init();
    else {
      this.running = true;
      this.lastFrameAt = performance.now();
      this.animate();
    }
    this.dispatchEvent(new CustomEvent('state', { detail: { running: true } }));
  }

  animate = () => {
    if (!this.running || !this.gl) return;
    this.animationId = requestAnimationFrame(this.animate);
    const now = performance.now();
    const delta = this.lastFrameAt ? now - this.lastFrameAt : 16.7;
    this.lastFrameAt = now;
    this.frameTimes.push(delta);
    if (this.frameTimes.length > 120) this.frameTimes.shift();
    const averageMs = this.frameTimes.reduce((sum, value) => sum + value, 0) / this.frameTimes.length;
    this.fps = averageMs > 0 ? 1000 / averageMs : 0;

    const gl = this.gl;
    const elapsed = (now - this.startedAt) / 1000;
    const normalized = this.level / 100;
    const particles = Math.max(3_000, Math.floor(3_000 + Math.pow(normalized, 1.8) * 747_000));
    gl.clear(gl.COLOR_BUFFER_BIT);
    gl.useProgram(this.program);
    gl.uniform1f(this.uniforms.time, elapsed);
    gl.uniform1f(this.uniforms.level, normalized);
    gl.uniform2f(this.uniforms.resolution, this.canvas.width, this.canvas.height);
    gl.drawArrays(gl.POINTS, 0, particles);

    if (this.cpuBurn) {
      const burnMs = 1.5 + this.level * 0.055;
      const end = performance.now() + burnMs;
      let x = 0.1234;
      while (performance.now() < end) x = Math.sin(x * 19.7) + Math.cos(x * 7.1);
      this._burnSink = x;
    }

    if ((Math.floor(elapsed * 4) & 3) === 0) {
      this.dispatchEvent(new CustomEvent('metrics', { detail: { fps: this.fps, instances: particles } }));
    }
  };

  dispose() {
    this.resizeObserver?.disconnect();
    cancelAnimationFrame(this.animationId);
    if (this.gl && this.program) this.gl.deleteProgram(this.program);
    this.canvas?.remove();
    this.canvas = null;
    this.gl = null;
    this.program = null;
  }
}

function compile(gl, type, source) {
  const shader = gl.createShader(type);
  gl.shaderSource(shader, source);
  gl.compileShader(shader);
  if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) {
    throw new Error(`WebGL shader compile failed: ${gl.getShaderInfoLog(shader)}`);
  }
  return shader;
}
