# Backspin '96 — Cinematic Warehouse Booth Phase 6A.3 v1.5.0

This slice begins translating the approved reactive warehouse props & polish north star into the working Backspin booth without rewriting the protected audio/control core.

## What changed

- Added **Full Booth** and **Performance Rig** framing presets.
- Added keyboard framing shortcuts: `Alt+Shift+1` and `Alt+Shift+2`.
- The Lab now **defaults closed on startup**, even if the last session ended in Lab mode.
- Added CRT source hotkeys:
  - `Alt+Shift+P` — Performance Monitor
  - `Alt+Shift+T` — Signal Tunnel
  - `Alt+Shift+H` — Health / Status
- Added a restrained CRT source-switch transition.
- Deepened the warehouse with wall, ceiling, floor, desk-leg, under-desk, cable-loom, shadow, sticker, and auxiliary-monitor layers.
- Refined CRT, deck, platter, mixer, knob, button, and room materials.
- The tunnel remains available as a CRT source and a Lab stress tool rather than dominating Booth mode.
- Evidence reports now include booth framing and source-hotkey capability.

## Run

```bash
python serve.py
```

Open `http://127.0.0.1:8080`.

## Proof run

1. Start dual audio and load two tracks.
2. Scratch and mix from the physical rig in **Full Booth**.
3. Switch to **Performance Rig** and verify the physical controls enlarge without restarting audio.
4. Use the CRT source hotkeys to switch among Performance Monitor, Signal Tunnel, and Health.
5. Open and close Lab; verify it remains evidence-on-demand and never covers the decks.
6. Enter Safe Flat and confirm the complete canonical control interface remains intact.
7. Export evidence.

## Presentation shortcuts

- `Alt+Shift+1` — Full Booth
- `Alt+Shift+2` — Performance Rig
- `Alt+Shift+P` — Performance Monitor
- `Alt+Shift+T` — Signal Tunnel
- `Alt+Shift+H` — Health / Status
- `Alt+Shift+B` — Booth
- `Alt+Shift+L` — Lab
- `Alt+Shift+F` — Safe Flat

## Verification

```bash
npm test
```

**Backspin Law:** The room may glow, deepen, switch views, and disappear. It may never stand between the DJ and the sound.


## Phase 6A.3 additions

- Foreground record crates and sleeve props
- Rave flyer fan and cassette culture details
- Headphones hero prop and desk clutter tags
- Warm practical lamps and lived-in sticker pass
- CSS-variable reactive polish tied to deck/mixer visual state
- Performance-Rig cleanup so props stay secondary during play


## Phase 6A.3 repair

- Raises both record crates into visible side framing zones.
- Moves flyers and headphones onto a pointer-safe front bezel strip.
- Gives the practical lamps articulated arms, bases, shades, and larger warm light pools.
- Strengthens sticker visibility and pre-audio hardware contrast.
- Keeps Lab closed on performance startup and recedes props whenever Lab is opened.


## Phase 6A.3 additions

- Raised side crates and brighter sleeve visibility
- Front-edge flyer strip positioning
- Clearly visible draped headphones
- Stronger practical-lamp silhouettes and warm light pools
- Better offline button/pad/knob contrast
- Props recede when Lab is open or Rig framing is selected


## Phase 6A.3 additions

- Authoritative [hidden] enforcement for the docked diagnostics drawer
- OPEN LAB / CLOSE LAB trigger text now stays in sync with real drawer authority
- Front headphones promoted as a clear hero prop
- Crate labels lifted and sleeves brightened
- Warm practical spill now reaches the adjacent deck surfaces


## Phase 6A.3 additions

- Material pass for CRT shell, glass, and performance monitor readability
- Richer tactile deck and mixer materials with stronger shadows and highlights
- More convincing warm practical spill and under-desk glow
- No transport or authority changes; this is a visual/material polish slice


## Phase 6A.3 additions

- Subtle channel-specific speaker-cone response
- Live rack and side-console indicator activity
- Drifting haze and dust-mote ambience
- Rear booth LED strip and channel beacons
- Restrained CRT phosphor roll during playback
- Analog practical-lamp flutter
- Recording and Auto Mix environmental callouts
- Effects Off and reduced-motion parity


## Phase 6A.3 additions

- Speaker cabinets moved to dedicated outer lanes
- Rack towers shifted inward and lower so they no longer mask the woofers
- Side processor consoles lowered beneath the speaker lane
- Reactive driver movement preserved on the now-visible speaker cones


## Phase 6A.3 — Smart Crates & Auto-Mix Queue

- Import multiple downloaded Suno MP3/WAV/M4A/OGG/FLAC files
- Deduplicate audio by SHA-256 content hash
- Persist audio blobs and metadata in IndexedDB
- Request persistent browser storage and show usage/quota
- Search and sort by title, artist, BPM, duration, or import date
- Create Backspin crates and save optional Suno playlist/share links as metadata
- Background BPM/duration analysis queue
- Preview, Load A, Load B, queue, move, and remove actions
- Export/import portable crate manifests
- Dedicated CRT CRATE LIBRARY source (Alt+Shift+Y)

Direct Suno account scraping is intentionally not used. Locally held audio is the only audio source admitted to the scratch timeline.


## Phase 6A.3 additions

- Favorites, 0–5 ratings, 1–5 energy, tags, notes, and manual BPM authority
- Batch selection, batch queueing, batch favorites, and batch crate moves
- BPM-family-aware Smart Set planner with tolerance, length, and energy arc
- Queue reordering and removal controls
- PREP QUIET DECK based on the current crossfader / deck state
- Optional AUTO-FEED after a completed Auto Mix when Stop Old Deck is enabled
- Manifest v2 preserves prep metadata without pretending missing audio is playable


## Phase 6A.3 additions

- IndexedDB import / repair / audit / recovery receipts
- Full library integrity scan and visible health dashboard
- Missing-audio repair by hash, filename, and file size
- Recovery-manifest v3 with crates, prep metadata, queue, settings, and receipts
- Queue journal with one-step previous-queue restore
- Reversible trash and explicit permanent purge
- Queue orphan cleanup and safer bulk trash operations
