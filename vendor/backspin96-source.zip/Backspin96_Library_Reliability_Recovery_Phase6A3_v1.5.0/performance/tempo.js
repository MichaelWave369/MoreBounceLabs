import { clamp } from '../audio/protocol.js';

export function normalizeBpm(value, min = 60, max = 190) {
  let bpm = Number(value);
  if (!Number.isFinite(bpm) || bpm <= 0) return null;
  while (bpm < min) bpm *= 2;
  while (bpm > max) bpm /= 2;
  return clamp(bpm, min, max);
}

export function bpmFamily(value, { min = 45, max = 240 } = {}) {
  const bpm = Number(value);
  if (!Number.isFinite(bpm) || bpm <= 0) return [];
  const factors = [0.25, 0.5, 1, 2, 4];
  const candidates = [];
  for (const factor of factors) {
    const candidate = bpm * factor;
    if (candidate < min || candidate > max) continue;
    if (!candidates.some((entry) => Math.abs(entry.bpm - candidate) < 1e-9)) {
      candidates.push({ bpm: candidate, factor });
    }
  }
  return candidates.sort((a, b) => Math.abs(Math.log2(a.factor)) - Math.abs(Math.log2(b.factor)));
}

export function median(values) {
  const finite = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!finite.length) return null;
  const middle = Math.floor(finite.length / 2);
  return finite.length % 2 ? finite[middle] : (finite[middle - 1] + finite[middle]) / 2;
}

export function calculateTapTempo(timestampsMs, { minBpm = 60, maxBpm = 190, maxGapMs = 2500 } = {}) {
  const taps = timestampsMs.filter(Number.isFinite);
  if (taps.length < 2) return null;
  const intervals = [];
  for (let i = 1; i < taps.length; i += 1) {
    const gap = taps[i] - taps[i - 1];
    if (gap > 80 && gap <= maxGapMs) intervals.push(gap);
  }
  if (!intervals.length) return null;
  const center = median(intervals);
  const filtered = intervals.filter((value) => Math.abs(value - center) <= center * 0.22);
  const interval = median(filtered.length ? filtered : intervals);
  return normalizeBpm(60_000 / interval, minBpm, maxBpm);
}

export function syncPitchPercent(sourceBpm, targetBaseBpm, { min = -16, max = 16 } = {}) {
  const source = normalizeBpm(sourceBpm);
  const target = normalizeBpm(targetBaseBpm);
  if (!source || !target) return { ok: false, reason: 'missing-bpm', percent: 0, unclamped: 0, targetFamilyFactor: 1, targetFamilyBpm: target };
  const unclamped = (source / target - 1) * 100;
  const percent = clamp(unclamped, min, max);
  return {
    ok: Math.abs(unclamped - percent) < 0.0001,
    reason: Math.abs(unclamped - percent) < 0.0001 ? 'matched' : 'outside-pitch-range',
    percent,
    unclamped,
    targetFamilyFactor: 1,
    targetFamilyBpm: target,
  };
}

export function smartSyncPitchPercent(sourceBpm, targetBaseBpm, { min = -16, max = 16 } = {}) {
  const source = Number(sourceBpm);
  const target = Number(targetBaseBpm);
  if (!Number.isFinite(source) || source <= 0 || !Number.isFinite(target) || target <= 0) {
    return { ok: false, reason: 'missing-bpm', percent: 0, unclamped: 0, targetFamilyFactor: 1, targetFamilyBpm: null };
  }

  const candidates = bpmFamily(target);
  let best = null;
  for (const candidate of candidates) {
    const unclamped = (source / candidate.bpm - 1) * 100;
    const feasible = unclamped >= min && unclamped <= max;
    const score = Math.abs(unclamped) + Math.abs(Math.log2(candidate.factor)) * 0.35;
    const entry = { ...candidate, unclamped, feasible, score };
    if (!best || (entry.feasible && !best.feasible) || (entry.feasible === best.feasible && entry.score < best.score)) best = entry;
  }

  if (!best) return { ok: false, reason: 'missing-bpm', percent: 0, unclamped: 0, targetFamilyFactor: 1, targetFamilyBpm: null };
  const percent = clamp(best.unclamped, min, max);
  return {
    ok: best.feasible,
    reason: best.feasible ? (best.factor === 1 ? 'matched' : 'family-matched') : 'outside-pitch-range',
    percent,
    unclamped: best.unclamped,
    targetFamilyFactor: best.factor,
    targetFamilyBpm: best.bpm,
  };
}

export function effectiveBpm(baseBpm, pitchRatio = 1) {
  const base = Number(baseBpm);
  return Number.isFinite(base) && base > 0 ? base * (Number.isFinite(pitchRatio) ? pitchRatio : 1) : null;
}

export function beatDurationSeconds(bpm) {
  const value = Number(bpm);
  return Number.isFinite(value) && value > 0 ? 60 / value : null;
}

export function framesPerBeat(sampleRate, bpm) {
  const duration = beatDurationSeconds(bpm);
  return duration && Number.isFinite(sampleRate) && sampleRate > 0 ? sampleRate * duration : null;
}

export function beatPhase(sourceFrame, sampleRate, bpm, beatOffsetFrame = 0) {
  const fpb = framesPerBeat(sampleRate, bpm);
  if (!fpb || !Number.isFinite(sourceFrame)) return null;
  const phaseFrames = ((sourceFrame - beatOffsetFrame) % fpb + fpb) % fpb;
  return phaseFrames / fpb;
}

export function quantizeFrameToBeat(sourceFrame, sampleRate, bpm, beatOffsetFrame = 0, mode = 'floor') {
  const fpb = framesPerBeat(sampleRate, bpm);
  if (!fpb || !Number.isFinite(sourceFrame)) return Math.max(0, Math.floor(Number(sourceFrame) || 0));
  const relative = (sourceFrame - beatOffsetFrame) / fpb;
  const beatIndex = mode === 'ceil' ? Math.ceil(relative) : mode === 'round' ? Math.round(relative) : Math.floor(relative);
  return Math.max(0, Math.round(beatOffsetFrame + beatIndex * fpb));
}

export function loopBoundsFromBeats(sourceFrame, sampleRate, bpm, beats, beatOffsetFrame = 0) {
  const fpb = framesPerBeat(sampleRate, bpm);
  const beatCount = Math.max(1, Math.round(Number(beats) || 1));
  if (!fpb) return null;
  const startFrame = quantizeFrameToBeat(sourceFrame, sampleRate, bpm, beatOffsetFrame, 'floor');
  return {
    startFrame,
    endFrame: Math.round(startFrame + fpb * beatCount),
    beats: beatCount,
    framesPerBeat: fpb,
  };
}

export function msUntilNextBoundary(sourceFrame, sampleRate, baseBpm, beatOffsetFrame = 0, playbackRatio = 1, boundaryBeats = 1) {
  const fpb = framesPerBeat(sampleRate, baseBpm);
  const beats = Math.max(1, Math.round(Number(boundaryBeats) || 1));
  const speed = Math.max(0.05, Math.abs(Number(playbackRatio) || 1));
  if (!fpb || !Number.isFinite(sourceFrame)) return 0;
  const boundaryFrames = fpb * beats;
  const relative = ((sourceFrame - beatOffsetFrame) % boundaryFrames + boundaryFrames) % boundaryFrames;
  const remainingFrames = relative < fpb * 0.02 ? 0 : boundaryFrames - relative;
  return Math.max(0, remainingFrames / sampleRate / speed * 1000);
}

export function msUntilNextBeat(sourceFrame, sampleRate, baseBpm, beatOffsetFrame = 0, playbackRatio = 1) {
  return msUntilNextBoundary(sourceFrame, sampleRate, baseBpm, beatOffsetFrame, playbackRatio, 1);
}
