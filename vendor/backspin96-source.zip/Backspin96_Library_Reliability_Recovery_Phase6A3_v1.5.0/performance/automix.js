import { clamp } from '../audio/protocol.js';

export function smoothstep01(value) {
  const t = clamp(Number(value) || 0, 0, 1);
  return t * t * (3 - 2 * t);
}

export function automixPosition(direction, progress) {
  const shaped = smoothstep01(progress);
  return direction === 'B_TO_A' ? 1 - shaped * 2 : -1 + shaped * 2;
}

export function resolveAutomixDirection(crossfader, requested = 'AUTO') {
  if (requested === 'A_TO_B' || requested === 'B_TO_A') return requested;
  return Number(crossfader) > 0 ? 'B_TO_A' : 'A_TO_B';
}

export function automixDecks(direction) {
  return direction === 'B_TO_A'
    ? { source: 'B', target: 'A', finalPosition: -1 }
    : { source: 'A', target: 'B', finalPosition: 1 };
}
