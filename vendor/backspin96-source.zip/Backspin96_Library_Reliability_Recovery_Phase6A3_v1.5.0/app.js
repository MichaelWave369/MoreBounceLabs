import { BackspinMixerSystem } from './audio/engine.js';
import { StressScene } from './visual/stress-scene.js';
import { MovingWaveform } from './visual/waveform-view.js';
import { percentile } from './audio/protocol.js';
import { calculateTapTempo, msUntilNextBoundary, beatDurationSeconds } from './performance/tempo.js';
import { automixDecks, resolveAutomixDirection, smoothstep01 } from './performance/automix.js';
import { WorldController } from './world/world-controller.js';
import { HardwareSurface } from './world/hardware/hardware-surface.js';
import { DiagnosticsDrawer } from './world/lab/diagnostics-drawer.js';
import { CrtSourceRouter } from './world/crt/source-router.js';
import { SunoCrateBridge } from './library/suno-crate-bridge.js';
import { ViewModeController } from './world/view-mode-controller.js';
import { BoothComposition } from './world/booth/booth-composition.js';
import { PerformanceMonitor } from './world/crt/performance-monitor.js';
import { FramingController } from './world/booth/framing-controller.js';

const $ = (selector) => document.querySelector(selector);
const system = new BackspinMixerSystem();
const visual = new StressScene($('#visualHost'));
const bench = {
  visualFpsSamples: [],
  longTasks: 0,
  visualInstances: 0,
  audioTelemetryAt: { A: 0, B: 0 },
};

const globalUi = {
  isolationState: $('#isolationState'),
  startAudio: $('#startAudio'), startBoth: $('#startBoth'), panicStop: $('#panicStop'), mixerState: $('#mixerState'),
  visualStatePill: $('#visualStatePill'), stressLevel: $('#stressLevel'), stressValue: $('#stressValue'), cpuBurn: $('#cpuBurn'),
  killVisual: $('#killVisual'), recoverVisual: $('#recoverVisual'), exportEvidence: $('#exportEvidence'),
  faultDeck: $('#faultDeck'), providerDelay: $('#providerDelay'), dropRegion: $('#dropRegion'), forceSeek: $('#forceSeek'),
  sampleRateMetric: $('#sampleRateMetric'), quantumMetric: $('#quantumMetric'), aRegionMetric: $('#a-region-metric'), bRegionMetric: $('#b-region-metric'),
  aUnderrunMetric: $('#a-underrun-metric'), bUnderrunMetric: $('#b-underrun-metric'), callbackMetric: $('#callbackMetric'), xfadeMetric: $('#xfadeMetric'),
  tempoMetric: $('#tempoMetric'), masterMetric: $('#masterMetric'), fpsMetric: $('#fpsMetric'), audioAgeMetric: $('#audioAgeMetric'),
  eventLog: $('#eventLog'), clearLog: $('#clearLog'), meterA: $('#meterA'), meterB: $('#meterB'), meterMaster: $('#meterMaster'),
  crossfader: $('#crossfader'), crossfaderValue: $('#crossfader-value'), cutA: $('#cutA'), cutB: $('#cutB'), centerX: $('#centerX'),
  master: $('#master'), masterValue: $('#master-value'), xfadeCurve: $('#xfade-curve'), xfadeCurveValue: $('#xfade-curve-value'),
  syncMaster: $('#syncMaster'), autoSyncEnabled: $('#autoSyncEnabled'), syncReadout: $('#syncReadout'),
  automixDirection: $('#automixDirection'), automixDuration: $('#automixDuration'), automixDurationValue: $('#automixDurationValue'),
  automixTempoStrategy: $('#automixTempoStrategy'), automixPhraseBars: $('#automixPhraseBars'), automixPhraseLock: $('#automixPhraseLock'), automixUseCue1: $('#automixUseCue1'),
  automixSync: $('#automixSync'), automixBeatStart: $('#automixBeatStart'), automixStopSource: $('#automixStopSource'),
  automixStart: $('#automixStart'), automixCancel: $('#automixCancel'), automixState: $('#automixState'),
  echoTime: $('#echo-time'), echoTimeValue: $('#echo-time-value'), echoFeedback: $('#echo-feedback'), echoFeedbackValue: $('#echo-feedback-value'), echoKill: $('#echo-kill'),
  cueLevel: $('#cue-level'), cueLevelValue: $('#cue-level-value'), cueMix: $('#cue-mix'), cueMixValue: $('#cue-mix-value'),
  recordStart: $('#recordStart'), recordStop: $('#recordStop'), recordingState: $('#recordingState'), recordingMetric: $('#recordingMetric'),
};

const deckUi = {
  A: makeDeckUi('a', 'A'),
  B: makeDeckUi('b', 'B'),
};

const world = new WorldController({ root: document.body });
world.addEventListener('world-event', (event) => {
  const { kind, mode, quality, reason } = event.detail;
  appendLog('world', `Visual ${kind}`, reason || mode || quality || 'state changed');
});
world.init();

const diagnostics = new DiagnosticsDrawer({ root: document });
diagnostics.init();
const sourceRouter = new CrtSourceRouter({ root: document });
sourceRouter.addEventListener('source-change', (event) => appendLog('world', 'CRT source', `${event.detail.source} / ${event.detail.reason}`));
sourceRouter.init();
const sunoCrate = new SunoCrateBridge({
  root: document,
  openSource: () => sourceRouter.setSource('library', 'Crate import opened the local library'),
  onEvent: (kind, detail) => appendLog('crate', kind, detail),
  getMixState: () => ({
    crossfader: system.crossfader,
    trackA: Boolean(system.decks.A.track),
    trackB: Boolean(system.decks.B.track),
    playingA: Boolean(deckUi.A.transport?.playing),
    playingB: Boolean(deckUi.B.transport?.playing),
  }),
  loadDeck: async (deckId, file, trackMeta) => {
    if (!system.ready) await system.start();
    await system.decks[deckId].loadFile(file);
    appendLog('crate', `Loaded ${trackMeta.title} to Deck ${deckId}`, trackMeta.fileName);
  },
});
sunoCrate.init().catch((error) => appendLog('fault', 'Suno Crate Bridge startup', error.message));
const viewModes = new ViewModeController({ root: document.body, shell: world.shell, drawer: diagnostics });
viewModes.addEventListener('mode-change', (event) => appendLog('world', 'Presentation mode', `${event.detail.mode} / ${event.detail.reason}`));
viewModes.init();
const performanceMonitor = new PerformanceMonitor({ root: document });
performanceMonitor.init();
const framing = new FramingController({ root: document.body });
framing.addEventListener('frame-change', (event) => appendLog('world', 'Booth framing', `${event.detail.frame} / ${event.detail.reason}`));
framing.init();
const boothComposition = new BoothComposition({ root: document.body, drawer: diagnostics, framing });
boothComposition.addEventListener('fit-change', (event) => {
  const fit = event.detail;
  if (fit.policy === 'flat' && viewModes.mode !== 'flat') viewModes.setMode('flat', 'Viewport below full-booth minimum', false);
});
boothComposition.init();

const hardware = new HardwareSurface({ root: document });
hardware.addEventListener('hardware-action', (event) => {
  const { kind, targetId, value } = event.detail;
  appendLog('hardware', `${kind} → ${targetId}`, String(value ?? ''));
});
hardware.addEventListener('platter-pointer', (event) => {
  const { deckId, element, event: pointerEvent } = event.detail;
  handlePlatterPointer(pointerEvent, deckId, element);
});
hardware.addEventListener('platter-key', (event) => {
  const { deckId, event: keyEvent } = event.detail;
  handlePlatterKey(keyEvent, deckId);
});
hardware.init();

let longTaskObserver = null;
let activeAutoMix = null;
let autoSyncBusy = false;
let lastAutoSyncKey = '';
let visualSequence = 0;

globalUi.isolationState.textContent = crossOriginIsolated ? 'cross-origin isolated / SAB-ready' : 'copy transport / isolation unavailable';

try {
  longTaskObserver = new PerformanceObserver((list) => { bench.longTasks += list.getEntries().length; });
  longTaskObserver.observe({ type: 'longtask', buffered: true });
} catch {}

wireRotaries();
for (const deckId of ['A', 'B']) wireDeck(deckId);
wireMixerControls();
wireTempoControls();
wireAutoMix();
wireRecording();
wireVisuals();

system.addEventListener('ready', (event) => {
  setAllControlsEnabled(true);
  globalUi.startAudio.textContent = 'DUAL AUDIO RUNNING';
  globalUi.startAudio.disabled = true;
  globalUi.startBoth.disabled = false;
  globalUi.panicStop.disabled = false;
  globalUi.mixerState.textContent = 'ONLINE';
  globalUi.mixerState.className = 'pill pill-ok';
  globalUi.recordStart.disabled = false;
  globalUi.recordStop.disabled = true;
  globalUi.sampleRateMetric.textContent = `${event.detail.sampleRate.toLocaleString()} Hz`;
  appendLog('engine', 'Phase 5D.1a prop-visibility repair audio baseline ready', `sampleRate=${event.detail.sampleRate}`);
});

system.addEventListener('fault', (event) => {
  cancelAutoMix('audio-fault');
  const { deckId, source, message } = event.detail;
  const ui = deckUi[deckId];
  if (ui) {
    ui.state.textContent = source === 'watchdog' ? 'STALLED' : 'FAULT';
    ui.state.className = 'pill pill-bad';
  }
  globalUi.mixerState.textContent = 'REBUILD NEEDED';
  globalUi.mixerState.className = 'pill pill-bad';
  globalUi.startAudio.disabled = false;
  globalUi.startAudio.textContent = 'REBUILD DUAL AUDIO';
  appendLog('fault', `Deck ${deckId ?? '?'} / ${source}`, message);
});

system.addEventListener('context-state', (event) => appendLog('engine', 'AudioContext state', event.detail.state));
system.addEventListener('ledger', (event) => {
  const { event: name, detail } = event.detail;
  const important = [
    'provider-delay', 'fault-arm', 'generation-seek', 'region-not-delivered', 'regions-invalidated',
    'dual-start', 'panic-stop', 'tempo-sync', 'bpm-analysis-complete', 'bpm-analysis-failed', 'bpm-manual', 'crossfader-curve',
    'beat-grid-set', 'hot-cue-set', 'hot-cue-trigger', 'hot-cue-clear', 'loop-set', 'loop-clear', 'pfl-change', 'echo-kill', 'recording-start', 'recording-stop',
  ];
  if (important.includes(name)) appendLog('ledger', name, compact(detail));
});

system.addEventListener('tempo-sync', (event) => {
  const detail = event.detail;
  const targetUi = deckUi[detail.targetDeckId];
  const locked = detail.reason === 'matched' || detail.reason === 'family-matched';
  targetUi.syncState.textContent = locked ? `LOCKED TO ${detail.sourceDeckId}` : detail.reason.toUpperCase();
  const family = detail.targetFamilyFactor && detail.targetFamilyFactor !== 1 ? ` / ${detail.targetFamilyFactor}× family` : '';
  globalUi.syncReadout.textContent = locked
    ? `${detail.targetDeckId} ${signed(detail.percent, 2)}%${family}`
    : detail.reason.toUpperCase();
  appendLog('tempo', `${detail.targetDeckId} synced from ${detail.sourceDeckId}`, `${signed(detail.percent, 2)}% / ${detail.reason}${family}`);
});

globalUi.startAudio.addEventListener('click', async () => {
  try {
    globalUi.startAudio.disabled = true;
    globalUi.startAudio.textContent = 'STARTING TWO KERNELS…';
    await system.start();
  } catch (error) {
    globalUi.startAudio.disabled = false;
    globalUi.startAudio.textContent = 'RETRY DUAL AUDIO';
    globalUi.mixerState.textContent = 'START FAILED';
    globalUi.mixerState.className = 'pill pill-bad';
    appendLog('fault', 'Dual audio start failed', error.message);
  }
});

globalUi.startBoth.addEventListener('click', async () => {
  try { await system.startBoth(); }
  catch (error) { appendLog('fault', 'Start both failed', error.message); }
});
globalUi.panicStop.addEventListener('click', () => {
  cancelAutoMix('panic-stop');
  system.pauseAll();
});

globalUi.faultDeck.addEventListener('change', () => {
  const deck = system.decks[globalUi.faultDeck.value];
  globalUi.providerDelay.value = String(deck.provider.delayMs);
});
globalUi.providerDelay.addEventListener('change', () => system.decks[globalUi.faultDeck.value].setProviderDelay(globalUi.providerDelay.value));
globalUi.dropRegion.addEventListener('click', () => system.decks[globalUi.faultDeck.value].dropNextRegion());
globalUi.forceSeek.addEventListener('click', () => {
  const deck = system.decks[globalUi.faultDeck.value];
  if (!deck.track) return;
  deck.seekNormalized(Math.min(.98, Math.random() * .9 + .05), 'fault-generation-seek');
});

globalUi.clearLog.addEventListener('click', () => globalUi.eventLog.replaceChildren());
globalUi.exportEvidence.addEventListener('click', () => {
  const report = system.exportEvidence({
    visualWorld: world.exportState(),
    tactileHardware: { enabled: true, surface: 'Phase 5D.1a prop-visible tactile rig / canonical control mirror' },
    presentation: { ...viewModes.exportState(), ...framing.exportState(), ...sourceRouter.exportState(), drawer: diagnostics.exportState(), fit: boothComposition.exportState(), viewport: { width: innerWidth, height: innerHeight, dpr: devicePixelRatio || 1 } },
    sunoCrate: sunoCrate.exportState(),
    performanceControls: {
      autoSyncEnabled: globalUi.autoSyncEnabled.checked,
      syncMaster: globalUi.syncMaster.value,
      crossfaderCurve: Number(globalUi.xfadeCurve.value),
      automix: {
        direction: globalUi.automixDirection.value,
        durationSeconds: Number(globalUi.automixDuration.value),
        tempoStrategy: globalUi.automixTempoStrategy.value,
        phraseBars: Number(globalUi.automixPhraseBars.value),
        phraseLock: globalUi.automixPhraseLock.checked,
        useCue1: globalUi.automixUseCue1.checked,
        matchBpm: globalUi.automixSync.checked,
        phraseStart: globalUi.automixBeatStart.checked,
        stopSource: globalUi.automixStopSource.checked,
        active: Boolean(activeAutoMix),
      },
    },
    bench: {
      visualFps: {
        p50: percentile(bench.visualFpsSamples, 50),
        p05: percentile(bench.visualFpsSamples, 5),
        min: bench.visualFpsSamples.length ? Math.min(...bench.visualFpsSamples) : 0,
        sampleCount: bench.visualFpsSamples.length,
        lastInstanceCount: bench.visualInstances,
      },
      longTasks: bench.longTasks,
      recording: system.mediaRecorder?.state === 'recording',
      stressLevel: Number(globalUi.stressLevel.value),
      cpuBurn: globalUi.cpuBurn.checked,
      meters: system.getMeters(),
    },
  });
  downloadJson(`backspin96-phase6a1-evidence-${new Date().toISOString().replace(/[:.]/g, '-')}.json`, report);
  appendLog('evidence', 'Phase 6A.1 report exported', `${report.ledger.length} system records`);
});

window.addEventListener('keydown', (event) => {
  if (!system.ready || event.repeat || isTypingTarget(event.target)) return;
  if (event.code === 'KeyQ') { event.preventDefault(); system.decks.A.togglePlay(); }
  if (event.code === 'KeyW') { event.preventDefault(); system.decks.A.cueStart(); }
  if (event.code === 'KeyE') { event.preventDefault(); tapDeck('A'); }
  if (event.code === 'KeyO') { event.preventDefault(); system.decks.B.togglePlay(); }
  if (event.code === 'KeyP') { event.preventDefault(); system.decks.B.cueStart(); }
  if (event.code === 'BracketLeft') { event.preventDefault(); tapDeck('B'); }
  if (event.code === 'Digit1') { event.preventDefault(); setCrossfader(-1); }
  if (event.code === 'Digit2') { event.preventDefault(); setCrossfader(0); }
  if (event.code === 'Digit3') { event.preventDefault(); setCrossfader(1); }
  if (event.code === 'KeyM') { event.preventDefault(); startAutoMix(); }
  if (event.code === 'KeyA' && event.altKey) { event.preventDefault(); triggerOrSetHotCue('A', 0, event.shiftKey); }
  if (event.code === 'KeyS' && event.altKey) { event.preventDefault(); triggerOrSetHotCue('A', 1, event.shiftKey); }
  if (event.code === 'KeyK' && event.altKey) { event.preventDefault(); triggerOrSetHotCue('B', 0, event.shiftKey); }
  if (event.code === 'KeyL' && event.altKey) { event.preventDefault(); triggerOrSetHotCue('B', 1, event.shiftKey); }
  if (event.code === 'Escape') cancelAutoMix('keyboard-veto');
});

let lastAnimationAt = performance.now();
function animateUi(now) {
  const dt = Math.min(.1, (now - lastAnimationAt) / 1000);
  lastAnimationAt = now;
  for (const deckId of ['A', 'B']) {
    const ui = deckUi[deckId];
    if (ui.transport) {
      const nominalRps = 33.333 / 60;
      ui.platterAngle += Math.PI * 2 * nominalRps * ui.transport.pitchRatio * ui.transport.jogRatio * dt;
      ui.platter.style.transform = `rotate(${ui.platterAngle}rad)`;
    }
    ui.waveform.render(now);
  }

  let visualMeters = { A: { db: -60 }, B: { db: -60 }, master: { db: -60 } };
  if (system.ready) {
    const meters = system.getMeters();
    visualMeters = meters;
    paintMeter(globalUi.meterA, meters.A.db);
    paintMeter(globalUi.meterB, meters.B.db);
    paintMeter(globalUi.meterMaster, meters.master.db);
    globalUi.masterMetric.textContent = `${meters.master.db.toFixed(1)} dB`;
    if (system.mediaRecorder?.state === 'recording' && system.recordingStartedAt) {
      const elapsed = (performance.now() - system.recordingStartedAt) / 1000;
      globalUi.recordingMetric.textContent = `REC ${formatTime(elapsed)}`;
      globalUi.recordingState.textContent = `RECORDING ${formatTime(elapsed)}`;
    }
  }

  const ageA = bench.audioTelemetryAt.A ? performance.now() - bench.audioTelemetryAt.A : 0;
  const ageB = bench.audioTelemetryAt.B ? performance.now() - bench.audioTelemetryAt.B : 0;
  globalUi.audioAgeMetric.textContent = bench.audioTelemetryAt.A && bench.audioTelemetryAt.B
    ? `${ageA.toFixed(0)} / ${ageB.toFixed(0)} ms`
    : '—';

  world.updateSnapshot({
    sequence: ++visualSequence,
    decks: {
      A: {
        angle: deckUi.A.platterAngle,
        playing: Boolean(deckUi.A.transport?.playing),
        mode: deckUi.A.transport?.mode || 'ready',
        bpm: system.decks.A.getBaseBpm?.() || 0,
        liveBpm: system.decks.A.getEffectiveBpm?.() || 0,
        loop: Boolean(system.decks.A.loop?.enabled),
      },
      B: {
        angle: deckUi.B.platterAngle,
        playing: Boolean(deckUi.B.transport?.playing),
        mode: deckUi.B.transport?.mode || 'ready',
        bpm: system.decks.B.getBaseBpm?.() || 0,
        liveBpm: system.decks.B.getEffectiveBpm?.() || 0,
        loop: Boolean(system.decks.B.loop?.enabled),
      },
    },
    mixer: {
      crossfader: system.crossfader,
      meterA: visualMeters.A.db,
      meterB: visualMeters.B.db,
      meterMaster: visualMeters.master.db,
      recording: system.mediaRecorder?.state === 'recording',
      automix: Boolean(activeAutoMix),
    },
    health: {
      underrunsA: Number(deckUi.A.transport?.underruns || 0),
      underrunsB: Number(deckUi.B.transport?.underruns || 0),
    },
  }, now);
  hardware.sync(false, now);
  sourceRouter.syncMirrors();
  boothComposition.syncBadges();
  requestAnimationFrame(animateUi);
}
requestAnimationFrame(animateUi);

function makeDeckUi(prefix, deckId) {
  return {
    deckId,
    state: $(`#${prefix}-state`), platter: $(`#${prefix}-platter`), play: $(`#${prefix}-play`), cue: $(`#${prefix}-cue`),
    tap: $(`#${prefix}-tap`), sync: $(`#${prefix}-sync`), bpm: $(`#${prefix}-bpm`), liveBpm: $(`#${prefix}-live-bpm`),
    bpmSource: $(`#${prefix}-bpm-source`), syncState: $(`#${prefix}-sync-state`),
    file: $(`#${prefix}-file`), trackName: $(`#${prefix}-track`), pitch: $(`#${prefix}-pitch`), pitchValue: $(`#${prefix}-pitch-value`),
    seek: $(`#${prefix}-seek`), seekValue: $(`#${prefix}-seek-value`), release: $(`#${prefix}-release`),
    grid: $(`#${prefix}-grid`), loopState: $(`#${prefix}-loop-state`),
    hotCueButtons: [1, 2, 3, 4].map((index) => $(`#${prefix}-hotcue-${index}`)),
    loopButtons: [...document.querySelectorAll(`.loop-pad[data-deck="${deckId}"]`)],
    pfl: $(`#${prefix}-pfl`),
    waveform: new MovingWaveform($(`#${prefix}-waveform`), { deckId }),
    track: null, transport: null, telemetryAt: 0, platterAngle: 0, gesture: null, seekDragging: false, taps: [],
  };
}

function wireDeck(deckId) {
  const deck = system.decks[deckId];
  const ui = deckUi[deckId];

  deck.addEventListener('processor-ready', (event) => appendLog('engine', `Deck ${deckId} processor handshake`, `clock=${event.detail.timingSource}`));
  deck.addEventListener('track', (event) => {
    ui.track = event.detail;
    ui.trackName.textContent = `${ui.track.name} • ${formatTime(ui.track.duration)} • ${ui.track.sampleRate.toLocaleString()} Hz`;
    ui.waveform.installTrack(ui.track);
    ui.seek.value = '0';
    ui.pitch.value = '0';
    ui.pitchValue.textContent = '+0.00%';
    ui.taps = [];
    renderHotCues(deckId, deck.hotCues);
    renderLoopState(deckId, deck.loop);
    updateRotaryVisual(ui.pitch);
    appendLog('track', `Deck ${deckId} installed`, ui.track.name);
  });
  deck.addEventListener('bpm', (event) => {
    const info = event.detail;
    ui.bpm.textContent = Number.isFinite(info.bpm) ? info.bpm.toFixed(1) : '—';
    ui.liveBpm.textContent = Number.isFinite(info.effectiveBpm) ? info.effectiveBpm.toFixed(1) : '—';
    ui.bpmSource.textContent = bpmSourceLabel(info.source, info.confidence, info.tempoFamilyFactor);
    updateTempoMetric();
    if (globalUi.autoSyncEnabled.checked && globalUi.syncMaster.value === deckId) applyAutoSync('master-bpm-change');
  });
  deck.addEventListener('pitch', (event) => {
    const info = event.detail;
    ui.pitch.value = String(info.percent);
    ui.pitchValue.textContent = `${info.percent >= 0 ? '+' : ''}${info.percent.toFixed(2)}%`;
    ui.liveBpm.textContent = Number.isFinite(info.effectiveBpm) ? info.effectiveBpm.toFixed(1) : '—';
    updateTempoMetric();
    if (globalUi.autoSyncEnabled.checked && globalUi.syncMaster.value === deckId) applyAutoSync('master-pitch-change');
  });
  deck.addEventListener('hotcue', (event) => renderHotCues(deckId, event.detail.cues));
  deck.addEventListener('loop', (event) => renderLoopState(deckId, event.detail));
  deck.addEventListener('grid', (event) => {
    renderLoopState(deckId, deck.loop);
    appendLog('grid', `Deck ${deckId} downbeat anchored`, formatTime(event.detail.beatOffsetFrame / (deck.track?.sampleRate || 48000), true));
  });
  deck.addEventListener('telemetry', (event) => {
    const t = event.detail;
    ui.transport = t;
    ui.telemetryAt = performance.now();
    bench.audioTelemetryAt[deckId] = ui.telemetryAt;
    ui.state.textContent = t.playing ? `${t.mode.toUpperCase()}` : 'READY';
    ui.state.className = 'pill pill-ok';
    ui.play.textContent = t.playing ? 'PAUSE' : 'PLAY';
    if (!ui.seekDragging && t.trackLength > 0) ui.seek.value = String(t.sourceFrame / t.trackLength);
    ui.seekValue.textContent = formatTime(t.sourceFrame / t.sampleRate, true);
    ui.platter.setAttribute('aria-valuenow', t.jogRatio.toFixed(2));
    ui.waveform.setTransport(t, ui.telemetryAt);

    if (deckId === 'A') {
      globalUi.quantumMetric.textContent = `${t.quantumFrames} fr / ${(t.quantumFrames / t.sampleRate * 1000).toFixed(2)} ms`;
      globalUi.aRegionMetric.textContent = `${t.regionReady} / ${t.regionPending}`;
      globalUi.aUnderrunMetric.textContent = t.underruns.toLocaleString();
    } else {
      globalUi.bRegionMetric.textContent = `${t.regionReady} / ${t.regionPending}`;
      globalUi.bUnderrunMetric.textContent = t.underruns.toLocaleString();
    }
    const aPeak = system.decks.A.telemetry?.callbackUtilizationPeak;
    const bPeak = system.decks.B.telemetry?.callbackUtilizationPeak;
    globalUi.callbackMetric.textContent = Number.isFinite(aPeak) && Number.isFinite(bPeak)
      ? `${(aPeak * 100).toFixed(1)}% / ${(bPeak * 100).toFixed(1)}%`
      : '—';
  });

  ui.play.addEventListener('click', async () => {
    try { await deck.togglePlay(); }
    catch (error) { appendLog('fault', `Deck ${deckId} play`, error.message); }
  });
  ui.cue.addEventListener('click', () => deck.cueStart());
  ui.tap.addEventListener('click', () => tapDeck(deckId));
  ui.sync.addEventListener('click', () => syncDeckFromOther(deckId, 'deck-button'));
  ui.grid.addEventListener('click', () => deck.setGridHere());
  ui.hotCueButtons.forEach((button, cueIndex) => {
    button.addEventListener('click', (event) => triggerOrSetHotCue(deckId, cueIndex, event.shiftKey));
    button.addEventListener('contextmenu', (event) => { event.preventDefault(); deck.clearHotCue(cueIndex); });
  });
  ui.loopButtons.forEach((button) => button.addEventListener('click', () => {
    const beats = Number(button.dataset.beats);
    const result = deck.toggleLoopBeats(beats);
    if (!result && !deck.loop.enabled) appendLog('loop', `Deck ${deckId} loop off`, `${beats} beat toggle`);
    else if (!result) appendLog('loop', `Deck ${deckId} loop unavailable`, 'set/tap BPM first');
  }));
  ui.pfl.addEventListener('click', () => {
    const enabled = ui.pfl.getAttribute('aria-pressed') !== 'true';
    ui.pfl.setAttribute('aria-pressed', String(enabled));
    ui.pfl.classList.toggle('is-active', enabled);
    system.setPfl(deckId, enabled);
  });
  ui.file.addEventListener('change', async () => {
    const file = ui.file.files?.[0];
    if (!file) return;
    ui.trackName.textContent = `Decoding ${file.name}…`;
    ui.bpm.textContent = '…';
    ui.bpmSource.textContent = 'ANALYZING';
    try { await deck.loadFile(file); }
    catch (error) { appendLog('fault', `Deck ${deckId} decode`, error.message); ui.trackName.textContent = `Could not decode ${file.name}`; }
  });
  ui.pitch.addEventListener('input', () => {
    const value = Number(ui.pitch.value);
    ui.pitchValue.textContent = `${value >= 0 ? '+' : ''}${value.toFixed(2)}%`;
    deck.setPitchPercent(value);
  });
  ui.seek.addEventListener('pointerdown', () => { ui.seekDragging = true; });
  ui.seek.addEventListener('input', () => {
    if (ui.track) ui.seekValue.textContent = formatTime(Number(ui.seek.value) * ui.track.duration, true);
  });
  const commitSeek = () => {
    if (!ui.seekDragging) return;
    ui.seekDragging = false;
    deck.seekNormalized(Number(ui.seek.value));
  };
  ui.seek.addEventListener('change', commitSeek);
  ui.seek.addEventListener('pointerup', commitSeek);

  for (const eventName of ['pointerdown', 'pointermove', 'pointerup', 'pointercancel']) {
    ui.platter.addEventListener(eventName, (event) => handlePlatterPointer(event, deckId, ui.platter));
  }
}

function handlePlatterPointer(event, deckId, surface = deckUi[deckId].platter) {
  const deck = system.decks[deckId];
  const ui = deckUi[deckId];
  if (!deck.ready) return;
  const rect = surface.getBoundingClientRect();
  const centerX = rect.left + rect.width / 2;
  const centerY = rect.top + rect.height / 2;
  const angle = Math.atan2(event.clientY - centerY, event.clientX - centerX);
  const now = performance.now();

  if (event.type === 'pointerdown') {
    surface.setPointerCapture?.(event.pointerId);
    ui.gesture = { pointerId: event.pointerId, angle, at: now, filteredRatio: 0 };
    deck.setJogRatio(0, 'scratch');
    event.preventDefault();
    return;
  }
  if (!ui.gesture || ui.gesture.pointerId !== event.pointerId) return;
  if (event.type === 'pointermove') {
    let delta = angle - ui.gesture.angle;
    if (delta > Math.PI) delta -= Math.PI * 2;
    if (delta < -Math.PI) delta += Math.PI * 2;
    const dt = Math.max(5, now - ui.gesture.at) / 1000;
    const angularVelocity = delta / dt;
    const nominal = Math.PI * 2 * (33.333 / 60);
    const ratio = Math.max(-4, Math.min(4, angularVelocity / nominal));
    ui.gesture.filteredRatio = ui.gesture.filteredRatio * .55 + ratio * .45;
    ui.gesture.angle = angle;
    ui.gesture.at = now;
    deck.setJogRatio(ui.gesture.filteredRatio, 'scratch');
    event.preventDefault();
    return;
  }
  if (event.type === 'pointerup' || event.type === 'pointercancel') {
    deck.releaseJog(ui.release.value);
    ui.gesture = null;
    event.preventDefault();
  }
}


function handlePlatterKey(event, deckId) {
  if (!system.ready || event.repeat) return;
  const deck = system.decks[deckId];
  if (!deck?.ready) return;
  const ratio = event.code === 'ArrowLeft' ? -0.58 : event.code === 'ArrowRight' ? 0.58 : 0;
  if (!ratio) return;
  event.preventDefault();
  deck.setJogRatio(ratio, 'keyboard-bend');
  window.clearTimeout(deckUi[deckId].hardwareKeyReleaseTimer);
  deckUi[deckId].hardwareKeyReleaseTimer = window.setTimeout(() => deck.releaseJog(deckUi[deckId].release.value), 95);
}

function wireMixerControls() {
  for (const deckId of ['A', 'B']) {
    const prefix = deckId.toLowerCase();
    bindMixerRange(`#${prefix}-trim`, `#${prefix}-trim-value`, (value) => system.setTrim(deckId, value), (v) => `${signed(v, 1)} dB`);
    bindMixerRange(`#${prefix}-high`, `#${prefix}-high-value`, (value) => system.setEq(deckId, 'high', value), (v) => `${signed(v, 1)} dB`);
    bindMixerRange(`#${prefix}-mid`, `#${prefix}-mid-value`, (value) => system.setEq(deckId, 'mid', value), (v) => `${signed(v, 1)} dB`);
    bindMixerRange(`#${prefix}-low`, `#${prefix}-low-value`, (value) => system.setEq(deckId, 'low', value), (v) => `${signed(v, 1)} dB`);
    bindMixerRange(`#${prefix}-filter`, `#${prefix}-filter-value`, (value) => system.setFilter(deckId, value), filterLabel);
    bindMixerRange(`#${prefix}-echo`, `#${prefix}-echo-value`, (value) => system.setEchoSend(deckId, value), (v) => `${Math.round(v * 100)}%`);
    bindMixerRange(`#${prefix}-fader`, `#${prefix}-fader-value`, (value) => system.setChannelFader(deckId, value), (v) => `${Math.round(v * 100)}%`);
  }
  globalUi.crossfader.addEventListener('input', () => {
    if (activeAutoMix) cancelAutoMix('manual-crossfader');
    setCrossfader(Number(globalUi.crossfader.value));
  });
  globalUi.cutA.addEventListener('click', () => { cancelAutoMix('manual-cut'); setCrossfader(-1); });
  globalUi.centerX.addEventListener('click', () => { cancelAutoMix('manual-center'); setCrossfader(0); });
  globalUi.cutB.addEventListener('click', () => { cancelAutoMix('manual-cut'); setCrossfader(1); });
  globalUi.master.addEventListener('input', () => {
    const value = Number(globalUi.master.value);
    globalUi.masterValue.textContent = `${Math.round(value * 100)}%`;
    system.setMaster(value);
  });
  globalUi.xfadeCurve.addEventListener('input', () => {
    const value = Number(globalUi.xfadeCurve.value);
    system.setCrossfaderCurve(value);
    globalUi.xfadeCurveValue.textContent = value < .2 ? 'SMOOTH' : value < .62 ? 'CLUB' : 'BATTLE';
  });
  globalUi.echoTime.addEventListener('input', () => {
    const value = Number(globalUi.echoTime.value);
    globalUi.echoTimeValue.textContent = `${Math.round(value)} ms`;
    system.setEchoTime(value);
  });
  globalUi.echoFeedback.addEventListener('input', () => {
    const value = Number(globalUi.echoFeedback.value);
    globalUi.echoFeedbackValue.textContent = `${Math.round(value * 100)}%`;
    system.setEchoFeedback(value);
  });
  globalUi.echoKill.addEventListener('click', () => {
    system.killEcho();
    for (const deckId of ['A', 'B']) setRangeValue($(`#${deckId.toLowerCase()}-echo`), 0);
    appendLog('fx', 'Dub echo tail killed', 'feedback restored after bounded flush');
  });
  globalUi.cueLevel.addEventListener('input', () => {
    const value = Number(globalUi.cueLevel.value);
    globalUi.cueLevelValue.textContent = `${Math.round(value * 100)}%`;
    system.setCueLevel(value);
  });
  globalUi.cueMix.addEventListener('input', () => {
    const value = Number(globalUi.cueMix.value);
    globalUi.cueMixValue.textContent = value < .05 ? 'MASTER' : value > .95 ? 'CUE' : `${Math.round(value * 100)}% CUE`;
    system.setCueMix(value);
  });
}

function wireTempoControls() {
  globalUi.syncMaster.addEventListener('change', () => {
    lastAutoSyncKey = '';
    for (const deckId of ['A', 'B']) deckUi[deckId].syncState.textContent = deckId === globalUi.syncMaster.value ? 'MASTER' : 'FREE';
    if (globalUi.autoSyncEnabled.checked) applyAutoSync('master-change');
  });
  globalUi.autoSyncEnabled.addEventListener('change', () => {
    lastAutoSyncKey = '';
    globalUi.syncReadout.textContent = globalUi.autoSyncEnabled.checked ? 'LOCK ARMED' : 'MANUAL';
    if (globalUi.autoSyncEnabled.checked) applyAutoSync('enabled');
    else {
      for (const deckId of ['A', 'B']) deckUi[deckId].syncState.textContent = deckId === globalUi.syncMaster.value ? 'MASTER' : 'FREE';
      appendLog('tempo', 'Auto BPM sync disabled', 'manual pitch control restored');
    }
  });
}

function wireAutoMix() {
  globalUi.automixDuration.addEventListener('input', () => {
    globalUi.automixDurationValue.textContent = `${Number(globalUi.automixDuration.value).toFixed(1)} s`;
  });
  globalUi.automixStart.addEventListener('click', startAutoMix);
  globalUi.automixCancel.addEventListener('click', () => cancelAutoMix('operator-veto'));
}

function wireRecording() {
  globalUi.recordStart.addEventListener('click', () => {
    try {
      system.startRecording();
    } catch (error) {
      appendLog('record', 'Could not start recording', error.message);
    }
  });
  globalUi.recordStop.addEventListener('click', async () => {
    globalUi.recordStop.disabled = true;
    globalUi.recordingState.textContent = 'FINALIZING…';
    try {
      const blob = await system.stopRecording();
      if (blob?.size) {
        const extension = blob.type.includes('ogg') ? 'ogg' : 'webm';
        downloadBlob(`backspin96-mix-${new Date().toISOString().replace(/[:.]/g, '-')}.${extension}`, blob);
        appendLog('record', 'Master recording saved', `${(blob.size / 1024 / 1024).toFixed(2)} MiB / ${blob.type}`);
      }
    } catch (error) {
      appendLog('record', 'Recording finalization failed', error.message);
    }
  });
  system.addEventListener('recording-state', (event) => {
    const recording = event.detail.recording;
    globalUi.recordStart.disabled = recording || !system.ready;
    globalUi.recordStop.disabled = !recording;
    globalUi.recordingState.textContent = recording ? 'RECORDING 0:00.0' : 'READY';
    globalUi.recordingMetric.textContent = recording ? 'REC' : (event.detail.blob ? `${(event.detail.blob.size / 1024 / 1024).toFixed(2)} MiB` : 'READY');
    globalUi.recordStart.classList.toggle('is-recording', recording);
  });
}

async function startAutoMix() {
  if (!system.ready || activeAutoMix) return;
  const direction = resolveAutomixDirection(system.crossfader, globalUi.automixDirection.value);
  const { source, target, finalPosition } = automixDecks(direction);
  const sourceDeck = system.decks[source];
  const targetDeck = system.decks[target];
  if (!sourceDeck.track || !targetDeck.track) {
    appendLog('automix', 'Cannot start', 'both decks need tracks');
    return;
  }

  let syncResult = null;
  if (globalUi.automixSync.checked) {
    syncResult = system.syncDeck(target, source, { strategy: globalUi.automixTempoStrategy.value });
    if (syncResult.reason === 'missing-bpm') {
      appendLog('automix', 'BPM match unavailable', 'tap BPM or wait for analysis');
    } else if (syncResult.reason === 'blend-only') {
      appendLog('automix', 'Smart sync chose blend-only', 'no extreme pitch push was applied');
    }
  }

  if (globalUi.automixUseCue1.checked && Number.isFinite(targetDeck.hotCues[0])) {
    targetDeck.triggerHotCue(0);
  }

  const bars = Math.max(1, Number(globalUi.automixPhraseBars.value) || 4);
  const boundaryBeats = bars * 4;
  const sourceBpm = sourceDeck.getGridBpm();
  const sourceLiveBpm = sourceDeck.getEffectiveBpm();
  const telemetry = sourceDeck.telemetry;
  const playbackRatio = telemetry?.pitchRatio ?? 1;
  const waitMs = globalUi.automixBeatStart.checked && telemetry && sourceBpm
    ? Math.min(12_000, msUntilNextBoundary(
      telemetry.sourceFrame,
      telemetry.sampleRate,
      sourceBpm,
      sourceDeck.beatOffsetFrame,
      playbackRatio,
      boundaryBeats,
    ))
    : 0;
  const phraseDuration = sourceLiveBpm
    ? beatDurationSeconds(sourceLiveBpm) * boundaryBeats * 1000
    : null;
  const durationMs = globalUi.automixPhraseLock.checked && phraseDuration
    ? phraseDuration
    : Number(globalUi.automixDuration.value) * 1000;

  const run = {
    id: crypto.randomUUID(), direction, source, target, finalPosition,
    startPosition: system.crossfader, durationMs, waitMs, cancelled: false, timer: null, raf: null,
    bars, boundaryBeats, syncResult,
  };
  activeAutoMix = run;
  globalUi.automixStart.disabled = true;
  globalUi.automixCancel.disabled = false;
  globalUi.automixState.textContent = waitMs > 10 ? `PHRASE ARMED ${Math.round(waitMs)} ms` : `${source} → ${target}`;
  appendLog('automix', `Armed ${source} → ${target}`, `${bars} bars / ${(durationMs / 1000).toFixed(2)}s / wait=${Math.round(waitMs)}ms`);

  run.timer = setTimeout(async () => {
    if (run.cancelled || activeAutoMix !== run) return;
    await targetDeck.play();
    const startedAt = performance.now();
    globalUi.automixState.textContent = `FADING ${source} → ${target}`;

    const tick = (now) => {
      if (run.cancelled || activeAutoMix !== run) return;
      const progress = Math.min(1, (now - startedAt) / durationMs);
      const shaped = smoothstep01(progress);
      const position = run.startPosition + (finalPosition - run.startPosition) * shaped;
      setCrossfader(position, { automation: true });
      globalUi.automixState.textContent = `${source} → ${target} ${Math.round(progress * 100)}%`;
      if (progress < 1) {
        run.raf = requestAnimationFrame(tick);
        return;
      }
      const stoppedSource = globalUi.automixStopSource.checked;
      if (stoppedSource) sourceDeck.pause();
      appendLog('automix', `Completed ${source} → ${target}`, stoppedSource ? `Deck ${source} stopped` : 'both decks continue');
      sunoCrate.handleAutoMixComplete({ source, target, stopped: stoppedSource }).catch((error) => appendLog('crate', 'Auto-feed failed', error.message));
      finishAutoMix('COMPLETE');
    };
    run.raf = requestAnimationFrame(tick);
  }, waitMs);
}

function cancelAutoMix(reason = 'cancelled') {
  if (!activeAutoMix) return;
  const run = activeAutoMix;
  run.cancelled = true;
  clearTimeout(run.timer);
  if (run.raf) cancelAnimationFrame(run.raf);
  appendLog('automix', 'Cancelled', reason);
  finishAutoMix('CANCELLED');
}

function finishAutoMix(label) {
  activeAutoMix = null;
  globalUi.automixState.textContent = label;
  globalUi.automixStart.disabled = !system.ready;
  globalUi.automixCancel.disabled = true;
  setTimeout(() => {
    if (!activeAutoMix && globalUi.automixState.textContent === label) globalUi.automixState.textContent = 'STANDBY';
  }, 1800);
}

function triggerOrSetHotCue(deckId, cueIndex, clear = false) {
  const deck = system.decks[deckId];
  if (clear) {
    deck.clearHotCue(cueIndex);
    return;
  }
  if (Number.isFinite(deck.hotCues[cueIndex])) {
    deck.triggerHotCue(cueIndex);
    return;
  }
  const frame = deck.setHotCue(cueIndex);
  if (!Number.isFinite(frame)) appendLog('cue', `Deck ${deckId} cue unavailable`, 'wait for track telemetry');
}

function renderHotCues(deckId, cues = []) {
  const ui = deckUi[deckId];
  const sampleRate = system.decks[deckId].track?.sampleRate || 48_000;
  ui.hotCueButtons.forEach((button, index) => {
    const frame = cues[index];
    const set = Number.isFinite(frame);
    button.classList.toggle('is-set', set);
    button.textContent = set ? `C${index + 1} ${formatTime(frame / sampleRate)}` : `C${index + 1} SET`;
    button.title = set ? 'Click to jump. Shift-click or right-click to clear.' : 'Click to set at the current playhead.';
  });
}

function renderLoopState(deckId, loop = system.decks[deckId].loop) {
  const ui = deckUi[deckId];
  const deck = system.decks[deckId];
  const sampleRate = deck.track?.sampleRate || 48_000;
  const gridTime = formatTime(deck.beatOffsetFrame / sampleRate, true);
  ui.loopState.textContent = loop?.enabled
    ? `LOOP ${loop.beats} BEATS • ${formatTime(loop.startFrame / sampleRate, true)} → ${formatTime(loop.endFrame / sampleRate, true)} • GRID ${gridTime}`
    : `LOOP OFF • GRID ${gridTime}`;
  ui.loopButtons.forEach((button) => button.classList.toggle('is-active', Boolean(loop?.enabled && Number(button.dataset.beats) === loop.beats)));
}

function tapDeck(deckId) {
  const ui = deckUi[deckId];
  const now = performance.now();
  if (ui.taps.length && now - ui.taps.at(-1) > 2500) ui.taps = [];
  ui.taps.push(now);
  if (ui.taps.length > 9) ui.taps.shift();
  const bpm = calculateTapTempo(ui.taps);
  ui.tap.textContent = bpm ? `${bpm.toFixed(1)} BPM` : `TAP ${ui.taps.length}`;
  ui.tap.classList.add('is-tapped');
  clearTimeout(ui.tapResetTimer);
  ui.tapResetTimer = setTimeout(() => {
    ui.tap.classList.remove('is-tapped');
    ui.tap.textContent = 'TAP BPM';
  }, 900);
  if (bpm) {
    system.decks[deckId].setManualBpm(bpm, 'tap');
    appendLog('tempo', `Deck ${deckId} tap BPM`, `${bpm.toFixed(1)} BPM / ${ui.taps.length} taps`);
  }
}

function syncDeckFromOther(targetDeckId, reason) {
  const sourceDeckId = targetDeckId === 'A' ? 'B' : 'A';
  const result = system.syncDeck(targetDeckId, sourceDeckId);
  if (result.reason === 'missing-bpm') appendLog('tempo', `Deck ${targetDeckId} sync unavailable`, 'tap BPM or wait for analysis');
  else if (result.reason === 'blend-only') appendLog('tempo', `Deck ${targetDeckId} left free`, 'no safe BPM-family match inside ±16%');
  else if (!result.ok) appendLog('tempo', `Deck ${targetDeckId} sync clamped`, `${signed(result.unclamped, 2)}% requested / ±16% allowed`);
  else appendLog('tempo', `Deck ${targetDeckId} sync applied`, `${reason}${result.targetFamilyFactor !== 1 ? ` / ${result.targetFamilyFactor}× family` : ''}`);
  return result;
}

function applyAutoSync(reason) {
  if (!globalUi.autoSyncEnabled.checked || autoSyncBusy || !system.ready) return;
  const master = globalUi.syncMaster.value === 'B' ? 'B' : 'A';
  const target = master === 'A' ? 'B' : 'A';
  const sourceBpm = system.decks[master].getEffectiveBpm();
  const targetBpm = system.decks[target].getBaseBpm();
  if (!sourceBpm || !targetBpm) {
    globalUi.syncReadout.textContent = 'WAITING BPM';
    return;
  }
  const key = `${master}:${sourceBpm.toFixed(3)}:${targetBpm.toFixed(3)}`;
  if (key === lastAutoSyncKey) return;
  autoSyncBusy = true;
  lastAutoSyncKey = key;
  try {
    const result = system.syncDeck(target, master);
    deckUi[master].syncState.textContent = 'MASTER';
    deckUi[target].syncState.textContent = ['matched', 'family-matched'].includes(result.reason) ? `LOCKED TO ${master}` : result.reason.toUpperCase();
    globalUi.syncReadout.textContent = ['matched', 'family-matched'].includes(result.reason) ? `${target} ${signed(result.percent, 2)}%` : result.reason.toUpperCase();
    appendLog('tempo', `Auto sync ${master} → ${target}`, reason);
  } finally {
    autoSyncBusy = false;
  }
}

function bindMixerRange(inputSelector, outputSelector, setter, formatter) {
  const input = $(inputSelector);
  const output = $(outputSelector);
  input.addEventListener('input', () => {
    const value = Number(input.value);
    output.textContent = formatter(value);
    setter(value);
    updateRotaryVisual(input);
  });
}

function setCrossfader(value, { automation = false } = {}) {
  const normalized = Math.max(-1, Math.min(1, Number(value) || 0));
  globalUi.crossfader.value = String(normalized);
  system.setCrossfader(normalized);
  const label = normalized < -.03 ? `A ${Math.round(-normalized * 100)}%`
    : normalized > .03 ? `B ${Math.round(normalized * 100)}%`
      : 'CENTER';
  globalUi.crossfaderValue.textContent = label;
  globalUi.xfadeMetric.textContent = automation ? `AUTO ${label}` : label;
}

function wireRotaries() {
  for (const input of document.querySelectorAll('input.rotary')) {
    updateRotaryVisual(input);
    let gesture = null;
    input.addEventListener('pointerdown', (event) => {
      if (input.disabled) return;
      input.setPointerCapture(event.pointerId);
      gesture = { id: event.pointerId, y: event.clientY, value: Number(input.value) };
      event.preventDefault();
    });
    input.addEventListener('pointermove', (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      const min = Number(input.min);
      const max = Number(input.max);
      const range = max - min;
      const next = gesture.value + (gesture.y - event.clientY) / 130 * range;
      setRangeValue(input, next);
      event.preventDefault();
    });
    const end = (event) => {
      if (!gesture || gesture.id !== event.pointerId) return;
      gesture = null;
      event.preventDefault();
    };
    input.addEventListener('pointerup', end);
    input.addEventListener('pointercancel', end);
    input.addEventListener('wheel', (event) => {
      if (input.disabled) return;
      const step = Number(input.step) || (Number(input.max) - Number(input.min)) / 100;
      setRangeValue(input, Number(input.value) + (event.deltaY < 0 ? step * 4 : -step * 4));
      event.preventDefault();
    }, { passive: false });
    input.addEventListener('dblclick', (event) => {
      if (input.disabled) return;
      setRangeValue(input, Number(input.dataset.default ?? input.min ?? 0));
      event.preventDefault();
    });
    input.addEventListener('input', () => updateRotaryVisual(input));
  }
}

function setRangeValue(input, value) {
  const min = Number(input.min);
  const max = Number(input.max);
  const step = Number(input.step) || 0;
  let next = Math.max(min, Math.min(max, value));
  if (step > 0) next = Math.round(next / step) * step;
  input.value = String(next);
  input.dispatchEvent(new Event('input', { bubbles: true }));
}

function updateRotaryVisual(input) {
  if (!input?.classList?.contains('rotary')) return;
  const shell = input.closest('.rotary-shell');
  if (!shell) return;
  const min = Number(input.min);
  const max = Number(input.max);
  const value = Number(input.value);
  const t = max > min ? (value - min) / (max - min) : 0;
  shell.style.setProperty('--angle', `${-135 + Math.max(0, Math.min(1, t)) * 270}deg`);
}

function wireVisuals() {
  visual.addEventListener('metrics', (event) => {
    const { fps, instances } = event.detail;
    bench.visualFpsSamples.push(fps);
    if (bench.visualFpsSamples.length > 600) bench.visualFpsSamples.shift();
    bench.visualInstances = instances;
    globalUi.fpsMetric.textContent = `${fps.toFixed(0)} / ${instances.toLocaleString()}`;
    world.reportFrameMetrics(fps, bench.longTasks);
  });
  if (!visual.running) {
    globalUi.visualStatePill.textContent = 'WEBGL2 UNAVAILABLE';
    globalUi.visualStatePill.className = 'pill pill-bad';
    globalUi.killVisual.disabled = true;
    globalUi.recoverVisual.disabled = true;
  }
  visual.addEventListener('state', (event) => {
    const running = event.detail.running;
    globalUi.visualStatePill.textContent = running ? 'RUNNING' : 'VISUALS DEAD';
    globalUi.visualStatePill.className = running ? 'pill pill-ok' : 'pill pill-bad';
    globalUi.killVisual.disabled = !running;
    globalUi.recoverVisual.disabled = running;
    appendLog('visual', running ? 'Renderer recovered' : 'Renderer killed', 'dual audio graph unchanged');
    world.reportRendererState(running ? 'running' : 'killed');
  });
  globalUi.stressLevel.addEventListener('input', () => {
    visual.setLevel(globalUi.stressLevel.value);
    globalUi.stressValue.textContent = `${globalUi.stressLevel.value}%`;
  });
  globalUi.cpuBurn.addEventListener('change', () => visual.setCpuBurn(globalUi.cpuBurn.checked));
  globalUi.killVisual.addEventListener('click', () => visual.kill());
  globalUi.recoverVisual.addEventListener('click', () => visual.recover());
}

function setAllControlsEnabled(enabled) {
  const elements = [
    globalUi.startBoth, globalUi.panicStop, globalUi.exportEvidence, globalUi.faultDeck, globalUi.providerDelay,
    globalUi.dropRegion, globalUi.forceSeek,
    ...document.querySelectorAll('.deck-panel button, .deck-panel input, .deck-panel select, .mixer-panel button, .mixer-panel input, .mixer-panel select'),
  ];
  for (const element of elements) element.disabled = !enabled;
  globalUi.automixCancel.disabled = true;
  globalUi.recordStop.disabled = true;
  globalUi.recordStart.disabled = !enabled;
}

function updateTempoMetric() {
  const a = system.decks.A.getEffectiveBpm();
  const b = system.decks.B.getEffectiveBpm();
  globalUi.tempoMetric.textContent = `${a ? a.toFixed(1) : '—'} / ${b ? b.toFixed(1) : '—'}`;
}

function paintMeter(element, db) {
  const percent = Math.max(0, Math.min(100, (Number(db) + 60) / 60 * 100));
  element.style.height = `${percent}%`;
}

function appendLog(category, title, message = '') {
  const item = document.createElement('li');
  const time = document.createElement('time');
  time.textContent = new Date().toLocaleTimeString([], { hour12: false });
  const label = document.createElement('b');
  label.textContent = `${category.toUpperCase()} / ${title}`;
  const detail = document.createElement('span');
  detail.textContent = message;
  item.append(time, label, detail);
  globalUi.eventLog.prepend(item);
  while (globalUi.eventLog.children.length > 100) globalUi.eventLog.lastElementChild.remove();
}

function compact(value) {
  try { return JSON.stringify(value); } catch { return String(value); }
}
function signed(value, decimals = 1) {
  const v = Number(value) || 0;
  return `${v > 0 ? '+' : ''}${v.toFixed(decimals)}`;
}
function filterLabel(value) {
  if (value < -.03) return `LP ${Math.round(-value * 100)}%`;
  if (value > .03) return `HP ${Math.round(value * 100)}%`;
  return 'OPEN';
}
function bpmSourceLabel(source, confidence, familyFactor = 1) {
  const family = familyFactor !== 1 ? ` / ${familyFactor}× FAMILY` : '';
  if (source === 'analyzing') return `ANALYZING${family}`;
  if (source === 'tap') return `TAP / MANUAL${family}`;
  if (source === 'embedded') return `KNOWN / DEMO${family}`;
  if (source === 'analyzed') return `ANALYZED ${Math.round((confidence || 0) * 100)}%${family}`;
  return 'UNKNOWN / TAP ME';
}
function formatTime(seconds, milliseconds = false) {
  if (!Number.isFinite(seconds)) return '0:00';
  const minutes = Math.floor(seconds / 60);
  const remainder = seconds - minutes * 60;
  return `${minutes}:${remainder.toFixed(milliseconds ? 3 : 1).padStart(milliseconds ? 6 : 4, '0')}`;
}
function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function downloadJson(filename, value) {
  const blob = new Blob([JSON.stringify(value, null, 2)], { type: 'application/json' });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = filename;
  anchor.click();
  setTimeout(() => URL.revokeObjectURL(url), 0);
}
function isTypingTarget(target) {
  return target instanceof HTMLInputElement || target instanceof HTMLSelectElement || target instanceof HTMLTextAreaElement;
}
